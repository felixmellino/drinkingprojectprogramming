repo: felixmellino/drinkingprojectprogramming
branch: main

## Last sync
date: 2026-11-18T14:16:04Z

### Updated in this project
- Six visual directions built as token themes on top of the repo's existing CSS hooks
- Component library + interactive UI kit (Map, Check in, Leaderboard, Lobby, Profile, Photos, Login)
- Copy, scoring table, location states and territory names taken from the repo

## Screen map
| Screen | Repo files |
|---|---|
| Bottom nav | app_navigation.py, assets/navigation.css |
| Map | map_ui.py, pages/5_Map.py |
| Check in | pages/3_Check_in.py, drink_entry_ui.py, assets/drink_entries.css, core/scoring_v1.py, core/checkin_feedback.py |
| Leaderboard | assets/standings.css, standings_ui.py |
| Lobby | lobby_ui.py, assets/lobbies.css |
| Profile / Memories / Login | profile_ui.py, friends_ui.py, photo_history_ui.py, account_ui.py (not read in detail; built from brief) |
