/* @ds-bundle: {"format":4,"namespace":"WeGoPubDesignSystem_71f296","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"Icon","sourcePath":"components/actions/Icon.jsx"},{"name":"IconButton","sourcePath":"components/actions/IconButton.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Countdown","sourcePath":"components/feedback/Countdown.jsx"},{"name":"ProgressBar","sourcePath":"components/feedback/ProgressBar.jsx"},{"name":"Skeleton","sourcePath":"components/feedback/Skeleton.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"ChipGroup","sourcePath":"components/forms/ChipGroup.jsx"},{"name":"ChoiceTiles","sourcePath":"components/forms/ChoiceTiles.jsx"},{"name":"SegmentedControl","sourcePath":"components/forms/SegmentedControl.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"TextInput","sourcePath":"components/forms/TextInput.jsx"},{"name":"PasswordInput","sourcePath":"components/forms/TextInput.jsx"},{"name":"CameraFrame","sourcePath":"components/game/CameraFrame.jsx"},{"name":"MapLegend","sourcePath":"components/game/MapLegend.jsx"},{"name":"Avatar","sourcePath":"components/identity/Avatar.jsx"},{"name":"RankBadge","sourcePath":"components/identity/RankBadge.jsx"},{"name":"YouTag","sourcePath":"components/identity/RankBadge.jsx"},{"name":"StatusPill","sourcePath":"components/identity/StatusPill.jsx"},{"name":"PlayerRow","sourcePath":"components/lists/PlayerRow.jsx"},{"name":"NAV_ITEMS","sourcePath":"components/navigation/BottomNav.jsx"},{"name":"BottomNav","sourcePath":"components/navigation/BottomNav.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"FloatingPanel","sourcePath":"components/surfaces/FloatingPanel.jsx"},{"name":"PhotoCard","sourcePath":"components/surfaces/PhotoCard.jsx"},{"name":"StatCard","sourcePath":"components/surfaces/StatCard.jsx"},{"name":"TerritoryCard","sourcePath":"components/surfaces/TerritoryCard.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"b2606cd47526","components/actions/Icon.jsx":"daa135bbbc0c","components/actions/IconButton.jsx":"73867f7e39de","components/ds-fallback.js":"006f0e5963cc","components/feedback/Alert.jsx":"095db58126a2","components/feedback/Countdown.jsx":"c7546b6b4471","components/feedback/ProgressBar.jsx":"27dd4e0b79ae","components/feedback/Skeleton.jsx":"433eeeee6075","components/feedback/Toast.jsx":"0358fb907f84","components/forms/Checkbox.jsx":"9ef6d1ba1f44","components/forms/ChipGroup.jsx":"cda4a043baf1","components/forms/ChoiceTiles.jsx":"efcb80c67f60","components/forms/SegmentedControl.jsx":"d2b6cc6e55e0","components/forms/Select.jsx":"01ec27433c37","components/forms/TextInput.jsx":"bc5581deb6a7","components/game/CameraFrame.jsx":"8ad010c4245b","components/game/MapLegend.jsx":"0d1cd2b5a52c","components/identity/Avatar.jsx":"faa5968d62e0","components/identity/RankBadge.jsx":"3943351115ca","components/identity/StatusPill.jsx":"256c31d1deed","components/lists/PlayerRow.jsx":"d73b3408d92b","components/navigation/BottomNav.jsx":"030bbdc5f3a5","components/surfaces/Card.jsx":"38e2c2b761f2","components/surfaces/FloatingPanel.jsx":"0a0a9770e9f9","components/surfaces/PhotoCard.jsx":"a13a1ca5425d","components/surfaces/StatCard.jsx":"1673f89a1c8d","components/surfaces/TerritoryCard.jsx":"013369352f50","ui_kits/app/BoardLobby.jsx":"42d2f39b2c41","ui_kits/app/CheckinScreen.jsx":"b0cdabf258b3","ui_kits/app/MapScreen.jsx":"54a36c8b39cf","ui_kits/app/MapView.jsx":"43cf000ef783","ui_kits/app/Phone.jsx":"b61836ee7ba4","ui_kits/app/ProfileMemories.jsx":"01d5eaf949e8","ui_kits/app/data.jsx":"7104134d848e","ui_kits/app/directions.js":"27e9bb99cb6d"},"inlinedExternals":[],"unexposedExports":[{"name":"initials","sourcePath":"components/identity/Avatar.jsx"}]} */

(() => {

const __ds_ns = (window.WeGoPubDesignSystem_71f296 = window.WeGoPubDesignSystem_71f296 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/actions/Icon.jsx
try { (() => {
/** Material Symbols Rounded glyph. The only icon set in WeGoPub. */
function Icon({
  name,
  fill = false,
  size,
  className = '',
  style,
  label
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: 'wg-icon' + (fill ? ' wg-icon--fill' : '') + (className ? ' ' + className : ''),
    style: {
      ...(size ? {
        fontSize: size
      } : null),
      ...style
    },
    "aria-hidden": label ? undefined : true,
    "aria-label": label,
    role: label ? 'img' : undefined
  }, name);
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Icon.jsx", error: String((e && e.message) || e) }); }

// components/actions/Button.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(' ');
function Button({
  variant = 'primary',
  size = 'md',
  block = false,
  icon,
  iconRight,
  disabled,
  type = 'button',
  onClick,
  children,
  className,
  style
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: type,
    disabled: disabled,
    onClick: onClick,
    style: style,
    className: cx('wg-btn', 'wg-btn--' + variant, size !== 'md' && 'wg-btn--' + size, block && 'wg-btn--block', className)
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon
  }), children, iconRight && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: iconRight
  }));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/actions/IconButton.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(' ');
function IconButton({
  icon,
  label,
  variant = 'default',
  size = 'md',
  fill,
  onClick,
  className,
  style
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": label,
    title: label,
    onClick: onClick,
    style: style,
    className: cx('wg-iconbtn', variant !== 'default' && 'wg-iconbtn--' + variant, size === 'lg' && 'wg-iconbtn--lg', className)
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    fill: fill
  }));
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/ds-fallback.js
try { (() => {
// Dev fallback: if _ds_bundle.js hasn't been compiled yet, build the namespace from the component sources.
(function () {
  var NS = 'WeGoPubDesignSystem_71f296';
  if (window[NS] || !window.Babel) return;
  var base = document.currentScript.src.replace(/ds-fallback\.js.*$/, '');
  var files = ['actions/Icon', 'actions/Button', 'actions/IconButton', 'identity/Avatar', 'identity/RankBadge', 'identity/StatusPill', 'feedback/ProgressBar', 'forms/TextInput', 'forms/Checkbox', 'forms/Select', 'forms/SegmentedControl', 'forms/ChipGroup', 'forms/ChoiceTiles', 'surfaces/Card', 'surfaces/StatCard', 'surfaces/FloatingPanel', 'surfaces/PhotoCard', 'surfaces/TerritoryCard', 'lists/PlayerRow', 'feedback/Alert', 'feedback/Toast', 'feedback/Countdown', 'feedback/Skeleton', 'navigation/BottomNav', 'game/CameraFrame', 'game/MapLegend'];
  var ns = {};
  files.forEach(function (f) {
    var x = new XMLHttpRequest();
    x.open('GET', base + f + '.jsx', false);
    x.send();
    if (x.status !== 200) {
      console.error('ds-fallback: missing ' + f);
      return;
    }
    var src = x.responseText.replace(/^import .*$/gm, '');
    var names = [];
    src.replace(/export (?:function|const) (\w+)/g, function (_, n) {
      names.push(n);
    });
    src = src.replace(/export (function|const)/g, '$1');
    var prior = Object.keys(ns).filter(function (n) {
      return names.indexOf(n) < 0;
    });
    var code = 'var __ns = window.__wgns; var {useState, useEffect, useRef, useId} = React; var {' + prior.join(',') + '} = __ns;\n' + src + '\nreturn {' + names.join(',') + '};';
    var out = Babel.transform('(function(){' + code + '})', {
      presets: ['react']
    }).code;
    window.__wgns = ns;
    Object.assign(ns, (0, eval)(out)());
  });
  window[NS] = ns;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/ds-fallback.js", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
const ICONS = {
  success: 'check_circle',
  warning: 'warning',
  error: 'error',
  info: 'info'
};
function Alert({
  tone = 'info',
  title,
  children,
  icon,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: 'wg-alert wg-alert--' + tone,
    role: tone === 'error' ? 'alert' : 'status'
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon || ICONS[tone],
    fill: true
  }), /*#__PURE__*/React.createElement("div", null, title && /*#__PURE__*/React.createElement("b", null, title), children), action || /*#__PURE__*/React.createElement("span", null));
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Countdown.jsx
try { (() => {
const {
  useEffect,
  useState
} = React;
const pad = n => String(n).padStart(2, '0');
function Countdown({
  seconds = 0,
  inline,
  live = true,
  compact
}) {
  const [s, setS] = useState(seconds);
  useEffect(() => {
    setS(seconds);
  }, [seconds]);
  useEffect(() => {
    if (!live) return;
    const t = setInterval(() => setS(v => Math.max(0, v - 1)), 1000);
    return () => clearInterval(t);
  }, [live]);
  const d = Math.floor(s / 86400),
    h = Math.floor(s % 86400 / 3600),
    m = Math.floor(s % 3600 / 60),
    sec = s % 60;
  if (inline) return /*#__PURE__*/React.createElement("span", {
    className: "wg-countdown wg-countdown--inline"
  }, d > 0 ? d + 'd ' + h + 'h ' + pad(m) + 'm' : h > 0 ? h + ':' + pad(m) + ':' + pad(sec) : m + ':' + pad(sec));
  const parts = d > 0 ? [[d, 'days'], [h, 'hrs'], [m, 'min']] : [[h, 'hrs'], [m, 'min'], [sec, 'sec']];
  return /*#__PURE__*/React.createElement("span", {
    className: "wg-countdown",
    role: "timer"
  }, parts.map(([v, l]) => /*#__PURE__*/React.createElement("div", {
    key: l
  }, /*#__PURE__*/React.createElement("span", {
    className: "wg-num"
  }, compact ? v : pad(v)), /*#__PURE__*/React.createElement("small", null, l))));
}
Object.assign(__ds_scope, { Countdown });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Countdown.jsx", error: String((e && e.message) || e) }); }

// components/feedback/ProgressBar.jsx
try { (() => {
function ProgressBar({
  value = 0,
  max = 100,
  tone = 'accent',
  thin,
  label
}) {
  const pct = Math.max(0, Math.min(100, value / max * 100));
  return /*#__PURE__*/React.createElement("div", {
    className: 'wg-progress' + (tone !== 'accent' ? ' wg-progress--' + tone : '') + (thin ? ' wg-progress--thin' : ''),
    role: "progressbar",
    "aria-valuenow": value,
    "aria-valuemax": max,
    "aria-label": label
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: pct + '%'
    }
  }));
}
Object.assign(__ds_scope, { ProgressBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/ProgressBar.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Skeleton.jsx
try { (() => {
function Skeleton({
  w = '100%',
  h = 16,
  r,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "wg-skel",
    "aria-hidden": "true",
    style: {
      width: w,
      height: h,
      ...(r != null ? {
        borderRadius: r
      } : null),
      ...style
    }
  });
}
Object.assign(__ds_scope, { Skeleton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Skeleton.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const ICONS = {
  success: 'check_circle',
  warning: 'warning',
  error: 'error',
  info: 'info'
};
function Toast({
  tone = 'success',
  children,
  icon,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: 'wg-toast wg-toast--' + tone,
    role: "status",
    style: style
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon || ICONS[tone],
    fill: true
  }), children);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked,
  defaultChecked,
  onChange,
  hint
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: "wg-check"
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: checked,
    defaultChecked: defaultChecked,
    onChange: e => onChange && onChange(e.target.checked)
  }), /*#__PURE__*/React.createElement("span", {
    className: "wg-check__box"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "check"
  })), /*#__PURE__*/React.createElement("span", null, label, hint && /*#__PURE__*/React.createElement("span", {
    className: "wg-hint",
    style: {
      display: 'block'
    }
  }, hint)));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/ChipGroup.jsx
try { (() => {
function ChipGroup({
  options = [],
  value,
  onChange,
  floating
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "wg-chips"
  }, options.map(o => {
    const v = typeof o === 'string' ? o : o.value;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      type: "button",
      className: 'wg-chip' + (floating ? ' wg-chip--float' : ''),
      "aria-pressed": v === value,
      onClick: () => onChange && onChange(v)
    }, o.icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: o.icon
    }), typeof o === 'string' ? o : o.label);
  }));
}
Object.assign(__ds_scope, { ChipGroup });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/ChipGroup.jsx", error: String((e && e.message) || e) }); }

// components/forms/ChoiceTiles.jsx
try { (() => {
function ChoiceTiles({
  options = [],
  value,
  onChange,
  columns = 4,
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "wg-tiles",
    role: "group",
    "aria-label": label,
    style: {
      gridTemplateColumns: 'repeat(' + columns + ',minmax(0,1fr))'
    }
  }, options.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    className: "wg-tile",
    "aria-pressed": o.value === value,
    onClick: () => onChange && onChange(o.value)
  }, o.icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: o.icon,
    fill: o.value === value
  }), /*#__PURE__*/React.createElement("span", null, o.label), o.sub && /*#__PURE__*/React.createElement("small", null, o.sub))));
}
Object.assign(__ds_scope, { ChoiceTiles });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/ChoiceTiles.jsx", error: String((e && e.message) || e) }); }

// components/forms/SegmentedControl.jsx
try { (() => {
function SegmentedControl({
  options = [],
  value,
  onChange,
  label
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "wg-seg",
    role: "group",
    "aria-label": label
  }, options.map(o => {
    const v = typeof o === 'string' ? o : o.value;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      type: "button",
      "aria-pressed": v === value,
      onClick: () => onChange && onChange(v)
    }, typeof o === 'string' ? o : o.label, o.sub && /*#__PURE__*/React.createElement("small", null, o.sub));
  }));
}
Object.assign(__ds_scope, { SegmentedControl });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SegmentedControl.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function Select({
  label,
  options = [],
  value,
  defaultValue,
  onChange,
  icon
}) {
  const id = React.useId();
  return /*#__PURE__*/React.createElement("div", {
    className: "wg-field"
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: id
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "wg-input"
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon
  }), /*#__PURE__*/React.createElement("select", {
    id: id,
    value: value,
    defaultValue: defaultValue,
    onChange: e => onChange && onChange(e.target.value)
  }, options.map(o => typeof o === 'string' ? /*#__PURE__*/React.createElement("option", {
    key: o
  }, o) : /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "expand_more"
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextInput.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  useState
} = React;
function TextInput({
  label,
  type = 'text',
  value,
  defaultValue,
  placeholder,
  icon,
  readOnly,
  error,
  hint,
  onChange,
  autoComplete,
  name
}) {
  const [show, setShow] = useState(false);
  const isPw = type === 'password';
  const id = React.useId();
  return /*#__PURE__*/React.createElement("div", {
    className: "wg-field"
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: id
  }, label), /*#__PURE__*/React.createElement("div", {
    className: 'wg-input' + (readOnly ? ' wg-input--readonly' : '') + (error ? ' wg-input--error' : '')
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon
  }), /*#__PURE__*/React.createElement("input", {
    id: id,
    name: name,
    type: isPw && show ? 'text' : type,
    value: value,
    defaultValue: defaultValue,
    placeholder: placeholder,
    readOnly: readOnly,
    autoComplete: autoComplete,
    "aria-invalid": !!error,
    onChange: e => onChange && onChange(e.target.value)
  }), readOnly && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "lock"
  }), isPw && /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: () => setShow(s => !s),
    "aria-label": show ? 'Hide password' : 'Show password',
    style: {
      border: 0,
      background: 'none',
      color: 'inherit',
      cursor: 'pointer',
      display: 'grid',
      placeItems: 'center',
      minWidth: 44,
      minHeight: 44,
      marginRight: -10
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: show ? 'visibility_off' : 'visibility'
  }))), error ? /*#__PURE__*/React.createElement("span", {
    className: "wg-hint wg-hint--error"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "error"
  }), error) : hint ? /*#__PURE__*/React.createElement("span", {
    className: "wg-hint"
  }, hint) : null);
}
function PasswordInput(props) {
  return /*#__PURE__*/React.createElement(TextInput, _extends({}, props, {
    type: "password"
  }));
}
Object.assign(__ds_scope, { TextInput, PasswordInput });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextInput.jsx", error: String((e && e.message) || e) }); }

// components/game/CameraFrame.jsx
try { (() => {
function CameraFrame({
  state = 'live',
  src,
  onShutter,
  onRetake,
  onRetry,
  onFlip
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "wg-camera"
  }, state === 'blocked' ? /*#__PURE__*/React.createElement("div", {
    className: "wg-camera__msg"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "no_photography"
  }), /*#__PURE__*/React.createElement("b", {
    style: {
      fontSize: 18
    }
  }, "Camera is blocked"), /*#__PURE__*/React.createElement("span", {
    style: {
      opacity: .8,
      fontSize: 14
    }
  }, "Allow camera access for this site in your browser settings, then tap Retry."), /*#__PURE__*/React.createElement("button", {
    className: "wg-btn wg-btn--primary",
    onClick: onRetry
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "refresh"
  }), "Retry")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "wg-camera__view"
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: "Your drink photo"
  }) : state === 'captured' ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "sports_bar",
    size: 64,
    style: {
      opacity: .4
    }
  }) : null), state === 'live' && /*#__PURE__*/React.createElement("div", {
    className: "wg-camera__corners"
  }), /*#__PURE__*/React.createElement("div", {
    className: "wg-camera__bar"
  }, /*#__PURE__*/React.createElement("span", null), state === 'live' ? /*#__PURE__*/React.createElement("button", {
    className: "wg-shutter",
    "aria-label": "Take photo",
    onClick: onShutter
  }, /*#__PURE__*/React.createElement("span", null)) : /*#__PURE__*/React.createElement("button", {
    className: "wg-btn wg-btn--secondary",
    onClick: onRetake
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "replay"
  }), "Retake"), /*#__PURE__*/React.createElement("span", {
    style: {
      justifySelf: 'end'
    }
  }, state === 'live' && /*#__PURE__*/React.createElement("button", {
    className: "wg-iconbtn wg-iconbtn--float",
    "aria-label": "Switch camera",
    onClick: onFlip
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "cameraswitch"
  }))))));
}
Object.assign(__ds_scope, { CameraFrame });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/CameraFrame.jsx", error: String((e && e.message) || e) }); }

// components/game/MapLegend.jsx
try { (() => {
function MapLegend({
  showYou = true,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "wg-legend",
    style: style
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("i", {
    style: {
      '--c': 'var(--territory-yours)'
    }
  }), "Yours"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("i", {
    style: {
      '--c': 'var(--territory-theirs)'
    }
  }), "Rival's"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("i", {
    style: {
      '--c': 'var(--territory-free)'
    }
  }), "Unclaimed"), showYou && /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("i", {
    className: "wg-legend__dot"
  }), "You"));
}
Object.assign(__ds_scope, { MapLegend });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/game/MapLegend.jsx", error: String((e && e.message) || e) }); }

// components/identity/Avatar.jsx
try { (() => {
const cx = (...a) => a.filter(Boolean).join(' ');
const HUES = ['#F6C177', '#9CCFD8', '#C4A7E7', '#F2B8A0', '#A7C7E7', '#E8D5B7', '#B8C0FF', '#F5A9C8'];
function initials(name = '') {
  const p = name.replace(/[^\p{L}\p{N} ]/gu, ' ').trim().split(/\s+/);
  return ((p[0] || '?')[0] + (p[1] ? p[1][0] : (p[0] || '')[1] || '')).toUpperCase();
}
function Avatar({
  name = '',
  src,
  size = 40,
  ring = false,
  className,
  style
}) {
  let h = 0;
  for (const c of name) h = h * 31 + c.charCodeAt(0) >>> 0;
  return /*#__PURE__*/React.createElement("span", {
    className: cx('wg-avatar', ring && 'wg-avatar--ring', className),
    style: {
      '--size': size + 'px',
      '--av-bg': HUES[h % HUES.length],
      ...style
    },
    title: name
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: ""
  }) : initials(name));
}
Object.assign(__ds_scope, { initials, Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/identity/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/identity/RankBadge.jsx
try { (() => {
function RankBadge({
  rank
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: 'wg-rank' + (rank <= 3 ? ' wg-rank--' + rank : ''),
    "aria-label": 'Rank ' + rank
  }, rank);
}
function YouTag() {
  return /*#__PURE__*/React.createElement("span", {
    className: "wg-you"
  }, "YOU");
}
Object.assign(__ds_scope, { RankBadge, YouTag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/identity/RankBadge.jsx", error: String((e && e.message) || e) }); }

// components/identity/StatusPill.jsx
try { (() => {
const ICONS = {
  yours: 'flag',
  theirs: 'swords',
  free: 'radio_button_unchecked',
  test: 'science',
  closed: 'schedule',
  live: 'bolt'
};
const LABELS = {
  yours: 'Yours',
  theirs: "Rival's",
  free: 'Unclaimed',
  test: 'Test season',
  closed: 'Closed',
  live: 'Live'
};
function StatusPill({
  status = 'free',
  children,
  icon,
  solid
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: 'wg-pill wg-pill--' + status + (solid ? ' wg-pill--solid' : '')
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon || ICONS[status],
    fill: status === 'yours'
  }), children ?? LABELS[status]);
}
Object.assign(__ds_scope, { StatusPill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/identity/StatusPill.jsx", error: String((e && e.message) || e) }); }

// components/lists/PlayerRow.jsx
try { (() => {
function PlayerRow({
  rank,
  name,
  src,
  sub,
  score,
  unit = 'pts',
  you
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: 'wg-row' + (you ? ' wg-row--you' : '')
  }, /*#__PURE__*/React.createElement(__ds_scope.RankBadge, {
    rank: rank
  }), /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    name: name,
    src: src
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wg-row__name"
  }, /*#__PURE__*/React.createElement("span", null, name), you && /*#__PURE__*/React.createElement(__ds_scope.YouTag, null)), sub && /*#__PURE__*/React.createElement("div", {
    className: "wg-row__sub"
  }, sub)), /*#__PURE__*/React.createElement("div", {
    className: "wg-num wg-row__score"
  }, score, /*#__PURE__*/React.createElement("small", null, unit)));
}
Object.assign(__ds_scope, { PlayerRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/lists/PlayerRow.jsx", error: String((e && e.message) || e) }); }

// components/navigation/BottomNav.jsx
try { (() => {
const NAV_ITEMS = [{
  id: 'profile',
  label: 'Profile',
  icon: 'person'
}, {
  id: 'lobby',
  label: 'Lobby',
  icon: 'group'
}, {
  id: 'checkin',
  label: 'Check in',
  icon: 'add',
  center: true
}, {
  id: 'map',
  label: 'Map',
  icon: 'map'
}, {
  id: 'leaderboard',
  label: 'Ranks',
  icon: 'leaderboard'
}, {
  id: 'history',
  label: 'Photos',
  icon: 'photo_library'
}];
function BottomNav({
  active = 'map',
  onNavigate,
  style
}) {
  const items = [NAV_ITEMS[0], NAV_ITEMS[1], NAV_ITEMS[3], NAV_ITEMS[2], NAV_ITEMS[4], NAV_ITEMS[5]];
  return /*#__PURE__*/React.createElement("nav", {
    className: "wg-nav",
    "aria-label": "Main",
    style: style
  }, items.map(it => /*#__PURE__*/React.createElement("button", {
    key: it.id,
    type: "button",
    className: it.center ? 'wg-nav__center' : undefined,
    "aria-current": active === it.id ? 'page' : undefined,
    onClick: () => onNavigate && onNavigate(it.id)
  }, it.center ? /*#__PURE__*/React.createElement("span", {
    className: "wg-nav__plus"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "add"
  })) : /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: it.icon
  }), /*#__PURE__*/React.createElement("span", null, it.label))));
}
Object.assign(__ds_scope, { NAV_ITEMS, BottomNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/BottomNav.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
function Card({
  variant,
  children,
  style,
  className,
  as: Tag = 'div'
}) {
  return /*#__PURE__*/React.createElement(Tag, {
    className: 'wg-card' + (variant ? ' wg-card--' + variant : '') + (className ? ' ' + className : ''),
    style: style
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/FloatingPanel.jsx
try { (() => {
function FloatingPanel({
  children,
  style,
  className
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: 'wg-hud' + (className ? ' ' + className : ''),
    style: style
  }, children);
}
Object.assign(__ds_scope, { FloatingPanel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/FloatingPanel.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/PhotoCard.jsx
try { (() => {
function PhotoCard({
  user,
  time,
  src,
  territory,
  status = 'free',
  drink,
  points,
  onOpen
}) {
  return /*#__PURE__*/React.createElement("article", {
    className: "wg-photo",
    onClick: onOpen,
    style: onOpen ? {
      cursor: 'pointer'
    } : undefined
  }, /*#__PURE__*/React.createElement("div", {
    className: "wg-photo__img"
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: 'Drink photo by ' + user
  }) : /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "photo_camera"
  }), /*#__PURE__*/React.createElement("div", {
    className: "wg-photo__top"
  }, /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    name: user,
    size: 34
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      lineHeight: 1.2
    }
  }, /*#__PURE__*/React.createElement("b", null, user), /*#__PURE__*/React.createElement("span", null, time)))), /*#__PURE__*/React.createElement("div", {
    className: "wg-photo__meta"
  }, territory ? /*#__PURE__*/React.createElement(__ds_scope.StatusPill, {
    status: status
  }, territory) : /*#__PURE__*/React.createElement(__ds_scope.StatusPill, {
    status: "closed",
    icon: "location_off"
  }, "Outside territories"), /*#__PURE__*/React.createElement("span", {
    className: "wg-muted",
    style: {
      fontSize: 13
    }
  }, drink), /*#__PURE__*/React.createElement("span", {
    className: "wg-num wg-photo__pts"
  }, "+", points)));
}
Object.assign(__ds_scope, { PhotoCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/PhotoCard.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/StatCard.jsx
try { (() => {
function StatCard({
  label,
  value,
  sub,
  accent
}) {
  return /*#__PURE__*/React.createElement(__ds_scope.Card, {
    variant: accent ? 'accent' : undefined,
    style: {
      padding: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wg-stat"
  }, /*#__PURE__*/React.createElement("span", {
    className: "wg-stat__label"
  }, label), /*#__PURE__*/React.createElement("span", {
    className: "wg-num wg-stat__value"
  }, value), sub && /*#__PURE__*/React.createElement("span", {
    className: "wg-stat__sub"
  }, sub)));
}
Object.assign(__ds_scope, { StatCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/StatCard.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/TerritoryCard.jsx
try { (() => {
function TerritoryCard({
  name,
  status = 'free',
  owner,
  players = [],
  note
}) {
  const max = Math.max(1, ...players.map(p => p.points));
  return /*#__PURE__*/React.createElement(__ds_scope.Card, {
    className: 'wg-terr' + (status === 'yours' ? ' wg-terr--yours' : '')
  }, /*#__PURE__*/React.createElement("div", {
    className: "wg-terr__head"
  }, /*#__PURE__*/React.createElement("h3", {
    className: "wg-terr__name"
  }, name), /*#__PURE__*/React.createElement(__ds_scope.StatusPill, {
    status: status
  })), owner ? /*#__PURE__*/React.createElement("div", {
    className: "wg-terr__owner"
  }, /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    name: owner,
    size: 24
  }), /*#__PURE__*/React.createElement("span", null, "Owned by ", /*#__PURE__*/React.createElement("b", null, owner))) : /*#__PURE__*/React.createElement("div", {
    className: "wg-terr__owner"
  }, "Nobody owns this yet. The next drink here claims it."), players.length > 0 && /*#__PURE__*/React.createElement("ul", {
    className: "wg-bars"
  }, players.map(p => /*#__PURE__*/React.createElement("li", {
    key: p.name
  }, /*#__PURE__*/React.createElement("span", null, p.name, p.you && ' (you)'), /*#__PURE__*/React.createElement("b", null, p.points), /*#__PURE__*/React.createElement(__ds_scope.ProgressBar, {
    value: p.points,
    max: max,
    thin: true,
    tone: p.name === owner ? status === 'yours' ? 'yours' : 'theirs' : p.you ? 'accent' : 'free'
  })))), note && /*#__PURE__*/React.createElement("div", {
    className: "wg-hint"
  }, note));
}
Object.assign(__ds_scope, { TerritoryCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/TerritoryCard.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/BoardLobby.jsx
try { (() => {
function LeaderboardScreen({
  demo = {}
}) {
  const [tab, setTab] = React.useState('season');
  const [loading, setLoading] = React.useState(false);
  const state = loading ? 'loading' : demo.board || 'ok';
  const me = PLAYERS.find(p => p.you),
    rank = PLAYERS.indexOf(me) + 1;
  const refresh = () => {
    setLoading(true);
    setTimeout(() => setLoading(false), 1200);
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '54px 0 120px'
    }
  }, /*#__PURE__*/React.createElement(ScreenHeader, {
    eyebrow: LOBBY.name + ' · Season 1',
    title: "Leaderboard",
    right: /*#__PURE__*/React.createElement(IconButton, {
      icon: "refresh",
      label: "Refresh",
      onClick: refresh
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px'
    }
  }, state === 'unavailable' ? /*#__PURE__*/React.createElement(Alert, {
    tone: "error",
    title: "Standings are unavailable",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "secondary",
      onClick: refresh
    }, "Retry")
  }, "We couldn't load the scores. Nothing is lost; try again in a moment.") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1.3fr 1fr',
      gap: 8
    }
  }, state === 'loading' ? [0, 1, 2].map(i => /*#__PURE__*/React.createElement(Skeleton, {
    key: i,
    h: 96,
    r: "var(--radius-lg)"
  })) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(StatCard, {
    accent: true,
    label: "Your rank",
    value: '#' + rank,
    sub: 'of ' + PLAYERS.length
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Season points",
    value: fmtPts(me.points),
    sub: '6.25 behind ' + PLAYERS[0].name
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Territories",
    value: me.terr,
    sub: "owned"
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      margin: '16px 0 4px'
    }
  }, /*#__PURE__*/React.createElement(SegmentedControl, {
    value: tab,
    onChange: setTab,
    options: [{
      value: 'season',
      label: 'Season'
    }, {
      value: 'territories',
      label: 'Territories'
    }]
  })), tab === 'season' ? /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: 6,
      marginTop: 10
    }
  }, state === 'loading' ? [0, 1, 2, 3].map(i => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'center',
      padding: 10
    }
  }, /*#__PURE__*/React.createElement(Skeleton, {
    w: 34,
    h: 34
  }), /*#__PURE__*/React.createElement(Skeleton, {
    w: 40,
    h: 40,
    r: 99
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(Skeleton, {
    w: "60%",
    h: 14
  })), /*#__PURE__*/React.createElement(Skeleton, {
    w: 44,
    h: 24
  }))) : PLAYERS.map((p, i) => /*#__PURE__*/React.createElement(PlayerRow, {
    key: p.name,
    rank: i + 1,
    name: p.name,
    you: p.you,
    score: fmtPts(p.points),
    sub: p.terr ? p.terr + (p.terr === 1 ? ' territory' : ' territories') : 'No territories'
  }))) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      marginTop: 10
    }
  }, TERRITORIES.filter(t => Object.keys(t.pts).length).slice(0, 6).map(t => /*#__PURE__*/React.createElement(TerritoryCard, {
    key: t.id,
    name: t.name,
    status: statusOf(t),
    owner: t.owner === ME ? 'You' : t.owner,
    players: Object.entries(t.pts).sort((a, b) => b[1] - a[1]).map(([n, v]) => ({
      name: n === ME ? 'You' : n,
      points: v,
      you: n === ME
    })),
    note: statusOf(t) === 'theirs' ? `You need ${plural(neededFor(t), 'more point')} to take it.` : statusOf(t) === 'yours' ? `You lead by ${plural(leadBy(t), 'point')}.` : null
  })), /*#__PURE__*/React.createElement(TerritoryCard, {
    name: "Rua dos Mouros",
    status: "free"
  })), /*#__PURE__*/React.createElement("div", {
    className: "wg-hint",
    style: {
      justifyContent: 'center',
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "info"
  }), "Owner bonuses are 0.25 per point, so totals can end in .25 / .5 / .75"))));
}
function LobbyCard({
  name,
  leader,
  active,
  test,
  ends,
  past,
  onOpen
}) {
  return /*#__PURE__*/React.createElement(Card, {
    variant: past ? 'muted' : undefined,
    style: {
      padding: 16,
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      ...(active ? {
        borderColor: 'var(--accent)',
        boxShadow: 'var(--shadow-card), inset 0 0 0 1px var(--accent)'
      } : null)
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      flexWrap: 'wrap'
    }
  }, active ? /*#__PURE__*/React.createElement(StatusPill, {
    status: "live"
  }, "Running") : /*#__PURE__*/React.createElement(StatusPill, {
    status: "closed",
    icon: "flag_check"
  }, "Finished"), test && /*#__PURE__*/React.createElement(StatusPill, {
    status: "test"
  }, "Test season \xB7 opens Wed")), /*#__PURE__*/React.createElement("div", {
    className: "wg-display",
    style: {
      fontSize: 26
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      fontSize: 14
    }
  }, leader ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Avatar, {
    name: leader,
    size: 32
  }), /*#__PURE__*/React.createElement("span", null, past ? 'Winner' : 'Leader', ": ", /*#__PURE__*/React.createElement("b", null, leader))) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
    className: "wg-avatar",
    style: {
      '--size': '32px',
      '--av-bg': 'var(--surface-raised)',
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "person_off",
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    className: "wg-muted"
  }, "No Leader yet"))), active ? /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Countdown, {
    seconds: ends,
    compact: true
  }), /*#__PURE__*/React.createElement("span", {
    className: "wg-muted",
    style: {
      fontSize: 12,
      textAlign: 'right'
    }
  }, "Ends", /*#__PURE__*/React.createElement("br", null), LOBBY.endsAt)) : /*#__PURE__*/React.createElement("span", {
    className: "wg-muted",
    style: {
      fontSize: 13
    }
  }, "Finished ", ends), /*#__PURE__*/React.createElement(Button, {
    variant: active ? 'primary' : 'secondary',
    block: true,
    onClick: onOpen
  }, past ? 'View results' : 'Open lobby'));
}
function LobbyScreen({
  go,
  demo = {}
}) {
  const [panel, setPanel] = React.useState(null);
  const [dur, setDur] = React.useState('1 month');
  const [code, setCode] = React.useState('');
  const empty = demo.lobby === 'empty';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '54px 0 120px'
    }
  }, /*#__PURE__*/React.createElement(ScreenHeader, {
    eyebrow: "Your lobbies",
    title: "Lobby"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: panel === 'create' ? 'primary' : 'secondary',
    icon: "add_circle",
    onClick: () => setPanel(panel === 'create' ? null : 'create')
  }, "Create"), /*#__PURE__*/React.createElement(Button, {
    variant: panel === 'join' ? 'primary' : 'secondary',
    icon: "key",
    onClick: () => setPanel(panel === 'join' ? null : 'join')
  }, "Join with code")), panel === 'create' && /*#__PURE__*/React.createElement(Card, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(TextInput, {
    label: "Lobby name",
    placeholder: "e.g. Thursday Crew"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "wg-label",
    style: {
      marginBottom: 8
    }
  }, "Duration"), /*#__PURE__*/React.createElement(SegmentedControl, {
    value: dur,
    onChange: setDur,
    options: ['1 week', '1 month', '3 months']
  })), /*#__PURE__*/React.createElement(Select, {
    label: "Timezone",
    icon: "public",
    options: ['Europe/Lisbon', 'Europe/London', 'Europe/Madrid']
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Test season",
    hint: "Opens Wednesday 08:00 instead of Thursday 18:00. Labelled everywhere."
  }), /*#__PURE__*/React.createElement(Button, {
    block: true,
    icon: "rocket_launch"
  }, "Create lobby")), panel === 'join' && /*#__PURE__*/React.createElement(Card, {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(TextInput, {
    label: "Invite code",
    placeholder: "6 characters",
    value: code,
    onChange: v => setCode(v.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6)),
    hint: code.length + ' / 6'
  }), /*#__PURE__*/React.createElement(Button, {
    block: true,
    disabled: code.length !== 6,
    icon: "login"
  }, "Join lobby")), demo.lobby === 'setup' && /*#__PURE__*/React.createElement(Alert, {
    tone: "error",
    title: "Lobby setup failed",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "secondary"
    }, "Retry")
  }, "Fridays League couldn't start. Check the timezone, then retry."), empty ? /*#__PURE__*/React.createElement(EmptyState, {
    icon: "group_add",
    title: "No lobby yet",
    action: /*#__PURE__*/React.createElement(Button, {
      icon: "add_circle",
      onClick: () => setPanel('create')
    }, "Create a lobby")
  }, "Create one for your group, or join with the 6-character code a friend sent you.") : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(SectionTitle, null, "Active"), /*#__PURE__*/React.createElement(LobbyCard, {
    active: true,
    name: LOBBY.name,
    leader: "ana.lx",
    ends: LOBBY.endsIn,
    onOpen: () => go('leaderboard')
  }), /*#__PURE__*/React.createElement(Card, {
    variant: "raised",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wg-stat__label"
  }, "Invite code"), /*#__PURE__*/React.createElement("div", {
    className: "wg-num",
    style: {
      fontSize: 26,
      letterSpacing: '.12em',
      marginTop: 4
    }
  }, LOBBY.code)), /*#__PURE__*/React.createElement(IconButton, {
    icon: "content_copy",
    label: "Copy code"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "share",
    label: "Share code",
    variant: "accent"
  })), /*#__PURE__*/React.createElement(LobbyCard, {
    active: true,
    test: true,
    name: "Erasmus Test Run",
    ends: 5 * 86400 + 3600
  }), /*#__PURE__*/React.createElement(SectionTitle, null, "Past"), /*#__PURE__*/React.createElement(LobbyCard, {
    past: true,
    name: "Freshers Week",
    leader: "joao_b",
    ends: "12 Oct 2026, 18:00 WEST"
  }))));
}
Object.assign(window, {
  LeaderboardScreen,
  LobbyScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/BoardLobby.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/CheckinScreen.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const LOC = {
  finding: {
    tone: 'info',
    icon: 'location_searching',
    title: 'Finding you…',
    body: 'Allow location access if your browser asks.',
    ok: false
  },
  found: {
    tone: 'success',
    icon: 'my_location',
    title: 'Location found',
    body: 'Accurate to ±12 m. Updates automatically.',
    ok: true
  },
  imprecise: {
    tone: 'warning',
    icon: 'location_disabled',
    title: 'Not precise enough',
    body: 'Only accurate to ±80 m (we need 50 m or better). Step outside or wait a moment.',
    ok: false
  },
  blocked: {
    tone: 'error',
    icon: 'location_off',
    title: 'Location is blocked',
    body: 'Open your browser settings → Site settings → Location → Allow, then reload.',
    ok: false
  },
  outside: {
    tone: 'info',
    icon: 'wrong_location',
    title: 'Outside all territories',
    body: 'Accurate to ±9 m. This drink earns season points only.',
    ok: true
  },
  stale: {
    tone: 'warning',
    icon: 'history',
    title: 'Reading too old',
    body: 'Your last location is over a minute old. Refreshing…',
    ok: false
  }
};
function LocationCard({
  state
}) {
  const l = LOC[state],
    t = TERRITORIES.find(x => x.id === CURRENT),
    s = statusOf(t),
    need = neededFor(t);
  return /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: 14,
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'grid',
      placeItems: 'center',
      width: 44,
      height: 44,
      borderRadius: 'var(--radius-md)',
      flex: 'none',
      background: `color-mix(in oklch, var(--${l.tone}) 16%, var(--surface))`,
      color: `var(--${l.tone})`
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: l.icon,
    fill: true,
    size: 24
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("b", {
    style: {
      fontSize: 15
    }
  }, l.title), /*#__PURE__*/React.createElement("div", {
    className: "wg-muted",
    style: {
      fontSize: 13,
      lineHeight: 1.35
    }
  }, l.body)), state === 'finding' || state === 'stale' ? /*#__PURE__*/React.createElement(Skeleton, {
    w: 24,
    h: 24,
    r: 99,
    style: {
      marginLeft: 'auto',
      flex: 'none'
    }
  }) : null), state === 'found' && /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid var(--border)',
      paddingTop: 12,
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "wg-stat__label"
  }, "Detected territory"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 18
    }
  }, t.name)), /*#__PURE__*/React.createElement(StatusPill, {
    status: s
  })), /*#__PURE__*/React.createElement("div", {
    className: "wg-terr__owner"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: t.owner,
    size: 26
  }), /*#__PURE__*/React.createElement("span", null, "Owned by ", /*#__PURE__*/React.createElement("b", null, t.owner), " \xB7 ", t.pts[t.owner], " pts vs your ", myPts(t))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700
    }
  }, "You need ", plural(need, 'more point'), " to take it."), /*#__PURE__*/React.createElement("div", {
    className: "wg-hint"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "percent"
  }), t.owner, " earns a 25% bonus on your drink here. Your points stay the same.")));
}
function CheckinSuccess({
  points,
  captured,
  onDone,
  onMap
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 30,
      background: 'var(--bg)',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 16,
      padding: 28,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "wg-pop",
    style: {
      display: 'grid',
      placeItems: 'center',
      width: 96,
      height: 96,
      borderRadius: '50%',
      background: 'var(--accent)',
      color: 'var(--on-accent)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: captured ? 'flag' : 'check',
    fill: true,
    size: 52
  })), /*#__PURE__*/React.createElement("div", {
    className: "wg-num wg-pop",
    style: {
      fontSize: 'var(--text-4xl)',
      color: 'var(--accent-ink)',
      animationDelay: '80ms'
    }
  }, "+", points), /*#__PURE__*/React.createElement("div", {
    className: "wg-eyebrow"
  }, "season points \xB7 +", points, " territory points"), captured && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "wg-display wg-pop",
    style: {
      fontSize: 'var(--text-2xl)',
      animationDelay: '160ms'
    }
  }, "You captured Shortys!"), /*#__PURE__*/React.createElement(StatusPill, {
    status: "yours"
  }, "Shortys is now yours"), /*#__PURE__*/React.createElement("div", {
    className: "wg-muted",
    style: {
      fontSize: 14,
      maxWidth: 290
    }
  }, "ana.lx also earned 0.75 season points as the previous owner. You kept all your points.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      width: '100%',
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    block: true,
    icon: "map",
    onClick: onMap
  }, "See it on the map"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    block: true,
    onClick: onDone
  }, "Done")));
}
function CheckinScreen({
  go,
  demo = {}
}) {
  const gate = demo.gate || 'open',
    loc = demo.loc || 'found',
    result = demo.result || 'success';
  const [shot, setShot] = React.useState(!!demo.captured);
  const [drink, setDrink] = React.useState('beer');
  const [size, setSize] = React.useState('large');
  const [done, setDone] = React.useState(null);
  const [err, setErr] = React.useState(null);
  const pts = drink === 'shot' ? POINTS.shot.standard : POINTS[drink][size];
  const sizes = ['small', 'medium', 'large'].map(v => ({
    value: v,
    label: v[0].toUpperCase() + v.slice(1),
    sub: VOLUMES[drink] ? VOLUMES[drink][v] + ' ml' : undefined
  }));
  const blockers = [gate !== 'open' && 'Scoring is not open', !shot && 'Take a photo first', !LOC[loc].ok && 'Waiting for an accurate location'].filter(Boolean);
  const submit = () => {
    if (result === 'success') {
      setDone({
        points: pts,
        captured: loc === 'found' && myPts(TERRITORIES[0]) + pts > 9
      });
    } else setErr(result);
  };
  const ERR = {
    save: ["Couldn't save your check-in", 'Check your connection. Your photo and choices are kept.'],
    duplicate: ['Already logged', 'You logged this drink a moment ago.'],
    accuracy: ['Location not accurate enough', 'Wait a moment, then submit again.']
  };
  if (gate !== 'open') {
    const G = {
      closed: ['schedule', 'Scoring is closed', 'Opens Thu 19 Nov at 18:00', 2 * 3600 + 18 * 60],
      cooldown: ['timer', 'Nice one. Catch your breath', 'Wait before your next check-in. Your photo and selections stay here.', 84],
      ended: ['emoji_events', 'This season has ended', 'ana.lx won Thursday Crew with 18.5 points. Start a new season from Lobby.', 0]
    }[gate];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '54px 0 120px'
      }
    }, /*#__PURE__*/React.createElement(ScreenHeader, {
      eyebrow: LOBBY.name,
      title: "Check in"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '0 20px'
      }
    }, /*#__PURE__*/React.createElement(EmptyState, {
      icon: G[0],
      title: G[1],
      action: gate === 'ended' ? /*#__PURE__*/React.createElement(Button, {
        variant: "secondary",
        onClick: () => go('lobby')
      }, "Go to Lobby") : G[3] ? /*#__PURE__*/React.createElement(Countdown, {
        seconds: G[3],
        inline: gate === 'cooldown'
      }) : null
    }, G[2])));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '54px 0 120px'
    }
  }, /*#__PURE__*/React.createElement(ScreenHeader, {
    eyebrow: LOBBY.name + ' · Thu 19 Nov 23:41',
    title: "Check in",
    right: demo.test ? /*#__PURE__*/React.createElement(StatusPill, {
      status: "test"
    }) : null
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(CameraFrame, {
    state: demo.camera === 'blocked' ? 'blocked' : shot ? 'captured' : 'live',
    onShutter: () => setShot(true),
    onRetake: () => setShot(false),
    onRetry: () => {}
  }), shot && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "wg-label",
    style: {
      marginBottom: 8
    }
  }, "Drink"), /*#__PURE__*/React.createElement(ChoiceTiles, {
    value: drink,
    onChange: setDrink,
    options: DRINKS,
    label: "Drink"
  })), drink !== 'shot' ? /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "wg-label",
    style: {
      marginBottom: 8
    }
  }, "Size"), /*#__PURE__*/React.createElement(SegmentedControl, {
    value: size,
    onChange: setSize,
    options: sizes,
    label: "Size"
  })) : /*#__PURE__*/React.createElement("div", {
    className: "wg-hint"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "info"
  }), "One shot serving. No size needed."), /*#__PURE__*/React.createElement(Card, {
    variant: "raised",
    style: {
      padding: 14,
      display: 'flex',
      alignItems: 'center',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "wg-num",
    style: {
      fontSize: 44,
      color: 'var(--accent-ink)'
    }
  }, "+", pts), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      lineHeight: 1.35
    }
  }, /*#__PURE__*/React.createElement("b", null, "season points"), /*#__PURE__*/React.createElement("div", {
    className: "wg-muted"
  }, "+", pts, " territory points if you're in a territory")))), /*#__PURE__*/React.createElement(LocationCard, {
    state: loc
  }), err && /*#__PURE__*/React.createElement(Alert, {
    tone: "error",
    title: ERR[err][0],
    action: /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      variant: "secondary",
      onClick: () => setErr(null)
    }, "Retry")
  }, ERR[err][1]), blockers.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "wg-hint",
    style: {
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "block"
  }), blockers[0]), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    block: true,
    icon: "send",
    disabled: blockers.length > 0,
    onClick: submit
  }, "Submit \xB7 +", pts), /*#__PURE__*/React.createElement("div", {
    className: "wg-hint",
    style: {
      justifyContent: 'center',
      textAlign: 'center'
    }
  }, "Shared only with your lobby with your username, time and territory.")), done && /*#__PURE__*/React.createElement(CheckinSuccess, _extends({}, done, {
    onDone: () => {
      setDone(null);
      setShot(false);
    },
    onMap: () => go('map')
  })));
}
Object.assign(window, {
  CheckinScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/CheckinScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/MapScreen.jsx
try { (() => {
function TerritoryDetail({
  t,
  here,
  onCheckin,
  onClose
}) {
  const s = statusOf(t),
    need = neededFor(t),
    lead = leadBy(t);
  const msg = s === 'free' ? 'Unclaimed: your drink claims it.' : s === 'yours' ? `You own it · leading by ${plural(lead, 'point')}.` : `You need ${plural(need, 'more point')} to take it.`;
  return /*#__PURE__*/React.createElement(FloatingPanel, {
    style: {
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wg-eyebrow",
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: here ? 'my_location' : 'location_on',
    size: 14
  }), here ? 'You are in' : 'Territory'), /*#__PURE__*/React.createElement("div", {
    className: "wg-display",
    style: {
      fontSize: 26,
      marginTop: 4
    }
  }, t.name)), /*#__PURE__*/React.createElement(StatusPill, {
    status: s
  }), !here && /*#__PURE__*/React.createElement(IconButton, {
    icon: "close",
    label: "Close",
    variant: "ghost",
    onClick: onClose,
    style: {
      marginTop: -8,
      marginRight: -8
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr 1fr',
      gap: 8,
      margin: '12px 0'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "wg-stat__label"
  }, "Owner"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      marginTop: 4,
      fontWeight: 750,
      fontSize: 14,
      minWidth: 0
    }
  }, t.owner ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Avatar, {
    name: t.owner,
    size: 22
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, t.owner === ME ? 'You' : t.owner)) : /*#__PURE__*/React.createElement("span", {
    className: "wg-muted"
  }, "Nobody"))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "wg-stat__label"
  }, "Your points"), /*#__PURE__*/React.createElement("div", {
    className: "wg-num",
    style: {
      fontSize: 22,
      marginTop: 4
    }
  }, myPts(t))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "wg-stat__label"
  }, s === 'theirs' ? 'To take it' : s === 'yours' ? 'Your lead' : 'To claim'), /*#__PURE__*/React.createElement("div", {
    className: "wg-num",
    style: {
      fontSize: 22,
      marginTop: 4,
      color: 'var(--accent-ink)'
    }
  }, s === 'theirs' ? '+' + need : s === 'yours' ? '+' + lead : '+1'))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 650
    }
  }, msg), s === 'theirs' && /*#__PURE__*/React.createElement("div", {
    className: "wg-hint",
    style: {
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "percent"
  }), t.owner, " earns a 25% bonus when you drink here."), here && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    block: true,
    icon: "add_a_photo",
    onClick: onCheckin
  }, "Check in here")));
}
function TerritorySheet({
  onClose,
  onPick
}) {
  const order = {
    yours: 0,
    theirs: 1,
    free: 2
  };
  const rows = [...TERRITORIES].sort((a, b) => order[statusOf(a)] - order[statusOf(b)] || a.name.localeCompare(b.name));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      zIndex: 20,
      background: 'rgba(0,0,0,.35)',
      display: 'flex',
      alignItems: 'flex-end'
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: "wg-card",
    onClick: e => e.stopPropagation(),
    style: {
      width: '100%',
      maxHeight: '72%',
      overflow: 'auto',
      borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0',
      padding: '8px 16px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 40,
      height: 5,
      borderRadius: 9,
      background: 'var(--border)',
      margin: '4px auto 10px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontSize: 18,
      fontWeight: 800
    }
  }, "All territories"), /*#__PURE__*/React.createElement(IconButton, {
    icon: "close",
    label: "Close",
    variant: "ghost",
    onClick: onClose
  })), /*#__PURE__*/React.createElement(MapLegend, {
    style: {
      margin: '6px 0 10px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "wg-list"
  }, rows.map(t => {
    const s = statusOf(t);
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      className: "wg-listrow",
      onClick: () => onPick(t.id),
      style: {
        background: 'none',
        border: 0,
        borderBottom: '1px solid var(--border)',
        color: 'inherit',
        font: 'inherit',
        textAlign: 'left',
        cursor: 'pointer',
        width: '100%'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 10,
        height: 36,
        borderRadius: 4,
        background: `var(--territory-${s})`,
        flex: 'none'
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 750,
        fontSize: 15
      }
    }, t.name), /*#__PURE__*/React.createElement("div", {
      className: "wg-row__sub"
    }, t.owner ? t.owner === ME ? 'Yours' : 'Owned by ' + t.owner : 'Unclaimed', " \xB7 you have ", myPts(t))), /*#__PURE__*/React.createElement("span", {
      className: "wg-muted",
      style: {
        fontSize: 13,
        fontWeight: 700
      }
    }, s === 'theirs' ? '+' + neededFor(t) + ' to take' : s === 'free' ? 'Claim' : 'Owned'));
  }))));
}
function MapScreen({
  go,
  mapStyle,
  w = 390,
  h = 844
}) {
  const [focus, setFocus] = React.useState('Bairro Alto');
  const [view, setView] = React.useState(VIEWS['Bairro Alto']);
  const [sel, setSel] = React.useState(null);
  const [sheet, setSheet] = React.useState(false);
  const yours = TERRITORIES.filter(t => statusOf(t) === 'yours').length,
    free = TERRITORIES.filter(t => statusOf(t) === 'free').length,
    theirs = TERRITORIES.length - yours - free;
  const pick = f => {
    setFocus(f);
    setView(VIEWS[f]);
  };
  const t = TERRITORIES.find(x => x.id === (sel || CURRENT));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0
    }
  }, /*#__PURE__*/React.createElement(MapView, {
    view: view,
    width: w,
    height: h,
    mapStyle: mapStyle,
    selected: sel || CURRENT,
    onSelect: id => setSel(id === CURRENT ? null : id),
    onPan: v => {
      setView(v);
      setFocus(null);
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 54,
      left: 12,
      right: 12,
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(FloatingPanel, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '10px 10px 10px 14px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      fontSize: 16,
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, LOBBY.name, /*#__PURE__*/React.createElement("span", {
    className: "wg-pill wg-pill--live",
    style: {
      height: 22,
      fontSize: 11
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bolt"
  }), "Live")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      fontSize: 13,
      fontWeight: 650,
      marginTop: 3,
      color: 'var(--text-muted)',
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", {
    className: "wg-num",
    style: {
      color: 'var(--territory-yours)',
      fontSize: 15
    }
  }, yours), " / ", TERRITORIES.length, " yours"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text)'
    }
  }, theirs), " rival"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text)'
    }
  }, free), " free"))), /*#__PURE__*/React.createElement(IconButton, {
    icon: "format_list_bulleted",
    label: "All territories",
    onClick: () => setSheet(true)
  })), /*#__PURE__*/React.createElement(ChipGroup, {
    floating: true,
    value: focus,
    onChange: pick,
    options: [{
      value: 'Me',
      label: 'Me',
      icon: 'my_location'
    }, 'Bairro Alto', 'Lisbon', 'Nova SBE', 'All']
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 12,
      right: 12,
      bottom: 100
    }
  }, /*#__PURE__*/React.createElement(TerritoryDetail, {
    t: t,
    here: !sel,
    onCheckin: () => go('checkin'),
    onClose: () => setSel(null)
  })), sheet && /*#__PURE__*/React.createElement(TerritorySheet, {
    onClose: () => setSheet(false),
    onPick: id => {
      setSheet(false);
      setSel(id === CURRENT ? null : id);
      const x = TERRITORIES.find(t => t.id === id);
      setView({
        lat: x.lat,
        lng: x.lng,
        z: x.id === 'nova-sbe' ? 16.4 : 17.4
      });
      setFocus(null);
    }
  }));
}
Object.assign(window, {
  MapScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/MapScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/MapView.jsx
try { (() => {
// Slippy-map stand-in for the deck.gl + Carto map. Preview uses Esri Canvas gray tiles (Carto raster tiles need an API key outside pydeck).
const TILE = 256;
function mapProj(lat, lng, z) {
  const s = TILE * Math.pow(2, z),
    sin = Math.sin(lat * Math.PI / 180);
  return [(lng + 180) / 360 * s, (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * s];
}
function mapUnproj(x, y, z) {
  const s = TILE * Math.pow(2, z),
    lng = x / s * 360 - 180,
    n = Math.PI - 2 * Math.PI * y / s;
  return [180 / Math.PI * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))), lng];
}
function polyFor(t) {
  let h = 0;
  for (const c of t.id) h = h * 33 + c.charCodeAt(0) >>> 0;
  const pts = [],
    n = 6,
    rot = h % 60 * Math.PI / 180;
  for (let i = 0; i < n; i++) {
    const j = 0.78 + (h >> i * 3 & 7) / 20,
      a = rot + i * 2 * Math.PI / n;
    pts.push([t.lat + Math.sin(a) * t.r * j / 111320, t.lng + Math.cos(a) * t.r * j / (111320 * Math.cos(t.lat * Math.PI / 180))]);
  }
  return pts;
}
const POLYS = {};
function MapView({
  view,
  width,
  height,
  mapStyle,
  selected,
  onSelect,
  me = ME_POS,
  onPan,
  fit = 1
}) {
  const {
    lat,
    lng,
    z
  } = view;
  const zi = Math.max(0, Math.min(16, Math.round(z))),
    scale = Math.pow(2, z - zi);
  const [cx, cy] = mapProj(lat, lng, zi);
  const vw = width / scale,
    vh = height / scale,
    x0 = cx - vw / 2,
    y0 = cy - vh / 2;
  const tiles = [];
  for (let tx = Math.floor(x0 / TILE); tx <= Math.floor((x0 + vw) / TILE); tx++) for (let ty = Math.floor(y0 / TILE); ty <= Math.floor((y0 + vh) / TILE); ty++) tiles.push(/*#__PURE__*/React.createElement("img", {
    key: tx + '_' + ty,
    alt: "",
    draggable: false,
    src: `https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_${mapStyle === 'dark' ? 'Dark' : 'Light'}_Gray_Base/MapServer/tile/${zi}/${ty}/${tx}`,
    style: {
      position: 'absolute',
      left: tx * TILE - x0,
      top: ty * TILE - y0,
      width: TILE,
      height: TILE
    }
  }));
  const [fx, fy] = mapProj(lat, lng, z);
  const toPx = (la, ln) => {
    const [x, y] = mapProj(la, ln, z);
    return [x - fx + width / 2, y - fy + height / 2];
  };
  const mPerPx = 156543.03 * Math.cos(lat * Math.PI / 180) / Math.pow(2, z);
  const drag = React.useRef(null);
  const down = e => {
    drag.current = {
      x: e.clientX,
      y: e.clientY,
      lat,
      lng,
      moved: false
    };
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const move = e => {
    const d = drag.current;
    if (!d || !onPan) return;
    const dx = (e.clientX - d.x) / fit,
      dy = (e.clientY - d.y) / fit;
    if (Math.abs(dx) + Math.abs(dy) > 4) d.moved = true;
    if (d.moved) {
      const [px, py] = mapProj(d.lat, d.lng, z);
      const [la, ln] = mapUnproj(px - dx, py - dy, z);
      onPan({
        lat: la,
        lng: ln,
        z
      });
    }
  };
  const up = () => {
    setTimeout(() => {
      drag.current = null;
    }, 0);
  };
  const click = id => {
    if (drag.current && drag.current.moved) return;
    onSelect && onSelect(id);
  };
  const [mx, my] = toPx(me.lat, me.lng);
  return /*#__PURE__*/React.createElement("div", {
    onPointerDown: down,
    onPointerMove: move,
    onPointerUp: up,
    style: {
      position: 'absolute',
      inset: 0,
      overflow: 'hidden',
      background: 'var(--surface-raised)',
      touchAction: 'none',
      cursor: 'grab'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      width: vw,
      height: vh,
      transform: `scale(${scale})`,
      transformOrigin: '0 0'
    }
  }, tiles), /*#__PURE__*/React.createElement("svg", {
    width: width,
    height: height,
    style: {
      position: 'absolute',
      inset: 0
    }
  }, TERRITORIES.map(t => {
    const s = statusOf(t),
      pts = (POLYS[t.id] ||= polyFor(t)).map(p => toPx(p[0], p[1]));
    const c = `var(--territory-${s})`,
      sel = selected === t.id;
    return /*#__PURE__*/React.createElement("g", {
      key: t.id,
      onClick: () => click(t.id),
      style: {
        cursor: 'pointer'
      }
    }, /*#__PURE__*/React.createElement("polygon", {
      points: pts.map(p => p.join(',')).join(' '),
      style: {
        fill: c,
        fillOpacity: sel ? .55 : .36,
        stroke: sel ? 'var(--text)' : c,
        strokeWidth: sel ? 3.5 : 2.5,
        strokeLinejoin: 'round'
      }
    }));
  }), z >= 16.4 && TERRITORIES.map(t => {
    const [x, y] = toPx(t.lat, t.lng);
    return /*#__PURE__*/React.createElement("text", {
      key: t.id,
      x: x,
      y: y + 4,
      textAnchor: "middle",
      pointerEvents: "none",
      style: {
        font: '800 11px var(--font-body)',
        fill: 'var(--text)',
        stroke: 'var(--bg)',
        strokeWidth: 3.5,
        paintOrder: 'stroke',
        strokeLinejoin: 'round'
      }
    }, t.name);
  }), /*#__PURE__*/React.createElement("circle", {
    cx: mx,
    cy: my,
    r: Math.max(9, me.acc / mPerPx),
    style: {
      fill: 'var(--you-dot)',
      fillOpacity: .16,
      stroke: 'var(--you-dot)',
      strokeOpacity: .4
    }
  }), /*#__PURE__*/React.createElement("circle", {
    cx: mx,
    cy: my,
    r: 8,
    style: {
      fill: 'var(--you-dot)',
      transformBox: 'fill-box',
      transformOrigin: 'center',
      animation: 'wg-pulse 2s ease-out infinite'
    }
  }), /*#__PURE__*/React.createElement("circle", {
    cx: mx,
    cy: my,
    r: 8,
    style: {
      fill: 'var(--you-dot)',
      stroke: '#fff',
      strokeWidth: 3
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      right: 6,
      bottom: 2,
      fontSize: 9,
      color: 'var(--text-muted)',
      opacity: .8,
      pointerEvents: 'none'
    }
  }, "Esri, HERE, Garmin, \xA9 OpenStreetMap"));
}
Object.assign(window, {
  MapView,
  mapProj
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/MapView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/Phone.jsx
try { (() => {
const DIRS = window.WGP_DIRECTIONS;
function StatusBar() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 0,
      left: 0,
      right: 0,
      height: 47,
      zIndex: 40,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '4px 28px 0 34px',
      fontWeight: 700,
      fontSize: 16,
      pointerEvents: 'none',
      color: 'var(--text)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "23:41"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: 5,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "signal_cellular_alt",
    size: 18
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "wifi",
    size: 18
  }), /*#__PURE__*/React.createElement(Icon, {
    name: "battery_5_bar",
    size: 20,
    style: {
      transform: 'rotate(90deg)'
    }
  })));
}
function Phone({
  theme = 'hyro-night',
  screen,
  setScreen,
  demo = {},
  frame = true
}) {
  const dir = DIRS.find(d => d.id === theme) || DIRS[0];
  const go = s => setScreen(s);
  const S = {
    map: MapScreen,
    checkin: CheckinScreen,
    leaderboard: LeaderboardScreen,
    lobby: LobbyScreen,
    profile: ProfileScreen,
    history: MemoriesScreen,
    login: LoginScreen
  }[screen] || MapScreen;
  const scrollRef = React.useRef(null);
  React.useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
  }, [screen]);
  return /*#__PURE__*/React.createElement("div", {
    "data-theme": theme,
    className: "wg-app",
    "data-screen-label": screen,
    style: {
      position: 'relative',
      width: 390,
      height: 844,
      overflow: 'hidden',
      borderRadius: frame ? 48 : 0,
      boxShadow: frame ? '0 0 0 10px #0a0a0a, 0 0 0 11px #333, 0 30px 80px rgba(0,0,0,.45)' : 'none',
      flex: 'none'
    }
  }, /*#__PURE__*/React.createElement(StatusBar, null), screen === 'map' ? /*#__PURE__*/React.createElement(S, {
    go: go,
    demo: demo,
    mapStyle: dir.scheme
  }) : /*#__PURE__*/React.createElement("div", {
    ref: scrollRef,
    style: {
      height: '100%',
      overflowY: 'auto',
      scrollbarWidth: 'none'
    }
  }, /*#__PURE__*/React.createElement(S, {
    key: screen + JSON.stringify(demo),
    go: go,
    demo: demo
  })), screen !== 'login' && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      left: 10,
      right: 10,
      bottom: 10,
      zIndex: 25
    }
  }, /*#__PURE__*/React.createElement(BottomNav, {
    active: screen,
    onNavigate: go
  })));
}
Object.assign(window, {
  Phone,
  DIRS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/Phone.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/ProfileMemories.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function BackBar({
  onBack,
  title
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 4,
      padding: '0 8px 6px'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    icon: "arrow_back",
    onClick: onBack
  }, "Back to Profile"));
}
function MenuRow({
  icon,
  label,
  sub,
  onClick,
  danger
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    className: "wg-listrow",
    style: {
      width: '100%',
      background: 'none',
      border: 0,
      borderBottom: '1px solid var(--border)',
      color: danger ? 'var(--error)' : 'inherit',
      font: 'inherit',
      cursor: 'pointer',
      textAlign: 'left',
      padding: '8px 4px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'grid',
      placeItems: 'center',
      width: 40,
      height: 40,
      borderRadius: 'var(--radius-md)',
      background: danger ? 'transparent' : 'var(--surface-raised)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 15
    }
  }, label), sub && /*#__PURE__*/React.createElement("div", {
    className: "wg-row__sub"
  }, sub)), !danger && /*#__PURE__*/React.createElement(Icon, {
    name: "chevron_right",
    style: {
      color: 'var(--text-muted)'
    }
  }));
}
function ProfileMain({
  setView,
  go
}) {
  const me = PLAYERS.find(p => p.you);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 10,
      padding: '10px 20px 18px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: ME,
    size: 104,
    ring: true
  }), /*#__PURE__*/React.createElement("div", {
    className: "wg-display",
    style: {
      fontSize: 'var(--text-2xl)'
    }
  }, "@", ME), /*#__PURE__*/React.createElement("div", {
    className: "wg-muted",
    style: {
      fontSize: 14,
      marginTop: -4
    }
  }, "Rita Fonseca \xB7 only your username is public")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr 1fr',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(StatCard, {
    accent: true,
    label: "Rank",
    value: "#2",
    sub: LOBBY.name
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Points",
    value: fmtPts(me.points),
    sub: "this season"
  }), /*#__PURE__*/React.createElement(StatCard, {
    label: "Owned",
    value: me.terr,
    sub: "territories"
  })), /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: '4px 12px',
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement(MenuRow, {
    icon: "edit",
    label: "Edit profile",
    sub: "Username, name, picture",
    onClick: () => setView('edit')
  }), /*#__PURE__*/React.createElement(MenuRow, {
    icon: "group",
    label: "Friends",
    sub: "2 requests waiting",
    onClick: () => setView('friends')
  }), /*#__PURE__*/React.createElement(MenuRow, {
    icon: "insights",
    label: "My stats",
    sub: "Points, rank, territories",
    onClick: () => go('leaderboard')
  }), /*#__PURE__*/React.createElement(MenuRow, {
    icon: "sports_esports",
    label: "Tonight's minigame",
    sub: "Win a special item",
    onClick: () => setView('minigame')
  }), /*#__PURE__*/React.createElement(MenuRow, {
    icon: "shield_lock",
    label: "Account & security",
    sub: "Change password",
    onClick: () => setView('security')
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      borderBottom: 0
    }
  }, /*#__PURE__*/React.createElement(MenuRow, {
    icon: "logout",
    label: "Log out",
    danger: true,
    onClick: () => go('login')
  })))));
}
function EditProfile({
  back
}) {
  const [pic, setPic] = React.useState(true);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("h1", {
    className: "wg-display",
    style: {
      fontSize: 'var(--text-2xl)',
      padding: '0 4px'
    }
  }, "Edit profile"), /*#__PURE__*/React.createElement(Card, {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 96,
      height: 96,
      borderRadius: '50%',
      flex: 'none',
      overflow: 'hidden',
      boxShadow: '0 0 0 3px var(--accent)',
      display: 'grid',
      placeItems: 'center',
      background: 'var(--surface-raised)'
    }
  }, pic ? /*#__PURE__*/React.createElement(Icon, {
    name: "face",
    size: 52,
    style: {
      color: 'var(--text-muted)'
    }
  }) : /*#__PURE__*/React.createElement(Avatar, {
    name: ME,
    size: 96
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "secondary",
    icon: "upload"
  }, "Upload"), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "secondary",
    icon: "photo_camera"
  }, "Take")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost",
    icon: "swap_horiz"
  }, "Replace"), pic && /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "destructive",
    icon: "delete",
    onClick: () => setPic(false)
  }, "Remove")))), /*#__PURE__*/React.createElement("div", {
    className: "wg-hint",
    style: {
      marginTop: -6
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "crop"
  }), "Circular crop preview. Removing falls back to your initials."), /*#__PURE__*/React.createElement(TextInput, {
    label: "Username",
    icon: "alternate_email",
    defaultValue: ME,
    hint: "Public. Shown on leaderboards and photos."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(TextInput, {
    label: "First name",
    defaultValue: "Rita"
  }), /*#__PURE__*/React.createElement(TextInput, {
    label: "Surname",
    defaultValue: "Fonseca"
  })), /*#__PURE__*/React.createElement(TextInput, {
    label: "Email",
    defaultValue: "rita@novasbe.pt",
    readOnly: true
  }), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    block: true,
    icon: "check",
    onClick: back
  }, "Save"));
}
function Friends() {
  const [q, setQ] = React.useState('an');
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("h1", {
    className: "wg-display",
    style: {
      fontSize: 'var(--text-2xl)',
      padding: '0 4px'
    }
  }, "Friends"), /*#__PURE__*/React.createElement(TextInput, {
    icon: "search",
    placeholder: "Search usernames",
    value: q,
    onChange: setQ
  }), q && /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: '4px 12px'
    }
  }, ['ana.lx', 'andre_m'].map(n => /*#__PURE__*/React.createElement("div", {
    key: n,
    className: "wg-listrow"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: n
  }), /*#__PURE__*/React.createElement("b", {
    style: {
      flex: 1
    }
  }, n), n === 'andre_m' ? /*#__PURE__*/React.createElement("span", {
    className: "wg-hint"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "timer"
  }), "Declined \xB7 retry in 8 min") : /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: sent ? 'ghost' : 'primary',
    icon: sent ? 'check' : 'person_add',
    onClick: () => setSent(true)
  }, sent ? 'Sent' : 'Add')))), /*#__PURE__*/React.createElement(SectionTitle, null, "Requests"), /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: '4px 12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wg-listrow"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "mia.santos"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("b", null, "mia.santos"), /*#__PURE__*/React.createElement("div", {
    className: "wg-row__sub"
  }, "wants to be friends")), /*#__PURE__*/React.createElement(IconButton, {
    icon: "close",
    label: "Decline"
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "check",
    label: "Accept",
    variant: "accent"
  })), /*#__PURE__*/React.createElement("div", {
    className: "wg-listrow"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "tomas.p"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("b", null, "tomas.p"), /*#__PURE__*/React.createElement("div", {
    className: "wg-row__sub"
  }, "Outgoing \xB7 pending")), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "ghost"
  }, "Cancel"))), /*#__PURE__*/React.createElement(SectionTitle, {
    right: /*#__PURE__*/React.createElement("span", {
      className: "wg-hint"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "lock"
    }), "Private")
  }, "Your friends \xB7 2"), /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: '4px 12px'
    }
  }, ['ana.lx', 'joao_b'].map(n => /*#__PURE__*/React.createElement("div", {
    key: n,
    className: "wg-listrow"
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: n
  }), /*#__PURE__*/React.createElement("b", {
    style: {
      flex: 1
    }
  }, n), /*#__PURE__*/React.createElement(Button, {
    size: "sm",
    variant: "destructive"
  }, "Remove")))));
}
function Security() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("h1", {
    className: "wg-display",
    style: {
      fontSize: 'var(--text-2xl)',
      padding: '0 4px'
    }
  }, "Account & security"), /*#__PURE__*/React.createElement(PasswordInput, {
    label: "Current password"
  }), /*#__PURE__*/React.createElement(PasswordInput, {
    label: "New password",
    hint: "At least 8 characters"
  }), /*#__PURE__*/React.createElement(PasswordInput, {
    label: "Confirm new password"
  }), /*#__PURE__*/React.createElement(Alert, {
    tone: "info",
    title: "Signs you out everywhere"
  }, "Changing your password logs out all your devices."), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    block: true,
    icon: "key"
  }, "Change password"));
}
function Minigame({
  demo
}) {
  const [phase, setPhase] = React.useState(demo.mini || 'start');
  const ITEMS = [{
    icon: 'bolt',
    name: '2× multiplier',
    sub: 'Next drink counts double'
  }, {
    icon: 'shield',
    name: 'Territory shield',
    sub: '1 hour of protection'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("h1", {
    className: "wg-display",
    style: {
      fontSize: 'var(--text-2xl)',
      padding: '0 4px'
    }
  }, "Reaction test"), phase === 'start' && /*#__PURE__*/React.createElement(EmptyState, {
    icon: "sports_esports",
    title: "One go per game night",
    action: /*#__PURE__*/React.createElement(Button, {
      size: "lg",
      icon: "play_arrow",
      onClick: () => setPhase('result')
    }, "Start")
  }, "Tap the moment the screen flashes. Win an item, not points."), phase === 'played' && /*#__PURE__*/React.createElement(EmptyState, {
    icon: "bedtime",
    title: "Already played tonight",
    action: /*#__PURE__*/React.createElement(Countdown, {
      seconds: 18 * 3600,
      inline: true
    })
  }, "Your next go unlocks when Thursday's window opens."), phase === 'result' && /*#__PURE__*/React.createElement(Card, {
    style: {
      textAlign: 'center',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 10,
      padding: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wg-num wg-pop",
    style: {
      fontSize: 'var(--text-4xl)',
      color: 'var(--accent-ink)'
    }
  }, "213", /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 22
    }
  }, "ms")), /*#__PURE__*/React.createElement("span", {
    className: "wg-pop",
    style: {
      display: 'grid',
      placeItems: 'center',
      width: 72,
      height: 72,
      borderRadius: 'var(--radius-lg)',
      background: 'var(--accent)',
      color: 'var(--on-accent)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bolt",
    fill: true,
    size: 40
  })), /*#__PURE__*/React.createElement("b", {
    style: {
      fontSize: 18
    }
  }, "You won a 2\xD7 multiplier"), /*#__PURE__*/React.createElement("span", {
    className: "wg-muted",
    style: {
      fontSize: 14
    }
  }, "Added to your inventory."), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    onClick: () => setPhase('played')
  }, "Done")), /*#__PURE__*/React.createElement(SectionTitle, null, "Inventory"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 8
    }
  }, ITEMS.map(i => /*#__PURE__*/React.createElement(Card, {
    key: i.name,
    style: {
      padding: 14
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: i.icon,
    fill: true,
    size: 28,
    style: {
      color: 'var(--accent-ink)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 800,
      marginTop: 8
    }
  }, i.name), /*#__PURE__*/React.createElement("div", {
    className: "wg-row__sub"
  }, i.sub)))));
}
function ProfileScreen({
  go,
  demo = {}
}) {
  const [view, setView] = React.useState(demo.profile || 'main');
  const back = () => setView('main');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '54px 0 120px'
    }
  }, view === 'main' ? /*#__PURE__*/React.createElement(ProfileMain, {
    setView: setView,
    go: go
  }) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(BackBar, {
    onBack: back
  }), view === 'edit' && /*#__PURE__*/React.createElement(EditProfile, {
    back: back
  }), view === 'friends' && /*#__PURE__*/React.createElement(Friends, null), view === 'security' && /*#__PURE__*/React.createElement(Security, null), view === 'minigame' && /*#__PURE__*/React.createElement(Minigame, {
    demo: demo
  })));
}
function MemoriesScreen({
  demo = {}
}) {
  const [page, setPage] = React.useState(0);
  const [open, setOpen] = React.useState(null);
  const pages = Math.ceil(MEMORIES.length / 4),
    list = MEMORIES.slice(page * 4, page * 4 + 4);
  if (demo.memories === 'empty') return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '54px 0 120px'
    }
  }, /*#__PURE__*/React.createElement(ScreenHeader, {
    eyebrow: LOBBY.name,
    title: "Memories"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px'
    }
  }, /*#__PURE__*/React.createElement(EmptyState, {
    icon: "photo_camera",
    title: "No drinks yet"
  }, "The first check-in of the night shows up here for the whole lobby.")));
  if (open) {
    const m = open,
      t = m.t && TERRITORIES.find(x => x.id === m.t);
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '54px 0 120px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '0 8px 6px'
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "ghost",
      icon: "arrow_back",
      onClick: () => setOpen(null)
    }, "Memories")), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '0 16px',
        display: 'flex',
        flexDirection: 'column',
        gap: 14
      }
    }, /*#__PURE__*/React.createElement(PhotoCard, _extends({}, m, {
      status: t ? statusOf(t) : 'free'
    })), m.mine && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Alert, {
      tone: "info",
      title: "Wrong drink or size?",
      action: /*#__PURE__*/React.createElement(Countdown, {
        inline: true,
        seconds: 96
      })
    }, "You can correct it for 2 minutes after posting."), /*#__PURE__*/React.createElement(SegmentedControl, {
      value: "large",
      options: [{
        value: 'small',
        label: 'Small',
        sub: '250 ml'
      }, {
        value: 'medium',
        label: 'Medium',
        sub: '330 ml'
      }, {
        value: 'large',
        label: 'Large',
        sub: '500 ml'
      }]
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "destructive",
      block: true,
      icon: "delete"
    }, "Delete photo"), /*#__PURE__*/React.createElement("div", {
      className: "wg-hint",
      style: {
        justifyContent: 'center',
        textAlign: 'center'
      }
    }, "Points stay if you delete. Photos expire 30 days after the season."))));
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '54px 0 120px'
    }
  }, /*#__PURE__*/React.createElement(ScreenHeader, {
    eyebrow: LOBBY.name + ' · newest first',
    title: "Memories"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px',
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 10
    }
  }, list.map((m, i) => {
    const t = m.t && TERRITORIES.find(x => x.id === m.t);
    return /*#__PURE__*/React.createElement(PhotoCard, _extends({
      key: i
    }, m, {
      status: t ? statusOf(t) : 'free',
      onOpen: () => setOpen(m)
    }));
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 12,
      marginTop: 14
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    icon: "chevron_left",
    label: "Newer",
    onClick: () => setPage(Math.max(0, page - 1))
  }), /*#__PURE__*/React.createElement("span", {
    className: "wg-muted",
    style: {
      fontSize: 14,
      fontWeight: 700
    }
  }, "Page ", page + 1, " of ", pages), /*#__PURE__*/React.createElement(IconButton, {
    icon: "chevron_right",
    label: "Older",
    onClick: () => setPage(Math.min(pages - 1, page + 1))
  })));
}
function LoginScreen({
  go,
  demo = {}
}) {
  const [mode, setMode] = React.useState('login');
  const e = demo.auth;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '80px 20px 40px',
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "wg-display",
    style: {
      fontSize: 'var(--text-4xl)',
      color: 'var(--accent-ink)'
    }
  }, "WeGoPub"), /*#__PURE__*/React.createElement("div", {
    className: "wg-muted",
    style: {
      fontSize: 16,
      marginTop: -6
    }
  }, "Every drink counts. Take the city."), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10
    }
  }, /*#__PURE__*/React.createElement(SegmentedControl, {
    value: mode,
    onChange: setMode,
    options: [{
      value: 'login',
      label: 'Log in'
    }, {
      value: 'signup',
      label: 'Create account'
    }]
  })), e === 'locked' && /*#__PURE__*/React.createElement(Alert, {
    tone: "warning",
    title: "Too many attempts",
    action: /*#__PURE__*/React.createElement(Countdown, {
      inline: true,
      seconds: 299
    })
  }, "Wait a few minutes, then try again."), e === 'down' && /*#__PURE__*/React.createElement(Alert, {
    tone: "error",
    title: "Service unavailable"
  }, "We can't reach the server. Try again in a moment."), mode === 'signup' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(TextInput, {
    label: "First name"
  }), /*#__PURE__*/React.createElement(TextInput, {
    label: "Surname"
  })), /*#__PURE__*/React.createElement(TextInput, {
    label: "Username",
    icon: "alternate_email",
    hint: "The only thing other players see"
  })), /*#__PURE__*/React.createElement(TextInput, {
    label: "Email",
    type: "email",
    icon: "mail",
    defaultValue: "rita@novasbe.pt"
  }), /*#__PURE__*/React.createElement(PasswordInput, {
    label: "Password",
    defaultValue: "wrongpass",
    error: e === 'wrong' && mode === 'login' ? 'Wrong email or password.' : undefined,
    hint: mode === 'signup' ? 'At least 8 characters' : undefined
  }), mode === 'signup' && /*#__PURE__*/React.createElement(PasswordInput, {
    label: "Confirm password"
  }), mode === 'login' && /*#__PURE__*/React.createElement(Checkbox, {
    label: "Remember me on this device",
    hint: "30 days",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Button, {
    size: "lg",
    block: true,
    onClick: () => go('map')
  }, mode === 'login' ? 'Log in' : 'Create account'));
}
Object.assign(window, {
  ProfileScreen,
  MemoriesScreen,
  LoginScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/ProfileMemories.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/data.jsx
try { (() => {
// Mock game state + shared helpers for the WeGoPub UI kit.
const DS = window.WeGoPubDesignSystem_71f296 || {};
Object.assign(window, DS);
const ME = 'ritafromlx';
const LOBBY = {
  name: 'Thursday Crew',
  code: 'K7P2QX',
  endsIn: 3 * 86400 + 4 * 3600 + 12 * 60,
  endsAt: 'Sun 6 Dec 2026, 18:00 WET'
};
const PLAYERS = [{
  name: 'ana.lx',
  points: 18.5,
  terr: 6
}, {
  name: ME,
  points: 12.25,
  terr: 3,
  you: true
}, {
  name: 'joao_b',
  points: 9,
  terr: 1
}, {
  name: 'mia.santos',
  points: 4.75,
  terr: 0
}, {
  name: 'tomas.p',
  points: 2,
  terr: 0
}];
// [id, name, lat, lng, radius m, owner, {player: territory points}]
const T = (id, name, lat, lng, r, owner, pts = {}) => ({
  id,
  name,
  lat,
  lng,
  r,
  owner,
  pts
});
const TERRITORIES = [T('shortys', 'Shortys', 38.71228, -9.14492, 34, 'ana.lx', {
  'ana.lx': 9,
  [ME]: 7,
  joao_b: 2
}), T('le-pub', 'Le Pub', 38.71155, -9.14435, 30, 'ana.lx', {
  'ana.lx': 5,
  [ME]: 1
}), T('party-street', 'Party Street', 38.71200, -9.14610, 36, 'ana.lx', {
  'ana.lx': 6,
  joao_b: 4
}), T('rua-da-rosa', 'Rua da Rosa', 38.71335, -9.14660, 34, ME, {
  [ME]: 8,
  'ana.lx': 3
}), T('rua-dos-mouros', 'Rua dos Mouros', 38.71345, -9.14455, 30, null), T('cheers-irish-pub', 'Cheers Irish Pub', 38.71440, -9.14540, 30, 'joao_b', {
  joao_b: 4
}), T('outer-bairro', 'Outer Bairro', 38.71445, -9.14760, 40, null), T('autschan', 'Autschan', 38.71090, -9.14590, 30, null), T('sao-pedro-de-alcantara', 'São Pedro de Alcântara', 38.71520, -9.14400, 38, null), T('principe-real', 'Príncipe Real', 38.71660, -9.14860, 46, ME, {
  [ME]: 5
}), T('chiado', 'Chiado', 38.71070, -9.14190, 44, 'ana.lx', {
  'ana.lx': 7,
  [ME]: 2
}), T('bica', 'Bica', 38.70880, -9.14700, 36, ME, {
  [ME]: 4,
  'mia.santos': 2
}), T('santa-catarina', 'Santa Catarina', 38.70960, -9.14860, 38, null), T('calcada-do-combro', 'Calçada do Combro', 38.71040, -9.14740, 30, null), T('pink-street', 'Pink Street', 38.70690, -9.14420, 36, 'ana.lx', {
  'ana.lx': 8,
  [ME]: 3,
  'tomas.p': 2
}), T('time-out-market', 'Time Out Market', 38.70660, -9.14620, 40, 'ana.lx', {
  'ana.lx': 4
}), T('sao-paulo', 'São Paulo', 38.70760, -9.14770, 32, null), T('santos-kiosk', 'Santos Kiosk', 38.70740, -9.15320, 32, null), T('tower-bar', 'Tower Bar', 38.71000, -9.15000, 30, null), T('after8', 'After8', 38.70830, -9.15090, 30, null), T('praca-das-flores', 'Praça das Flores', 38.71540, -9.15300, 38, null), T('sao-bento', 'São Bento', 38.71240, -9.15280, 40, null), T('madragoa', 'Madragoa', 38.70820, -9.15560, 42, null), T('sao-pedro', 'Miradouro', 38.71590, -9.14560, 26, null), T('nova-sbe', 'Nova SBE', 38.67830, -9.32590, 140, null, {
  'mia.santos': 0
})];
const statusOf = t => t.owner === ME ? 'yours' : t.owner ? 'theirs' : 'free';
const myPts = t => t.pts[ME] || 0;
const neededFor = t => t.owner && t.owner !== ME ? (t.pts[t.owner] || 0) - myPts(t) + 1 : 0;
const leadBy = t => {
  const others = Object.entries(t.pts).filter(([k]) => k !== ME).map(([, v]) => v);
  return myPts(t) - Math.max(0, ...others);
};
const CURRENT = 'shortys';
const ME_POS = {
  lat: 38.71232,
  lng: -9.14488,
  acc: 12
};
const VIEWS = {
  Me: {
    lat: ME_POS.lat,
    lng: ME_POS.lng,
    z: 17.2
  },
  'Bairro Alto': {
    lat: 38.71280,
    lng: -9.14560,
    z: 17
  },
  Lisbon: {
    lat: 38.71120,
    lng: -9.14850,
    z: 15.6
  },
  'Nova SBE': {
    lat: 38.67830,
    lng: -9.32590,
    z: 16.4
  },
  All: {
    lat: 38.6960,
    lng: -9.2350,
    z: 12.4
  }
};
const POINTS = {
  beer: {
    small: 1,
    medium: 2,
    large: 3
  },
  wine: {
    small: 1,
    medium: 2,
    large: 4
  },
  mixed: {
    small: 2,
    medium: 3,
    large: 5
  },
  shot: {
    standard: 4
  }
};
const VOLUMES = {
  beer: {
    small: 250,
    medium: 330,
    large: 500
  },
  wine: {
    small: 100,
    medium: 150,
    large: 250
  }
};
const DRINKS = [{
  value: 'beer',
  label: 'Beer',
  icon: 'sports_bar'
}, {
  value: 'wine',
  label: 'Wine',
  icon: 'wine_bar'
}, {
  value: 'shot',
  label: 'Shot',
  icon: 'liquor'
}, {
  value: 'mixed',
  label: 'Mixed drink',
  icon: 'local_bar'
}];
const MEMORIES = [{
  user: 'ana.lx',
  time: 'Thu 23:52',
  territory: 'Pink Street',
  t: 'pink-street',
  drink: 'Shot',
  points: 4
}, {
  user: ME,
  time: 'Thu 23:41',
  territory: 'Shortys',
  t: 'shortys',
  drink: 'Beer · Large 500 ml',
  points: 3,
  mine: true
}, {
  user: 'joao_b',
  time: 'Thu 23:20',
  territory: 'Cheers Irish Pub',
  t: 'cheers-irish-pub',
  drink: 'Mixed drink · Medium',
  points: 3
}, {
  user: 'mia.santos',
  time: 'Thu 22:58',
  territory: null,
  drink: 'Wine · Medium 150 ml',
  points: 2
}, {
  user: 'ana.lx',
  time: 'Thu 22:31',
  territory: 'Chiado',
  t: 'chiado',
  drink: 'Beer · Medium 330 ml',
  points: 2
}, {
  user: ME,
  time: 'Thu 21:47',
  territory: 'Rua da Rosa',
  t: 'rua-da-rosa',
  drink: 'Beer · Large 500 ml',
  points: 3,
  mine: true
}, {
  user: 'tomas.p',
  time: 'Thu 21:12',
  territory: 'Pink Street',
  t: 'pink-street',
  drink: 'Beer · Small 250 ml',
  points: 1
}];
const fmtPts = n => String(Math.round(n * 100) / 100);
const plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');
function ScreenHeader({
  eyebrow,
  title,
  right
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      gap: 12,
      padding: '8px 20px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0
    }
  }, eyebrow && /*#__PURE__*/React.createElement("div", {
    className: "wg-eyebrow",
    style: {
      marginBottom: 6
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h1", {
    className: "wg-display",
    style: {
      fontSize: 'var(--text-3xl)'
    }
  }, title)), right);
}
function SectionTitle({
  children,
  right
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      margin: '22px 0 10px'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontSize: 17,
      fontWeight: 800,
      letterSpacing: '-.01em'
    }
  }, children), right);
}
function EmptyState({
  icon,
  title,
  children,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "wg-card",
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      textAlign: 'center',
      gap: 10,
      padding: '28px 20px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'grid',
      placeItems: 'center',
      width: 64,
      height: 64,
      borderRadius: '50%',
      background: 'var(--accent-soft)',
      color: 'var(--accent-ink)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 32
  })), /*#__PURE__*/React.createElement("b", {
    style: {
      fontSize: 17
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    className: "wg-muted",
    style: {
      fontSize: 14,
      maxWidth: 280
    }
  }, children), action);
}
Object.assign(window, {
  ME,
  LOBBY,
  PLAYERS,
  TERRITORIES,
  statusOf,
  myPts,
  neededFor,
  leadBy,
  CURRENT,
  ME_POS,
  VIEWS,
  POINTS,
  VOLUMES,
  DRINKS,
  MEMORIES,
  fmtPts,
  plural,
  ScreenHeader,
  SectionTitle,
  EmptyState
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/data.jsx", error: String((e && e.message) || e) }); }

// ui_kits/app/directions.js
try { (() => {
window.WGP_DIRECTIONS = [{
  "id": "hyro-night",
  "name": "HYRO Night",
  "mood": "Dark night game — sporty, high-energy, made for a dark bar.",
  "scheme": "dark",
  "map": "dark_all",
  "font": {
    "display": "'Archivo', system-ui, sans-serif",
    "body": "'Archivo', system-ui, sans-serif",
    "stFont": "sans serif",
    "label": "Archivo Expanded Black Italic + Archivo"
  },
  "pros": ["Orange sits far from both territory red and green, so actions never read as map status.", "Charcoal ground makes the coloured territories and photos pop at night.", "Expanded italic numerals feel like a sports scoreboard: points and ranks are the hero."],
  "cons": ["Orange on charcoal needs dark text on buttons (white fails AA).", "Dark UI loses some punch in direct sunlight; pair with HYRO Day.", "Heavy italic display can feel aggressive if overused; keep it to numbers and titles."],
  "rootCss": ":root {\n  /* colours */\n  --bg: #121212; --surface: #1C1C1B; --surface-raised: #272725; --text: #FDF9EA; --text-muted: #ABA696;\n  --accent: #FE5105; --accent-ink: #FF7A3D; --on-accent: #121212; --border: #363531;\n  --territory-yours: #2FC77A; --territory-theirs: #FF4F5E; --territory-free: #77746C; --you-dot: #3B8EFF;\n  --success: #52D08A; --warning: #F6B93B; --error: #FF6B73; --info: #6AAEFF;\n  /* type */\n  --font-display: 'Archivo', system-ui, sans-serif; --font-body: 'Archivo', system-ui, sans-serif;\n  --text-xs: 12px; --text-sm: 14px; --text-md: 16px; --text-lg: 18px; --text-xl: 22px; --text-2xl: 30px; --text-3xl: 44px;\n  /* shape */\n  --radius-sm: 8px; --radius-md: 14px; --radius-lg: 22px; --radius-pill: 999px;\n  --space-1: 4px; --space-2: 8px; --space-3: 12px; --space-4: 16px; --space-5: 20px; --space-6: 24px; --space-7: 32px; --space-8: 48px;\n  --shadow-card: 0 1px 0 rgba(255,255,255,.04) inset, 0 8px 24px rgba(0,0,0,.45); --shadow-float: 0 14px 40px rgba(0,0,0,.65);\n}",
  "streamlit": "[theme]\nbase = \"dark\"\nprimaryColor = \"#FE5105\"\nbackgroundColor = \"#121212\"\nsecondaryBackgroundColor = \"#1C1C1B\"\ntextColor = \"#FDF9EA\"\nfont = \"sans serif\"   # load Archivo Expanded Black Italic + Archivo via injected CSS",
  "tokens": {
    "bg": "#121212",
    "surface": "#1C1C1B",
    "surface-raised": "#272725",
    "text": "#FDF9EA",
    "text-muted": "#ABA696",
    "accent": "#FE5105",
    "accent-hover": "#FF6A2B",
    "accent-ink": "#FF7A3D",
    "accent-soft": "#3A1D10",
    "on-accent": "#121212",
    "border": "#363531",
    "hud-bg": "rgba(18,18,18,.82)",
    "territory-yours": "#2FC77A",
    "territory-theirs": "#FF4F5E",
    "territory-free": "#77746C",
    "you-dot": "#3B8EFF",
    "success": "#52D08A",
    "warning": "#F6B93B",
    "error": "#FF6B73",
    "info": "#6AAEFF",
    "display-weight": "900",
    "display-style": "italic",
    "display-case": "uppercase",
    "display-tracking": "-0.01em",
    "display-stretch": "125%",
    "radius-sm": "8px",
    "radius-md": "14px",
    "radius-lg": "22px",
    "radius-pill": "999px",
    "radius-btn": "999px",
    "border-width": "1px",
    "shadow-card": "0 1px 0 rgba(255,255,255,.04) inset, 0 8px 24px rgba(0,0,0,.45)",
    "shadow-float": "0 14px 40px rgba(0,0,0,.65)"
  }
}, {
  "id": "hyro-day",
  "name": "HYRO Day",
  "mood": "Daylight training — the same scoreboard energy, readable in the sun.",
  "scheme": "light",
  "map": "rastertiles/voyager",
  "font": {
    "display": "'Archivo', system-ui, sans-serif",
    "body": "'Archivo', system-ui, sans-serif",
    "stFont": "sans serif",
    "label": "Archivo Expanded Black Italic + Archivo"
  },
  "pros": ["Best sunlight readability of all directions (charcoal on warm white ≈ 18:1).", "Shares tokens with HYRO Night — one brand, two modes.", "Warm white feels friendlier than pure white; photos look warmer."],
  "cons": ["Orange text on cream fails AA: use --accent-ink for links and small labels.", "Light Voyager map is busier; territory fills need higher opacity.", "Not a direction on its own — best shipped as the light mode of HYRO."],
  "rootCss": ":root {\n  /* colours */\n  --bg: #FDF9EA; --surface: #FFFFFF; --surface-raised: #F3EDD8; --text: #121212; --text-muted: #5B574C;\n  --accent: #FE5105; --accent-ink: #B83A00; --on-accent: #121212; --border: #E4DCC3;\n  --territory-yours: #18995A; --territory-theirs: #DB3B3B; --territory-free: #9C988B; --you-dot: #1F6FEB;\n  --success: #18804C; --warning: #A86400; --error: #C62F3A; --info: #1F63C6;\n  /* type */\n  --font-display: 'Archivo', system-ui, sans-serif; --font-body: 'Archivo', system-ui, sans-serif;\n  --text-xs: 12px; --text-sm: 14px; --text-md: 16px; --text-lg: 18px; --text-xl: 22px; --text-2xl: 30px; --text-3xl: 44px;\n  /* shape */\n  --radius-sm: 8px; --radius-md: 14px; --radius-lg: 22px; --radius-pill: 999px;\n  --space-1: 4px; --space-2: 8px; --space-3: 12px; --space-4: 16px; --space-5: 20px; --space-6: 24px; --space-7: 32px; --space-8: 48px;\n  --shadow-card: 0 1px 2px rgba(18,18,18,.06), 0 6px 18px rgba(18,18,18,.06); --shadow-float: 0 12px 32px rgba(18,18,18,.18);\n}",
  "streamlit": "[theme]\nbase = \"light\"\nprimaryColor = \"#FE5105\"\nbackgroundColor = \"#FDF9EA\"\nsecondaryBackgroundColor = \"#F3EDD8\"\ntextColor = \"#121212\"\nfont = \"sans serif\"   # load Archivo Expanded Black Italic + Archivo via injected CSS",
  "tokens": {
    "bg": "#FDF9EA",
    "surface": "#FFFFFF",
    "surface-raised": "#F3EDD8",
    "text": "#121212",
    "text-muted": "#5B574C",
    "accent": "#FE5105",
    "accent-hover": "#E64600",
    "accent-ink": "#B83A00",
    "accent-soft": "#FFE4D6",
    "on-accent": "#121212",
    "border": "#E4DCC3",
    "hud-bg": "rgba(253,249,234,.9)",
    "territory-yours": "#18995A",
    "territory-theirs": "#DB3B3B",
    "territory-free": "#9C988B",
    "you-dot": "#1F6FEB",
    "success": "#18804C",
    "warning": "#A86400",
    "error": "#C62F3A",
    "info": "#1F63C6",
    "display-weight": "900",
    "display-style": "italic",
    "display-case": "uppercase",
    "display-tracking": "-0.01em",
    "display-stretch": "125%",
    "radius-sm": "8px",
    "radius-md": "14px",
    "radius-lg": "22px",
    "radius-pill": "999px",
    "radius-btn": "999px",
    "border-width": "1px",
    "shadow-card": "0 1px 2px rgba(18,18,18,.06), 0 6px 18px rgba(18,18,18,.06)",
    "shadow-float": "0 12px 32px rgba(18,18,18,.18)"
  }
}, {
  "id": "base-club",
  "name": "Base Club",
  "mood": "Loud social club — stickers, hard shadows, group-chat energy.",
  "scheme": "light",
  "map": "light_all",
  "font": {
    "display": "'Bricolage Grotesque', system-ui, sans-serif",
    "body": "'DM Sans', system-ui, sans-serif",
    "stFont": "sans serif",
    "label": "Bricolage Grotesque ExtraBold + DM Sans"
  },
  "pros": ["Most social and shareable; screenshots look like posters.", "Hard ink borders + offset shadows are pure CSS and survive Streamlit widgets.", "Mint is a celebration colour only (stickers, YOU marker, success burst), so it never touches the map."],
  "cons": ["Raspberry leans towards red: theirs-red is pushed to a warm orange-red and every pill carries an icon.", "Mint can still be read as \"yours\" if used near the map — rule: no mint on Map screen.", "Loudest direction; can tire on long sessions."],
  "rootCss": ":root {\n  /* colours */\n  --bg: #FEFDFE; --surface: #FFFFFF; --surface-raised: #FCEAF2; --text: #2A0A1A; --text-muted: #6E4B5C;\n  --accent: #CC1466; --accent-ink: #B0105A; --on-accent: #FFFFFF; --border: #2A0A1A;\n  --territory-yours: #178A3E; --territory-theirs: #E0402C; --territory-free: #9A8F95; --you-dot: #2563EB;\n  --success: #137A3A; --warning: #9A5B00; --error: #C5282C; --info: #1F5FC4;\n  --highlight: #63F5C3; /* celebration only, never on the map */\n  /* type */\n  --font-display: 'Bricolage Grotesque', system-ui, sans-serif; --font-body: 'DM Sans', system-ui, sans-serif;\n  --text-xs: 12px; --text-sm: 14px; --text-md: 16px; --text-lg: 18px; --text-xl: 22px; --text-2xl: 30px; --text-3xl: 44px;\n  /* shape */\n  --radius-sm: 12px; --radius-md: 18px; --radius-lg: 28px; --radius-pill: 999px;\n  --space-1: 4px; --space-2: 8px; --space-3: 12px; --space-4: 16px; --space-5: 20px; --space-6: 24px; --space-7: 32px; --space-8: 48px;\n  --shadow-card: 4px 4px 0 #2A0A1A; --shadow-float: 6px 6px 0 #2A0A1A;\n}",
  "streamlit": "[theme]\nbase = \"light\"\nprimaryColor = \"#CC1466\"\nbackgroundColor = \"#FEFDFE\"\nsecondaryBackgroundColor = \"#FCEAF2\"\ntextColor = \"#2A0A1A\"\nfont = \"sans serif\"   # load Bricolage Grotesque ExtraBold + DM Sans via injected CSS",
  "tokens": {
    "bg": "#FEFDFE",
    "surface": "#FFFFFF",
    "surface-raised": "#FCEAF2",
    "text": "#2A0A1A",
    "text-muted": "#6E4B5C",
    "accent": "#CC1466",
    "accent-hover": "#B00F57",
    "accent-ink": "#B0105A",
    "accent-soft": "#FCE1EE",
    "on-accent": "#FFFFFF",
    "border": "#2A0A1A",
    "hud-bg": "rgba(255,255,255,.94)",
    "highlight": "#63F5C3",
    "on-highlight": "#2A0A1A",
    "territory-yours": "#178A3E",
    "territory-theirs": "#E0402C",
    "territory-free": "#9A8F95",
    "you-dot": "#2563EB",
    "success": "#137A3A",
    "warning": "#9A5B00",
    "error": "#C5282C",
    "info": "#1F5FC4",
    "display-weight": "800",
    "display-style": "normal",
    "display-case": "none",
    "display-tracking": "-0.035em",
    "display-stretch": "100%",
    "radius-sm": "12px",
    "radius-md": "18px",
    "radius-lg": "28px",
    "radius-pill": "999px",
    "radius-btn": "999px",
    "border-width": "2px",
    "shadow-card": "4px 4px 0 #2A0A1A",
    "shadow-float": "6px 6px 0 #2A0A1A"
  }
}, {
  "id": "rush",
  "name": "Rush",
  "mood": "Retro bar crawl — navy and cream, varsity badges, swashy numbers.",
  "scheme": "dark",
  "map": "dark_all",
  "font": {
    "display": "'Shrikhand', Georgia, serif",
    "body": "'Familjen Grotesk', system-ui, sans-serif",
    "stFont": "sans serif",
    "label": "Shrikhand + Familjen Grotesk"
  },
  "pros": ["Most characterful: feels like a bar, not a fitness app.", "Cream-on-navy buttons are unmistakable and never confused with map colours.", "Vintage red is confined to the wordmark and the 1st-place medal, so it never collides with \"theirs\"."],
  "cons": ["No bright accent: primary action relies on value contrast, not hue.", "Shrikhand only works for short words and numbers; long titles get messy.", "Navy map tiles need a custom tint (Carto dark is grey-black)."],
  "rootCss": ":root {\n  /* colours */\n  --bg: #1A2841; --surface: #22334F; --surface-raised: #2C3F60; --text: #F0E1CE; --text-muted: #BCB0A0;\n  --accent: #F0E1CE; --accent-ink: #F7D9A8; --on-accent: #1A2841; --border: #3C5076;\n  --territory-yours: #4CC38A; --territory-theirs: #FF5D52; --territory-free: #7E889C; --you-dot: #5AA8FF;\n  --success: #6BD49B; --warning: #F4C04E; --error: #FF7A70; --info: #7DB8FF;\n  --brand: #B11722; /* wordmark + 1st medal only */\n  /* type */\n  --font-display: 'Shrikhand', Georgia, serif; --font-body: 'Familjen Grotesk', system-ui, sans-serif;\n  --text-xs: 12px; --text-sm: 14px; --text-md: 16px; --text-lg: 18px; --text-xl: 22px; --text-2xl: 30px; --text-3xl: 40px;\n  /* shape */\n  --radius-sm: 6px; --radius-md: 10px; --radius-lg: 16px; --radius-pill: 999px;\n  --space-1: 4px; --space-2: 8px; --space-3: 12px; --space-4: 16px; --space-5: 20px; --space-6: 24px; --space-7: 32px; --space-8: 48px;\n  --shadow-card: 0 0 0 1px rgba(240,225,206,.06), 0 6px 18px rgba(5,10,20,.35); --shadow-float: 0 14px 36px rgba(5,10,20,.55);\n}",
  "streamlit": "[theme]\nbase = \"dark\"\nprimaryColor = \"#F0E1CE\"\nbackgroundColor = \"#1A2841\"\nsecondaryBackgroundColor = \"#22334F\"\ntextColor = \"#F0E1CE\"\nfont = \"sans serif\"   # load Shrikhand + Familjen Grotesk via injected CSS",
  "tokens": {
    "bg": "#1A2841",
    "surface": "#22334F",
    "surface-raised": "#2C3F60",
    "text": "#F0E1CE",
    "text-muted": "#BCB0A0",
    "accent": "#F0E1CE",
    "accent-hover": "#FFF2E0",
    "accent-ink": "#F7D9A8",
    "accent-soft": "#33466A",
    "on-accent": "#1A2841",
    "border": "#3C5076",
    "hud-bg": "rgba(26,40,65,.9)",
    "brand": "#B11722",
    "territory-yours": "#4CC38A",
    "territory-theirs": "#FF5D52",
    "territory-free": "#7E889C",
    "you-dot": "#5AA8FF",
    "success": "#6BD49B",
    "warning": "#F4C04E",
    "error": "#FF7A70",
    "info": "#7DB8FF",
    "display-weight": "400",
    "display-style": "normal",
    "display-case": "none",
    "display-tracking": "0",
    "display-stretch": "100%",
    "radius-sm": "6px",
    "radius-md": "10px",
    "radius-lg": "16px",
    "radius-pill": "999px",
    "radius-btn": "10px",
    "border-width": "2px",
    "shadow-card": "0 0 0 1px rgba(240,225,206,.06), 0 6px 18px rgba(5,10,20,.35)",
    "shadow-float": "0 14px 36px rgba(5,10,20,.55)"
  }
}, {
  "id": "tennis",
  "name": "Tennis",
  "mood": "Fresh match day — sky blue, white, condensed scoreboard type.",
  "scheme": "light",
  "map": "rastertiles/voyager",
  "font": {
    "display": "'Anton', Impact, sans-serif",
    "body": "'Barlow', system-ui, sans-serif",
    "stFont": "sans serif",
    "label": "Anton + Barlow"
  },
  "pros": ["Scarlet maps 1:1 onto \"theirs\" and errors — its only job, so it reinforces the game.", "Cleanest, most Strava-like; condensed type fits big numbers in narrow rows.", "Very readable outdoors."],
  "cons": ["Sky blue fails AA with white text; buttons use navy text.", "Blue accent sits close to the \"you are here\" dot: the dot moves to deep navy with a white ring.", "Least nightlife-feeling; reads as daytime sport."],
  "rootCss": ":root {\n  /* colours */\n  --bg: #F8FAFC; --surface: #FFFFFF; --surface-raised: #E8F3FA; --text: #0E2233; --text-muted: #4A6073;\n  --accent: #2C99D6; --accent-ink: #14699A; --on-accent: #0E2233; --border: #D6E3EC;\n  --territory-yours: #1E9E58; --territory-theirs: #EB2F33; --territory-free: #9AA6B0; --you-dot: #0B3A8C;\n  --success: #16804A; --warning: #9C5D00; --error: #C4161C; --info: #14699A;\n  /* type */\n  --font-display: 'Anton', Impact, sans-serif; --font-body: 'Barlow', system-ui, sans-serif;\n  --text-xs: 12px; --text-sm: 14px; --text-md: 16px; --text-lg: 18px; --text-xl: 22px; --text-2xl: 30px; --text-3xl: 52px;\n  /* shape */\n  --radius-sm: 4px; --radius-md: 8px; --radius-lg: 12px; --radius-pill: 999px;\n  --space-1: 4px; --space-2: 8px; --space-3: 12px; --space-4: 16px; --space-5: 20px; --space-6: 24px; --space-7: 32px; --space-8: 48px;\n  --shadow-card: 0 1px 2px rgba(14,34,51,.06), 0 4px 12px rgba(14,34,51,.06); --shadow-float: 0 10px 28px rgba(14,34,51,.18);\n}",
  "streamlit": "[theme]\nbase = \"light\"\nprimaryColor = \"#2C99D6\"\nbackgroundColor = \"#F8FAFC\"\nsecondaryBackgroundColor = \"#E8F3FA\"\ntextColor = \"#0E2233\"\nfont = \"sans serif\"   # load Anton + Barlow via injected CSS",
  "tokens": {
    "bg": "#F8FAFC",
    "surface": "#FFFFFF",
    "surface-raised": "#E8F3FA",
    "text": "#0E2233",
    "text-muted": "#4A6073",
    "accent": "#2C99D6",
    "accent-hover": "#2389C2",
    "accent-ink": "#14699A",
    "accent-soft": "#DCEFFA",
    "on-accent": "#0E2233",
    "border": "#D6E3EC",
    "hud-bg": "rgba(255,255,255,.92)",
    "territory-yours": "#1E9E58",
    "territory-theirs": "#EB2F33",
    "territory-free": "#9AA6B0",
    "you-dot": "#0B3A8C",
    "success": "#16804A",
    "warning": "#9C5D00",
    "error": "#C4161C",
    "info": "#14699A",
    "display-weight": "400",
    "display-style": "normal",
    "display-case": "uppercase",
    "display-tracking": "0.005em",
    "display-stretch": "100%",
    "radius-sm": "4px",
    "radius-md": "8px",
    "radius-lg": "12px",
    "radius-pill": "999px",
    "radius-btn": "8px",
    "border-width": "1px",
    "shadow-card": "0 1px 2px rgba(14,34,51,.06), 0 4px 12px rgba(14,34,51,.06)",
    "shadow-float": "0 10px 28px rgba(14,34,51,.18)"
  }
}, {
  "id": "moon",
  "name": "Moon",
  "mood": "Calm premium editorial — slate, deep teal, serif numerals.",
  "scheme": "dark",
  "map": "dark_all",
  "font": {
    "display": "'Instrument Serif', Georgia, serif",
    "body": "'Geist', system-ui, sans-serif",
    "stFont": "sans serif",
    "label": "Instrument Serif + Geist"
  },
  "pros": ["Most premium and calm; easy on the eyes late at night.", "Serif numerals make stats feel editorial (Strava-meets-magazine).", "Low saturation lets territory colours be the only loud thing on screen."],
  "cons": ["Deep teal button has low contrast against slate surfaces: needs a lighter rim.", "Teal is the nearest accent to green; \"yours\" is pushed to a yellow-green.", "Least playful; may undersell the banter."],
  "rootCss": ":root {\n  /* colours */\n  --bg: #212A31; --surface: #2E3944; --surface-raised: #384653; --text: #D3D9D4; --text-muted: #A3B3B6;\n  --accent: #124E66; --accent-ink: #86C6DC; --on-accent: #E6ECE7; --border: #43525F;\n  --territory-yours: #7BD389; --territory-theirs: #F07070; --territory-free: #748D92; --you-dot: #8AB4FF;\n  --success: #8BD69A; --warning: #E9C46A; --error: #F28B82; --info: #86C6DC;\n  /* type */\n  --font-display: 'Instrument Serif', Georgia, serif; --font-body: 'Geist', system-ui, sans-serif;\n  --text-xs: 12px; --text-sm: 14px; --text-md: 16px; --text-lg: 18px; --text-xl: 22px; --text-2xl: 30px; --text-3xl: 48px;\n  /* shape */\n  --radius-sm: 6px; --radius-md: 12px; --radius-lg: 18px; --radius-pill: 999px;\n  --space-1: 4px; --space-2: 8px; --space-3: 12px; --space-4: 16px; --space-5: 20px; --space-6: 24px; --space-7: 32px; --space-8: 48px;\n  --shadow-card: 0 1px 0 rgba(255,255,255,.03) inset, 0 6px 20px rgba(0,0,0,.25); --shadow-float: 0 12px 36px rgba(0,0,0,.45);\n}",
  "streamlit": "[theme]\nbase = \"dark\"\nprimaryColor = \"#124E66\"\nbackgroundColor = \"#212A31\"\nsecondaryBackgroundColor = \"#2E3944\"\ntextColor = \"#D3D9D4\"\nfont = \"sans serif\"   # load Instrument Serif + Geist via injected CSS",
  "tokens": {
    "bg": "#212A31",
    "surface": "#2E3944",
    "surface-raised": "#384653",
    "text": "#D3D9D4",
    "text-muted": "#A3B3B6",
    "accent": "#124E66",
    "accent-hover": "#17607D",
    "accent-ink": "#86C6DC",
    "accent-soft": "#1B3A48",
    "on-accent": "#E6ECE7",
    "border": "#43525F",
    "hud-bg": "rgba(33,42,49,.88)",
    "territory-yours": "#7BD389",
    "territory-theirs": "#F07070",
    "territory-free": "#748D92",
    "you-dot": "#8AB4FF",
    "success": "#8BD69A",
    "warning": "#E9C46A",
    "error": "#F28B82",
    "info": "#86C6DC",
    "display-weight": "400",
    "display-style": "normal",
    "display-case": "none",
    "display-tracking": "-0.01em",
    "display-stretch": "100%",
    "radius-sm": "6px",
    "radius-md": "12px",
    "radius-lg": "18px",
    "radius-pill": "999px",
    "radius-btn": "12px",
    "border-width": "1px",
    "shadow-card": "0 1px 0 rgba(255,255,255,.03) inset, 0 6px 20px rgba(0,0,0,.25)",
    "shadow-float": "0 12px 36px rgba(0,0,0,.45)"
  }
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/app/directions.js", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Countdown = __ds_scope.Countdown;

__ds_ns.ProgressBar = __ds_scope.ProgressBar;

__ds_ns.Skeleton = __ds_scope.Skeleton;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.ChipGroup = __ds_scope.ChipGroup;

__ds_ns.ChoiceTiles = __ds_scope.ChoiceTiles;

__ds_ns.SegmentedControl = __ds_scope.SegmentedControl;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.TextInput = __ds_scope.TextInput;

__ds_ns.PasswordInput = __ds_scope.PasswordInput;

__ds_ns.CameraFrame = __ds_scope.CameraFrame;

__ds_ns.MapLegend = __ds_scope.MapLegend;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.RankBadge = __ds_scope.RankBadge;

__ds_ns.YouTag = __ds_scope.YouTag;

__ds_ns.StatusPill = __ds_scope.StatusPill;

__ds_ns.PlayerRow = __ds_scope.PlayerRow;

__ds_ns.NAV_ITEMS = __ds_scope.NAV_ITEMS;

__ds_ns.BottomNav = __ds_scope.BottomNav;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.FloatingPanel = __ds_scope.FloatingPanel;

__ds_ns.PhotoCard = __ds_scope.PhotoCard;

__ds_ns.StatCard = __ds_scope.StatCard;

__ds_ns.TerritoryCard = __ds_scope.TerritoryCard;

})();
