export interface AlertProps { tone?: 'info' | 'success' | 'warning' | 'error'; title?: string; children?: React.ReactNode; icon?: string; action?: React.ReactNode; }
export declare function Alert(props: AlertProps): JSX.Element;
