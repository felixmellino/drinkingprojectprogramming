export interface SkeletonProps { w?: number | string; h?: number | string; r?: number | string; style?: React.CSSProperties; }
export declare function Skeleton(props: SkeletonProps): JSX.Element;
