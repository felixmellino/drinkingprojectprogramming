Ticking countdown: boxed segments for season end, inline m:ss for cooldowns.
```jsx
<Countdown seconds={3*86400+4*3600} /> <Countdown inline seconds={84} />
```
