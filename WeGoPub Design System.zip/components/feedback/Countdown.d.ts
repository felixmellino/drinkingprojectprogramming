export interface CountdownProps { /** Seconds remaining */ seconds: number; inline?: boolean; live?: boolean; compact?: boolean; }
export declare function Countdown(props: CountdownProps): JSX.Element;
