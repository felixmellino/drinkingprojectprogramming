import React from 'react';
export function Skeleton({ w = '100%', h = 16, r, style }) { return <div className="wg-skel" aria-hidden="true" style={{ width: w, height: h, ...(r != null ? { borderRadius: r } : null), ...style }} />; }
