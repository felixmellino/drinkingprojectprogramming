export interface ToastProps { tone?: 'info' | 'success' | 'warning' | 'error'; children?: React.ReactNode; icon?: string; style?: React.CSSProperties; }
export declare function Toast(props: ToastProps): JSX.Element;
