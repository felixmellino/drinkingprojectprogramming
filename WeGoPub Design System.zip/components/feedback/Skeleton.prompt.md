Shimmer placeholder for loading states — never show fake zeros.
```jsx
<Skeleton h={60} r={14} />
```
