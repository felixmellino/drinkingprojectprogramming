Short inverted notification (bottom, above nav). Auto-dismiss 3s.
```jsx
<Toast tone="success">Friend request sent to ana.lx</Toast>
```
