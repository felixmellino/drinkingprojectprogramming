import React from 'react';
import { Icon } from '../actions/Icon.jsx';
const ICONS = { success: 'check_circle', warning: 'warning', error: 'error', info: 'info' };
export function Alert({ tone = 'info', title, children, icon, action }) {
  return <div className={'wg-alert wg-alert--' + tone} role={tone === 'error' ? 'alert' : 'status'}>
    <Icon name={icon || ICONS[tone]} fill /><div>{title && <b>{title}</b>}{children}</div>{action || <span />}</div>;
}
