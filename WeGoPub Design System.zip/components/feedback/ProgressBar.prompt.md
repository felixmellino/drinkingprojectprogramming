Rounded progress/points bar; territory tones for per-territory standings.
```jsx
<ProgressBar value={6} max={9} tone="theirs" thin />
```
