import React from 'react';
import { Icon } from '../actions/Icon.jsx';
const ICONS = { success: 'check_circle', warning: 'warning', error: 'error', info: 'info' };
export function Toast({ tone = 'success', children, icon, style }) {
  return <div className={'wg-toast wg-toast--' + tone} role="status" style={style}><Icon name={icon || ICONS[tone]} fill />{children}</div>;
}
