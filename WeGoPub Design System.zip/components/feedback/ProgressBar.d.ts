export interface ProgressBarProps { value: number; max?: number; tone?: 'accent' | 'yours' | 'theirs' | 'free'; thin?: boolean; label?: string; }
export declare function ProgressBar(props: ProgressBarProps): JSX.Element;
