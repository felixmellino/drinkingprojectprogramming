Inline message; always icon + title text so it is never confused with territory colour.
```jsx
<Alert tone="warning" title="Scoring is closed">Opens Thu 19 Nov at 18:00</Alert>
```
