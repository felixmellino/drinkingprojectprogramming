import React from 'react';
export function ProgressBar({ value = 0, max = 100, tone = 'accent', thin, label }) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  return <div className={'wg-progress' + (tone !== 'accent' ? ' wg-progress--' + tone : '') + (thin ? ' wg-progress--thin' : '')} role="progressbar" aria-valuenow={value} aria-valuemax={max} aria-label={label}><span style={{ width: pct + '%' }} /></div>;
}
