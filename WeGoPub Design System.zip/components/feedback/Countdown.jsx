import React, { useEffect, useState } from 'react';
const pad = n => String(n).padStart(2, '0');
export function Countdown({ seconds = 0, inline, live = true, compact }) {
  const [s, setS] = useState(seconds);
  useEffect(() => { setS(seconds); }, [seconds]);
  useEffect(() => { if (!live) return; const t = setInterval(() => setS(v => Math.max(0, v - 1)), 1000); return () => clearInterval(t); }, [live]);
  const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60), sec = s % 60;
  if (inline) return <span className="wg-countdown wg-countdown--inline">{d > 0 ? d + 'd ' + h + 'h ' + pad(m) + 'm' : h > 0 ? h + ':' + pad(m) + ':' + pad(sec) : m + ':' + pad(sec)}</span>;
  const parts = d > 0 ? [[d, 'days'], [h, 'hrs'], [m, 'min']] : [[h, 'hrs'], [m, 'min'], [sec, 'sec']];
  return <span className="wg-countdown" role="timer">{parts.map(([v, l]) => <div key={l}><span className="wg-num">{compact ? v : pad(v)}</span><small>{l}</small></div>)}</span>;
}
