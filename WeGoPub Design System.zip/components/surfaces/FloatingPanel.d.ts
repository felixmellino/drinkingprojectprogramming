export interface FloatingPanelProps { children?: React.ReactNode; style?: React.CSSProperties; className?: string; }
export declare function FloatingPanel(props: FloatingPanelProps): JSX.Element;
