import React from 'react';
import { Card } from './Card.jsx';
import { Avatar } from '../identity/Avatar.jsx';
import { StatusPill } from '../identity/StatusPill.jsx';
import { ProgressBar } from '../feedback/ProgressBar.jsx';
export function TerritoryCard({ name, status = 'free', owner, players = [], note }) {
  const max = Math.max(1, ...players.map(p => p.points));
  return <Card className={'wg-terr' + (status === 'yours' ? ' wg-terr--yours' : '')}>
    <div className="wg-terr__head"><h3 className="wg-terr__name">{name}</h3><StatusPill status={status} /></div>
    {owner ? <div className="wg-terr__owner"><Avatar name={owner} size={24} /><span>Owned by <b>{owner}</b></span></div>
      : <div className="wg-terr__owner">Nobody owns this yet. The next drink here claims it.</div>}
    {players.length > 0 && <ul className="wg-bars">{players.map(p => <li key={p.name}><span>{p.name}{p.you && ' (you)'}</span><b>{p.points}</b>
      <ProgressBar value={p.points} max={max} thin tone={p.name === owner ? (status === 'yours' ? 'yours' : 'theirs') : p.you ? 'accent' : 'free'} /></li>)}</ul>}
    {note && <div className="wg-hint">{note}</div>}
  </Card>;
}
