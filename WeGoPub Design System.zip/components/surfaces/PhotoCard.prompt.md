Photo-first check-in post for Memories: big 4:5 image, user overlay, territory pill, drink, points.
```jsx
<PhotoCard user="ana.lx" time="23:41" territory="Shortys" status="theirs" drink="Beer · Large 500 ml" points={3} />
```
