export interface TerritoryCardProps { name: string; status: 'yours' | 'theirs' | 'free'; owner?: string; players?: { name: string; points: number; you?: boolean }[]; note?: string; }
export declare function TerritoryCard(props: TerritoryCardProps): JSX.Element;
