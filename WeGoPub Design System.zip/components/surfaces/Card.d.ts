export interface CardProps { variant?: 'raised' | 'muted' | 'accent'; children?: React.ReactNode; style?: React.CSSProperties; className?: string; as?: string; }
export declare function Card(props: CardProps): JSX.Element;
