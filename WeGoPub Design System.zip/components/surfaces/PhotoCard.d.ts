export interface PhotoCardProps { user: string; time: string; src?: string; territory?: string; status?: 'yours' | 'theirs' | 'free'; drink: string; points: number | string; onOpen?: () => void; }
export declare function PhotoCard(props: PhotoCardProps): JSX.Element;
