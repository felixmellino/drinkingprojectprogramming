Territory standings: name, ownership pill, owner, every player's points as bars.
```jsx
<TerritoryCard name="Shortys" status="theirs" owner="ana.lx" players={[{name:'ana.lx',points:9},{name:'rita',points:6,you:true}]} note="You need 4 more points to take it." />
```
