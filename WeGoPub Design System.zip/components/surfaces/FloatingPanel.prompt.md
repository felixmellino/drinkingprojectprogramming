Blurred, floating HUD/card for content over the full-screen map (top HUD, bottom "You are in…" card).
```jsx
<FloatingPanel style={{position:'absolute',top:12,left:12,right:12}}>Thursday Crew · 2 / 24 yours</FloatingPanel>
```
