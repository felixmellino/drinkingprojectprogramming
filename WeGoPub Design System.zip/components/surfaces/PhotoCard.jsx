import React from 'react';
import { Avatar } from '../identity/Avatar.jsx';
import { StatusPill } from '../identity/StatusPill.jsx';
import { Icon } from '../actions/Icon.jsx';
export function PhotoCard({ user, time, src, territory, status = 'free', drink, points, onOpen }) {
  return <article className="wg-photo" onClick={onOpen} style={onOpen ? { cursor: 'pointer' } : undefined}>
    <div className="wg-photo__img">{src ? <img src={src} alt={'Drink photo by ' + user} /> : <Icon name="photo_camera" />}
      <div className="wg-photo__top"><Avatar name={user} size={34} /><div style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.2 }}><b>{user}</b><span>{time}</span></div></div></div>
    <div className="wg-photo__meta">{territory ? <StatusPill status={status}>{territory}</StatusPill> : <StatusPill status="closed" icon="location_off">Outside territories</StatusPill>}
      <span className="wg-muted" style={{ fontSize: 13 }}>{drink}</span><span className="wg-num wg-photo__pts">+{points}</span></div>
  </article>;
}
