import React from 'react';
export function Card({ variant, children, style, className, as: Tag = 'div' }) {
  return <Tag className={'wg-card' + (variant ? ' wg-card--' + variant : '') + (className ? ' ' + className : '')} style={style}>{children}</Tag>;
}
