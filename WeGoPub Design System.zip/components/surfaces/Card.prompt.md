Base surface. muted = past lobbies; accent = hero stat.
```jsx
<Card>…</Card> <Card variant="muted">Past lobby</Card>
```
