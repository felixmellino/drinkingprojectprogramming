Big-number stat (rank, season points, territories). Use accent for the first/hero stat only.
```jsx
<StatCard accent label="Your rank" value="#2" sub="of 8 players" /> <StatCard label="Season points" value="12.25" />
```
