export interface StatCardProps { label: string; value: React.ReactNode; sub?: string; accent?: boolean; }
export declare function StatCard(props: StatCardProps): JSX.Element;
