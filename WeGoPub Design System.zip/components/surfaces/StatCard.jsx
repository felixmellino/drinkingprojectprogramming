import React from 'react';
import { Card } from './Card.jsx';
export function StatCard({ label, value, sub, accent }) {
  return <Card variant={accent ? 'accent' : undefined} style={{ padding: 14 }}><div className="wg-stat"><span className="wg-stat__label">{label}</span><span className="wg-num wg-stat__value">{value}</span>{sub && <span className="wg-stat__sub">{sub}</span>}</div></Card>;
}
