import React from 'react';
export function FloatingPanel({ children, style, className }) { return <div className={'wg-hud' + (className ? ' ' + className : '')} style={style}>{children}</div>; }
