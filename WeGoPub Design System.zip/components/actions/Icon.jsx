import React from 'react';
/** Material Symbols Rounded glyph. The only icon set in WeGoPub. */
export function Icon({ name, fill = false, size, className = '', style, label }) {
  return <span className={'wg-icon' + (fill ? ' wg-icon--fill' : '') + (className ? ' ' + className : '')}
    style={{ ...(size ? { fontSize: size } : null), ...style }} aria-hidden={label ? undefined : true} aria-label={label} role={label ? 'img' : undefined}>{name}</span>;
}
