import React from 'react';
import { Icon } from './Icon.jsx';
const cx = (...a) => a.filter(Boolean).join(' ');

export function IconButton({ icon, label, variant = 'default', size = 'md', fill, onClick, className, style }) {
  return <button type="button" aria-label={label} title={label} onClick={onClick} style={style}
    className={cx('wg-iconbtn', variant !== 'default' && 'wg-iconbtn--' + variant, size === 'lg' && 'wg-iconbtn--lg', className)}>
    <Icon name={icon} fill={fill} />
  </button>;
}
