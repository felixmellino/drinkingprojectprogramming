export interface IconButtonProps { icon: string; /** Required accessible name */ label: string; variant?: 'default' | 'ghost' | 'accent' | 'float'; size?: 'md' | 'lg'; fill?: boolean; onClick?: () => void; className?: string; style?: React.CSSProperties; }
export declare function IconButton(props: IconButtonProps): JSX.Element;
