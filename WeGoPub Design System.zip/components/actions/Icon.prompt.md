Material Symbols Rounded glyph — use for every UI icon; never emoji.
```jsx
<Icon name="local_bar" /> <Icon name="flag" fill size={18} />
```
Common names: add, map, leaderboard, group, person, photo_library, photo_camera, my_location, flag, swords, local_bar, sports_bar, wine_bar, liquor, timer, refresh.
