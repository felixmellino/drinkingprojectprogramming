Round 44px icon-only button. Use variant="float" over the map (blurred HUD background).
```jsx
<IconButton icon="my_location" label="Centre on me" variant="float" />
<IconButton icon="arrow_back" label="Back to Profile" variant="ghost" />
```
