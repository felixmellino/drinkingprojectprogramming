import React from 'react';
import { Icon } from './Icon.jsx';
const cx = (...a) => a.filter(Boolean).join(' ');

export function Button({ variant = 'primary', size = 'md', block = false, icon, iconRight, disabled, type = 'button', onClick, children, className, style }) {
  return <button type={type} disabled={disabled} onClick={onClick} style={style}
    className={cx('wg-btn', 'wg-btn--' + variant, size !== 'md' && 'wg-btn--' + size, block && 'wg-btn--block', className)}>
    {icon && <Icon name={icon} />}{children}{iconRight && <Icon name={iconRight} />}
  </button>;
}
