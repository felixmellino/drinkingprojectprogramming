Pill/rounded action button; one primary per screen, ≥44px tall (lg = 56px for Submit / Check in here).
```jsx
<Button variant="primary" size="lg" block icon="add_a_photo">Check in here</Button>
<Button variant="secondary" icon="refresh">Retake</Button>
<Button variant="destructive" icon="delete">Delete photo</Button>
```
Disabled buttons should always be accompanied by a visible reason (Alert or hint) above them.
