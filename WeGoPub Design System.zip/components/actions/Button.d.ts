export interface ButtonProps {
  /** primary = the one main action per screen; destructive is outline-only so it never reads as a territory colour */
  variant?: 'primary' | 'secondary' | 'ghost' | 'destructive';
  size?: 'sm' | 'md' | 'lg'; block?: boolean; icon?: string; iconRight?: string; disabled?: boolean;
  type?: 'button' | 'submit'; onClick?: () => void; children?: React.ReactNode; className?: string; style?: React.CSSProperties;
}
export declare function Button(props: ButtonProps): JSX.Element;
