export interface IconProps { /** Material Symbols Rounded ligature name, e.g. "local_bar" */ name: string; fill?: boolean; size?: number; className?: string; style?: React.CSSProperties; /** Accessible label; omit for decorative icons */ label?: string; }
export declare function Icon(props: IconProps): JSX.Element;
