Rounded 3:4 camera frame with one big shutter; captured → Retake; blocked → message + Retry.
```jsx
<CameraFrame state="live" onShutter={take} /> <CameraFrame state="captured" src={photo} onRetake={retake} />
```
