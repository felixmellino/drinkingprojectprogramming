import React from 'react';
import { Icon } from '../actions/Icon.jsx';
export function CameraFrame({ state = 'live', src, onShutter, onRetake, onRetry, onFlip }) {
  return <div className="wg-camera">
    {state === 'blocked' ? <div className="wg-camera__msg"><Icon name="no_photography" /><b style={{ fontSize: 18 }}>Camera is blocked</b>
      <span style={{ opacity: .8, fontSize: 14 }}>Allow camera access for this site in your browser settings, then tap Retry.</span>
      <button className="wg-btn wg-btn--primary" onClick={onRetry}><Icon name="refresh" />Retry</button></div> : <>
      <div className="wg-camera__view">{src ? <img src={src} alt="Your drink photo" /> : state === 'captured' ? <Icon name="sports_bar" size={64} style={{ opacity: .4 }} /> : null}</div>
      {state === 'live' && <div className="wg-camera__corners" />}
      <div className="wg-camera__bar"><span />
        {state === 'live' ? <button className="wg-shutter" aria-label="Take photo" onClick={onShutter}><span /></button>
          : <button className="wg-btn wg-btn--secondary" onClick={onRetake}><Icon name="replay" />Retake</button>}
        <span style={{ justifySelf: 'end' }}>{state === 'live' && <button className="wg-iconbtn wg-iconbtn--float" aria-label="Switch camera" onClick={onFlip}><Icon name="cameraswitch" /></button>}</span></div></>}
  </div>;
}
