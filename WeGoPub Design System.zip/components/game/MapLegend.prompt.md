Map key for the three fixed territory colours plus the blue "you" dot.
```jsx
<MapLegend />
```
