export interface MapLegendProps { showYou?: boolean; style?: React.CSSProperties; }
export declare function MapLegend(props: MapLegendProps): JSX.Element;
