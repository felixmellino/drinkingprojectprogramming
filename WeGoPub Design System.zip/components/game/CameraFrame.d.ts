export interface CameraFrameProps { state?: 'live' | 'captured' | 'blocked'; src?: string; onShutter?: () => void; onRetake?: () => void; onRetry?: () => void; onFlip?: () => void; }
export declare function CameraFrame(props: CameraFrameProps): JSX.Element;
