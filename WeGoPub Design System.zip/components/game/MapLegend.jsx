import React from 'react';
export function MapLegend({ showYou = true, style }) {
  return <div className="wg-legend" style={style}>
    <span><i style={{ '--c': 'var(--territory-yours)' }} />Yours</span><span><i style={{ '--c': 'var(--territory-theirs)' }} />Rival's</span>
    <span><i style={{ '--c': 'var(--territory-free)' }} />Unclaimed</span>{showYou && <span><i className="wg-legend__dot" />You</span>}</div>;
}
