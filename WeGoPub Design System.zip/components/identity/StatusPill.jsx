import React from 'react';
import { Icon } from '../actions/Icon.jsx';
const ICONS = { yours: 'flag', theirs: 'swords', free: 'radio_button_unchecked', test: 'science', closed: 'schedule', live: 'bolt' };
const LABELS = { yours: 'Yours', theirs: "Rival's", free: 'Unclaimed', test: 'Test season', closed: 'Closed', live: 'Live' };
export function StatusPill({ status = 'free', children, icon, solid }) {
  return <span className={'wg-pill wg-pill--' + status + (solid ? ' wg-pill--solid' : '')}><Icon name={icon || ICONS[status]} fill={status === 'yours'} />{children ?? LABELS[status]}</span>;
}
