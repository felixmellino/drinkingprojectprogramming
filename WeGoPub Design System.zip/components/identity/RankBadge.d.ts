export interface RankBadgeProps { rank: number; }
export declare function RankBadge(props: RankBadgeProps): JSX.Element;
export declare function YouTag(): JSX.Element;
