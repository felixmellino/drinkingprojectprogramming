Square rank number with gold/silver/bronze for top 3; YouTag marks the current player's row.
```jsx
<RankBadge rank={1} /> <YouTag />
```
