export interface StatusPillProps {
  /** yours/theirs/free use the fixed territory colours and always carry an icon + text */
  status: 'yours' | 'theirs' | 'free' | 'test' | 'closed' | 'live'; children?: React.ReactNode; icon?: string; solid?: boolean;
}
export declare function StatusPill(props: StatusPillProps): JSX.Element;
