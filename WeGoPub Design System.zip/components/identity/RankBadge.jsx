import React from 'react';
export function RankBadge({ rank }) { return <span className={'wg-rank' + (rank <= 3 ? ' wg-rank--' + rank : '')} aria-label={'Rank ' + rank}>{rank}</span>; }
export function YouTag() { return <span className="wg-you">YOU</span>; }
