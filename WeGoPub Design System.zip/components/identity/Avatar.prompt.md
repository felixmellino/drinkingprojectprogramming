Circular profile picture with an initials fallback (deterministic pastel per username).
```jsx
<Avatar name="ritafromlx" size={44} /> <Avatar name="me" src={url} ring />
```
