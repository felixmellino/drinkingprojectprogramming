Small pill for territory ownership and season state; colour is never the only signal (icon + label).
```jsx
<StatusPill status="yours" /> <StatusPill status="theirs">ana.lx</StatusPill> <StatusPill status="test" />
```
