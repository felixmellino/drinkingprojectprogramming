import React from 'react';
const cx = (...a) => a.filter(Boolean).join(' ');

const HUES = ['#F6C177','#9CCFD8','#C4A7E7','#F2B8A0','#A7C7E7','#E8D5B7','#B8C0FF','#F5A9C8'];
export function initials(name = '') { const p = name.replace(/[^\p{L}\p{N} ]/gu, ' ').trim().split(/\s+/); return ((p[0]||'?')[0] + (p[1] ? p[1][0] : (p[0]||'')[1] || '')).toUpperCase(); }
export function Avatar({ name = '', src, size = 40, ring = false, className, style }) {
  let h = 0; for (const c of name) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return <span className={cx('wg-avatar', ring && 'wg-avatar--ring', className)} style={{ '--size': size + 'px', '--av-bg': HUES[h % HUES.length], ...style }} title={name}>
    {src ? <img src={src} alt="" /> : initials(name)}
  </span>;
}
