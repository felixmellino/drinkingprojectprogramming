export interface AvatarProps { /** Username; drives initials + fallback colour */ name: string; src?: string; size?: number; /** Accent ring — use for the current player */ ring?: boolean; className?: string; style?: React.CSSProperties; }
export declare function Avatar(props: AvatarProps): JSX.Element;
export declare function initials(name: string): string;
