// Dev fallback: if _ds_bundle.js hasn't been compiled yet, build the namespace from the component sources.
(function () {
  var NS = 'WeGoPubDesignSystem_71f296';
  if (window[NS] || !window.Babel) return;
  var base = document.currentScript.src.replace(/ds-fallback\.js.*$/, '');
  var files = ['actions/Icon', 'actions/Button', 'actions/IconButton', 'identity/Avatar', 'identity/RankBadge', 'identity/StatusPill', 'feedback/ProgressBar',
    'forms/TextInput', 'forms/Checkbox', 'forms/Select', 'forms/SegmentedControl', 'forms/ChipGroup', 'forms/ChoiceTiles',
    'surfaces/Card', 'surfaces/StatCard', 'surfaces/FloatingPanel', 'surfaces/PhotoCard', 'surfaces/TerritoryCard', 'lists/PlayerRow',
    'feedback/Alert', 'feedback/Toast', 'feedback/Countdown', 'feedback/Skeleton', 'navigation/BottomNav', 'game/CameraFrame', 'game/MapLegend'];
  var ns = {};
  files.forEach(function (f) {
    var x = new XMLHttpRequest(); x.open('GET', base + f + '.jsx', false); x.send();
    if (x.status !== 200) { console.error('ds-fallback: missing ' + f); return; }
    var src = x.responseText.replace(/^import .*$/gm, '');
    var names = []; src.replace(/export (?:function|const) (\w+)/g, function (_, n) { names.push(n); });
    src = src.replace(/export (function|const)/g, '$1');
    var prior = Object.keys(ns).filter(function (n) { return names.indexOf(n) < 0; });
    var code = 'var __ns = window.__wgns; var {useState, useEffect, useRef, useId} = React; var {' + prior.join(',') + '} = __ns;\n' + src + '\nreturn {' + names.join(',') + '};';
    var out = Babel.transform('(function(){' + code + '})', { presets: ['react'] }).code;
    window.__wgns = ns;
    Object.assign(ns, (0, eval)(out)());
  });
  window[NS] = ns;
})();
