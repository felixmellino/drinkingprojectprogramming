/** @startingPoint section="Navigation" subtitle="6-destination bottom bar with big central Check in" viewport="420x140" */
export interface BottomNavProps { active?: 'profile' | 'lobby' | 'checkin' | 'map' | 'leaderboard' | 'history'; onNavigate?: (id: string) => void; style?: React.CSSProperties; }
export declare function BottomNav(props: BottomNavProps): JSX.Element;
export declare const NAV_ITEMS: { id: string; label: string; icon: string; center?: boolean }[];
