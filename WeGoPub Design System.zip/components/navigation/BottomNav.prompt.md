Floating bottom bar with six destinations; the central + (Check in) is the primary action of the app.
```jsx
<BottomNav active="map" onNavigate={setScreen} />
```
Order: Profile · Lobby · Check in (+) · Map · Ranks · Photos. Short labels "Ranks"/"Photos" fit 390px; full names live in aria/page titles.
