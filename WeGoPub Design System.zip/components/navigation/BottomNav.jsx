import React from 'react';
import { Icon } from '../actions/Icon.jsx';
export const NAV_ITEMS = [
  { id: 'profile', label: 'Profile', icon: 'person' }, { id: 'lobby', label: 'Lobby', icon: 'group' },
  { id: 'checkin', label: 'Check in', icon: 'add', center: true }, { id: 'map', label: 'Map', icon: 'map' },
  { id: 'leaderboard', label: 'Ranks', icon: 'leaderboard' }, { id: 'history', label: 'Photos', icon: 'photo_library' }];
export function BottomNav({ active = 'map', onNavigate, style }) {
  const items = [NAV_ITEMS[0], NAV_ITEMS[1], NAV_ITEMS[3], NAV_ITEMS[2], NAV_ITEMS[4], NAV_ITEMS[5]];
  return <nav className="wg-nav" aria-label="Main" style={style}>{items.map(it =>
    <button key={it.id} type="button" className={it.center ? 'wg-nav__center' : undefined} aria-current={active === it.id ? 'page' : undefined} onClick={() => onNavigate && onNavigate(it.id)}>
      {it.center ? <span className="wg-nav__plus"><Icon name="add" /></span> : <Icon name={it.icon} />}<span>{it.label}</span></button>)}</nav>;
}
