import React from 'react';
import { Icon } from '../actions/Icon.jsx';
export function Checkbox({ label, checked, defaultChecked, onChange, hint }) {
  return <label className="wg-check"><input type="checkbox" checked={checked} defaultChecked={defaultChecked} onChange={e => onChange && onChange(e.target.checked)} />
    <span className="wg-check__box"><Icon name="check" /></span><span>{label}{hint && <span className="wg-hint" style={{ display: 'block' }}>{hint}</span>}</span></label>;
}
