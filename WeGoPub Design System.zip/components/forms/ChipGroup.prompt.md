Horizontally scrolling single-select chips (map quick-zoom, filters).
```jsx
<ChipGroup floating value="Bairro Alto" options={[{value:'Me',label:'Me',icon:'my_location'},'Bairro Alto','Lisbon','Nova SBE','All']} />
```
