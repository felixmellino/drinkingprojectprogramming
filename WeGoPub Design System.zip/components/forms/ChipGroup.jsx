import React from 'react';
import { Icon } from '../actions/Icon.jsx';
export function ChipGroup({ options = [], value, onChange, floating }) {
  return <div className="wg-chips">{options.map(o => { const v = typeof o === 'string' ? o : o.value;
    return <button key={v} type="button" className={'wg-chip' + (floating ? ' wg-chip--float' : '')} aria-pressed={v === value} onClick={() => onChange && onChange(v)}>
      {o.icon && <Icon name={o.icon} />}{typeof o === 'string' ? o : o.label}</button>; })}</div>;
}
