export interface TextInputProps { label?: string; type?: 'text' | 'email' | 'password'; value?: string; defaultValue?: string; placeholder?: string; icon?: string; readOnly?: boolean; error?: string; hint?: string; onChange?: (v: string) => void; autoComplete?: string; name?: string; }
export declare function TextInput(props: TextInputProps): JSX.Element;
export declare function PasswordInput(props: TextInputProps): JSX.Element;
