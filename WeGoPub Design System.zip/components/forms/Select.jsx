import React from 'react';
import { Icon } from '../actions/Icon.jsx';
export function Select({ label, options = [], value, defaultValue, onChange, icon }) {
  const id = React.useId();
  return <div className="wg-field">{label && <label htmlFor={id}>{label}</label>}
    <div className="wg-input">{icon && <Icon name={icon} />}
      <select id={id} value={value} defaultValue={defaultValue} onChange={e => onChange && onChange(e.target.value)}>
        {options.map(o => typeof o === 'string' ? <option key={o}>{o}</option> : <option key={o.value} value={o.value}>{o.label}</option>)}
      </select><Icon name="expand_more" /></div></div>;
}
