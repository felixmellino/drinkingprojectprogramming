export interface ChoiceTilesProps { options: { value: string; label: string; icon?: string; sub?: string }[]; value?: string; onChange?: (v: string) => void; columns?: number; label?: string; }
export declare function ChoiceTiles(props: ChoiceTilesProps): JSX.Element;
