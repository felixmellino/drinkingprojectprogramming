Big icon tiles for the drink picker (styled Streamlit radio).
```jsx
<ChoiceTiles value="beer" options={[{value:'beer',label:'Beer',icon:'sports_bar'},{value:'wine',label:'Wine',icon:'wine_bar'},{value:'shot',label:'Shot',icon:'liquor'},{value:'mixed',label:'Mixed',icon:'local_bar'}]} />
```
