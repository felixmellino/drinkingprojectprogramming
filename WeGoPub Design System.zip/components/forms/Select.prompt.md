Native select styled like TextInput with a chevron.
```jsx
<Select label="Timezone" icon="public" options={['Europe/Lisbon','Europe/London']} />
```
