export interface CheckboxProps { label: React.ReactNode; checked?: boolean; defaultChecked?: boolean; onChange?: (v: boolean) => void; hint?: string; }
export declare function Checkbox(props: CheckboxProps): JSX.Element;
