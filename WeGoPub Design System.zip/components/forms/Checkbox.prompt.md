Native checkbox with a 24px custom box and 44px row.
```jsx
<Checkbox label="Remember me on this device" hint="30 days" defaultChecked />
```
