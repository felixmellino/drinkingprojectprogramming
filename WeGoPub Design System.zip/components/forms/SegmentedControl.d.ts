export interface SegmentedControlProps { options: (string | { value: string; label: string; sub?: string })[]; value?: string; onChange?: (v: string) => void; label?: string; }
export declare function SegmentedControl(props: SegmentedControlProps): JSX.Element;
