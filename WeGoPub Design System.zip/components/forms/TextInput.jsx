import React, { useState } from 'react';
import { Icon } from '../actions/Icon.jsx';
export function TextInput({ label, type = 'text', value, defaultValue, placeholder, icon, readOnly, error, hint, onChange, autoComplete, name }) {
  const [show, setShow] = useState(false);
  const isPw = type === 'password';
  const id = React.useId();
  return <div className="wg-field">
    {label && <label htmlFor={id}>{label}</label>}
    <div className={'wg-input' + (readOnly ? ' wg-input--readonly' : '') + (error ? ' wg-input--error' : '')}>
      {icon && <Icon name={icon} />}
      <input id={id} name={name} type={isPw && show ? 'text' : type} value={value} defaultValue={defaultValue} placeholder={placeholder} readOnly={readOnly} autoComplete={autoComplete}
        aria-invalid={!!error} onChange={e => onChange && onChange(e.target.value)} />
      {readOnly && <Icon name="lock" />}
      {isPw && <button type="button" onClick={() => setShow(s => !s)} aria-label={show ? 'Hide password' : 'Show password'} style={{ border: 0, background: 'none', color: 'inherit', cursor: 'pointer', display: 'grid', placeItems: 'center', minWidth: 44, minHeight: 44, marginRight: -10 }}><Icon name={show ? 'visibility_off' : 'visibility'} /></button>}
    </div>
    {error ? <span className="wg-hint wg-hint--error"><Icon name="error" />{error}</span> : hint ? <span className="wg-hint">{hint}</span> : null}
  </div>;
}
export function PasswordInput(props) { return <TextInput {...props} type="password" />; }
