import React from 'react';
import { Icon } from '../actions/Icon.jsx';
export function ChoiceTiles({ options = [], value, onChange, columns = 4, label }) {
  return <div className="wg-tiles" role="group" aria-label={label} style={{ gridTemplateColumns: 'repeat(' + columns + ',minmax(0,1fr))' }}>
    {options.map(o => <button key={o.value} type="button" className="wg-tile" aria-pressed={o.value === value} onClick={() => onChange && onChange(o.value)}>
      {o.icon && <Icon name={o.icon} fill={o.value === value} />}<span>{o.label}</span>{o.sub && <small>{o.sub}</small>}</button>)}
  </div>;
}
