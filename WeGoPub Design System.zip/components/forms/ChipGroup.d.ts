export interface ChipGroupProps { options: (string | { value: string; label: string; icon?: string })[]; value?: string; onChange?: (v: string) => void; /** Blurred HUD style for use over the map */ floating?: boolean; }
export declare function ChipGroup(props: ChipGroupProps): JSX.Element;
