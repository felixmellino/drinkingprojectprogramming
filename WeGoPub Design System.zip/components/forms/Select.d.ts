export interface SelectProps { label?: string; options: (string | { value: string; label: string })[]; value?: string; defaultValue?: string; onChange?: (v: string) => void; icon?: string; }
export declare function Select(props: SelectProps): JSX.Element;
