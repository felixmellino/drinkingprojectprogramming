Labelled text field (50px) with optional leading icon, read-only lock, error line and password show/hide.
```jsx
<TextInput label="Email" type="email" icon="mail" />
<PasswordInput label="Password" hint="At least 8 characters" />
<TextInput label="Email" value="rita@novasbe.pt" readOnly />
```
