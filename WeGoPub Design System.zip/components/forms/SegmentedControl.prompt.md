Equal-width toggle group (Streamlit segmented_control / horizontal radio). Optional second line for ml sizes.
```jsx
<SegmentedControl value="medium" options={[{value:'small',label:'Small',sub:'250 ml'},{value:'medium',label:'Medium',sub:'330 ml'},{value:'large',label:'Large',sub:'500 ml'}]} />
```
