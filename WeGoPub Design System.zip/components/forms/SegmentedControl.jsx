import React from 'react';
export function SegmentedControl({ options = [], value, onChange, label }) {
  return <div className="wg-seg" role="group" aria-label={label}>
    {options.map(o => { const v = typeof o === 'string' ? o : o.value; return <button key={v} type="button" aria-pressed={v === value} onClick={() => onChange && onChange(v)}>
      {typeof o === 'string' ? o : o.label}{o.sub && <small>{o.sub}</small>}</button>; })}
  </div>;
}
