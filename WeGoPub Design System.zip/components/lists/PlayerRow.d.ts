export interface PlayerRowProps { rank: number; name: string; src?: string; sub?: string; score: React.ReactNode; unit?: string; you?: boolean; }
export declare function PlayerRow(props: PlayerRowProps): JSX.Element;
