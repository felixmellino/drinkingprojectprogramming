Leaderboard row: rank badge (medals for top 3), avatar, username + YOU marker, big score.
```jsx
<PlayerRow rank={2} name="rita" you score="12.25" sub="3 territories" />
```
