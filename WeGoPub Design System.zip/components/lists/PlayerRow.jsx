import React from 'react';
import { Avatar } from '../identity/Avatar.jsx';
import { RankBadge, YouTag } from '../identity/RankBadge.jsx';
export function PlayerRow({ rank, name, src, sub, score, unit = 'pts', you }) {
  return <div className={'wg-row' + (you ? ' wg-row--you' : '')}>
    <RankBadge rank={rank} /><Avatar name={name} src={src} />
    <div style={{ minWidth: 0 }}><div className="wg-row__name"><span>{name}</span>{you && <YouTag />}</div>{sub && <div className="wg-row__sub">{sub}</div>}</div>
    <div className="wg-num wg-row__score">{score}<small>{unit}</small></div>
  </div>;
}
