# WeGoPub Design System

WeGoPub is a mobile-first social drinking game for student friend groups in Lisbon (19–26, nightlife, competitive banter). Players join a lobby with a 6-character invite code. During a season every drink counts: take a fresh photo, pick drink + size, the phone's GPS is read automatically. The drink earns season points, and if you are inside one of the territories (24 areas in central Lisbon + the Nova SBE campus) it also earns territory points there. Most points in a territory owns it; owners earn a 25% bonus when others drink there. Most season points wins. Think BeReal × Strava × Pokémon GO.

**One product, one surface:** a Streamlit (Python) web app used on phones at night, styled with CSS over native widgets, with a deck.gl + Carto map.

This system contains **six visual directions** that share one component set and one rule set. A direction is a token file (`tokens/themes/<id>.css`) applied with `data-theme="<id>"`. The default (`:root`) is **HYRO Night**, the recommended direction.

| id | Direction | Mood |
|---|---|---|
| `hyro-night` | HYRO Night (recommended, default) | Dark night game — charcoal, warm white, performance orange |
| `hyro-day` | HYRO Day | Same palette, daylight mode |
| `base-club` | Base Club | Loud social club — raspberry, mint stickers, hard shadows |
| `rush` | Rush | Retro bar crawl — midnight navy + old cream, vintage red wordmark |
| `tennis` | Tennis | Fresh match day — sky blue, cloud white, scarlet = rival only |
| `moon` | Moon | Calm premium editorial — slate, deep teal, serif numerals |

See `ui_kits/app/compare.html` for the side-by-side comparison, scores and recommendation, and `ui_kits/app/tokens.html` for pasteable `:root` + Streamlit `[theme]` code per direction.

## Sources
- GitHub: https://github.com/felixmellino/drinkingprojectprogramming (branch `main`). Read: `assets/navigation.css`, `assets/drink_entries.css`, `assets/standings.css`, `assets/lobbies.css`, `app_navigation.py`, `map_ui.py`, `lobby_ui.py`, `pages/3_Check_in.py`, `drink_entry_ui.py`, `core/scoring_v1.py`, `core/checkin_feedback.py`, `core/constants.py`. Explore `docs/ontology/SCREENS.md`, `RULES.md` and `GAME.md` there for deeper product rules — it will help you design more accurately.
- Uploaded colour references (Instagram screenshots, in `uploads/`): HYRO (charcoal #121212 / warm white #FDF9EA / orange #FE5105), Base Club (raspberry / mellow white / pastel turquoise), Rush (vintage red #B11722 / old cream #F0E1CE / midnight navy #1A2841), Tennis (sky blue #2C99D6 / cloud white #F8FAFC / scarlet #EB2F33), Kinetic (vermin red / snowy white / citrus yellow — not used: red accent conflicts with territory red).
- The design brief (in chat) defined the component inventory, screens and fixed constraints. The repo's current UI is a light green theme (`#176c50` accent, `#f5f7f2` bg); none of the six directions keeps green as an accent because green means "yours" on the map.

## Fixed rules (every direction)
1. **Territory colours:** green = yours, red = someone else's, grey = unclaimed (`--territory-yours|theirs|free`). Shades adapt per direction; hues never change.
2. **Accent is never red or green.** Buttons can't be confused with territory status.
3. **Status messages** (success/warning/error/info) always carry an icon *and* a text title. Colour is never the only signal. Territory pills also carry an icon (flag / swords / empty circle).
4. **Red only ever means "rival" or "error".** In Tennis the brand scarlet is that red; in Rush the vintage red is confined to the wordmark and 1st-place medal.
5. **Mint (Base Club) is a celebration colour** — YOU tag, success burst — and never appears on the Map screen.
6. Mobile first at 390×844; content max-width 720px on desktop. Touch targets ≥ 44px, primary actions 56px.
7. One icon set: Material Symbols Rounded. No emoji as UI icons (the repo's 🟢🔴⚪📍 legend should be replaced).
8. WCAG AA: text ≥ 4.5:1. Where the accent fails with white (orange, sky blue), buttons use dark text (`--on-accent`), and small accent-coloured text uses `--accent-ink`.

## CONTENT FUNDAMENTALS
- **Voice:** a friend keeping score. Second person ("You captured Shortys!", "You need 3 more points to take it"). Never "we" except for system problems ("We couldn't confirm the check-in was saved").
- **Tone:** playful, competitive, a bit cheeky, never childish or preachy. Banter lives in success moments and empty states ("Nice one. Catch your breath"), never in errors.
- **Casing:** Sentence case for everything — buttons ("Check in here", "Open lobby", "View results"), titles, alerts. Uppercase only via the display style tokens (HYRO, Tennis) and eyebrows.
- **Numbers first:** "+3 points", "2 / 24 yours · 19 free", "12.25". Points can be quarters (owner bonus = 0.25/point). Never show fake zeros while loading — use skeletons or "unavailable".
- **Be exact:** times include day + date + hour + zone ("Opens Thu 19 Nov at 18:00", "Ends Sun 6 Dec 2026, 18:00 WET"); accuracy in metres ("accurate to ±12 m"); sizes in ml ("Large · 500 ml").
- **Say what to do next:** every blocked state tells the fix ("Allow location for this site in your browser settings, then reload the page.", "Wait 1:24 before your next check-in. Your photo and selections stay here.").
- **Privacy said plainly:** "Only your username is public." "Shared only with your lobby."
- **No emoji** in UI copy. Unicode: `·` as separator, `…` for in-progress ("Finding you…"), `±`, `×` for multipliers.
- Product vocabulary: lobby, season, check in (verb) / check-in (noun), territory, owner, rival, unclaimed, season points, territory points, owner bonus, Memories (photo history), test season.

## VISUAL FOUNDATIONS
- **Colour:** each direction = background + surface + raised surface, one text colour + muted text, one accent (+ hover, ink, soft tint), plus the fixed territory set and four status colours. Soft status backgrounds are computed with `color-mix(in oklch, tone 12%, surface)`; no extra tokens.
- **Type:** one display face per direction (Archivo Expanded Black Italic / Bricolage Grotesque / Shrikhand / Anton / Instrument Serif) used only for screen titles, territory names and big numbers; one UI face (Archivo / DM Sans / Familjen Grotesk / Barlow / Geist). Numbers are tabular. Scale `--text-xs 12` → `--text-4xl 64` (Tennis/Moon/Rush adjust the top two).
- **Spacing:** 4-pt scale `--space-1 4px` … `--space-8 48px`. Screen gutters 16px, card padding 14–16px, section gap 22px.
- **Corners:** per direction — HYRO 8/14/22 + pill buttons; Base Club chunky 12/18/28; Rush badge-like 6/10/16 with square-ish buttons; Tennis tight 4/8/12; Moon 6/12/18.
- **Cards:** surface fill, 1px border (2px ink in Base Club / Rush), `--shadow-card`. Base Club uses a hard offset "sticker" shadow (4px 4px 0 ink) — pure CSS, works on Streamlit containers. Muted cards (past lobbies) drop opacity to .72 and lose their shadow.
- **Backgrounds:** flat colour only. No gradients except photo protection scrims (top of photo cards, bottom of camera). No textures or illustrations. Imagery = user photos (warm, flash-lit bar photos, shown big at 4:5) and the map.
- **Map:** full-bleed Carto base (dark_all for dark directions, Voyager/Positron for light). Territory fill ~36% opacity, 2.5px stroke in the territory colour; selected = 55% fill + text-coloured stroke. Names in bold 11px with a background-coloured halo. You = blue dot, white ring, pulsing halo + accuracy circle.
- **Map tiles in previews:** Carto raster tiles require an API key outside pydeck, so the UI kit previews use Esri's gray canvas tiles as a stand-in. Production keeps Carto via pydeck (`map_provider="carto"`).
- **Transparency & blur:** only for things floating over the map or content — HUD, chips, bottom nav, map card: `--hud-bg` (~85–94% opaque) + `backdrop-filter: blur(16px)`.
- **Layout:** fixed floating bottom nav (10px from edges) with the + raised 28px above it; screen content gets 120px bottom padding. Map screen: HUD top, chips under it, floating territory card above the nav.
- **Motion:** quick and purposeful. 120ms press, 220ms state, 420ms success. Press = `scale(.97)` (Base Club: translate 2px into its shadow). Success/capture = pop with overshoot (`--ease-pop`). Skeleton shimmer 1.4s. All disabled under `prefers-reduced-motion`.
- **Hover:** accent → `--accent-hover`; secondary → mix 20% toward text; ghost gains `--surface-raised`. Focus = 3px `--accent-ink` outline, 2px offset.
- **Selected:** chips invert (text on bg); tiles get accent border + soft tint; nav item gets filled icon in `--accent-ink` on raised pill.

## ICONOGRAPHY
- **Material Symbols Rounded** (Google Fonts CDN, variable: FILL 0/1, wght 500, opsz 24). The repo already uses `:material/…:` names in Streamlit, so the same names work in Python and HTML.
- Outline by default; **filled = active/selected** (active nav tab, selected drink, status-alert icons, "yours" flag).
- Sizes: 24 nav / 20 buttons / 22 alerts / 16 pills & hints / 28 tiles / 34 central +.
- Key glyphs: person, group, add, map, leaderboard, photo_library, photo_camera, add_a_photo, my_location, location_on, flag (yours), swords (rival), radio_button_unchecked (free), sports_bar, wine_bar, liquor, local_bar, timer, schedule, science (test season), bolt, refresh, share, emoji_events.
- No emoji, no custom SVG icons, no PNG icons. The repo's hand-drawn hero SVGs in `drink_entry_ui.py` are not carried over.
- **Logo:** none was provided. The wordmark is the name "WeGoPub" set in the direction's display face (see Brand → Wordmark card). No mark was drawn.

## Fonts (substitutions — please confirm)
All faces load from Google Fonts (`tokens/fonts.css`); no font binaries were supplied. Choices are matches to the references, not the brands' actual fonts: HYRO → Archivo Expanded Black Italic; Base Club → Bricolage Grotesque + DM Sans; Rush → Shrikhand + Familjen Grotesk; Tennis → Anton + Barlow; Moon → Instrument Serif + Geist.

## Components
React primitives in `components/` (all styled by `components/components.css`, class prefix `wg-`):
- actions: **Icon**, **Button** (primary / secondary / ghost / destructive; sm / md / lg; block), **IconButton** (default / ghost / accent / float)
- identity: **Avatar** (initials fallback), **RankBadge** + **YouTag**, **StatusPill** (yours / theirs / free / test / closed / live)
- forms: **TextInput** + **PasswordInput**, **Checkbox**, **Select**, **SegmentedControl**, **ChipGroup**, **ChoiceTiles**
- surfaces: **Card**, **StatCard**, **FloatingPanel** (HUD / map card), **PhotoCard**, **TerritoryCard**
- lists: **PlayerRow**
- feedback: **Alert**, **Toast**, **ProgressBar**, **Countdown**, **Skeleton**
- navigation: **BottomNav**
- game: **CameraFrame**, **MapLegend**

Intentional additions beyond the brief's list: **Icon** (wrapper for the Material Symbols ligature font), **Skeleton** (loading states), **ChoiceTiles** (drink picker).

## Index
- `styles.css` — entry point (imports only)
- `tokens/fonts.css`, `tokens/base.css` (spacing, type scale, motion, medals), `tokens/themes/*.css` (one per direction)
- `components/components.css` + `components/<group>/<Name>.jsx|.d.ts|.prompt.md` + one `*.card.html` per group
- `guidelines/*.html` — foundation cards (colours, type, spacing, radius, shadows, brand, icons, map styles)
- `ui_kits/app/` — `index.html` interactive kit, `compare.html` direction comparison, `tokens.html` pasteable code, screen JSX
- `thumbnail.html`, `SKILL.md`, `github.md`
