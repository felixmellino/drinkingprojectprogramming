// Slippy-map stand-in for the deck.gl + Carto map. Preview uses Esri Canvas gray tiles (Carto raster tiles need an API key outside pydeck).
const TILE = 256;
function mapProj(lat, lng, z) {
  const s = TILE * Math.pow(2, z), sin = Math.sin(lat * Math.PI / 180);
  return [(lng + 180) / 360 * s, (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * s];
}
function mapUnproj(x, y, z) {
  const s = TILE * Math.pow(2, z), lng = x / s * 360 - 180, n = Math.PI - 2 * Math.PI * y / s;
  return [180 / Math.PI * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n))), lng];
}
function polyFor(t) {
  let h = 0; for (const c of t.id) h = (h * 33 + c.charCodeAt(0)) >>> 0;
  const pts = [], n = 6, rot = (h % 60) * Math.PI / 180;
  for (let i = 0; i < n; i++) {
    const j = 0.78 + ((h >> (i * 3)) & 7) / 20, a = rot + i * 2 * Math.PI / n;
    pts.push([t.lat + Math.sin(a) * t.r * j / 111320, t.lng + Math.cos(a) * t.r * j / (111320 * Math.cos(t.lat * Math.PI / 180))]);
  }
  return pts;
}
const POLYS = {};
function MapView({ view, width, height, mapStyle, selected, onSelect, me = ME_POS, onPan, fit = 1 }) {
  const { lat, lng, z } = view;
  const zi = Math.max(0, Math.min(16, Math.round(z))), scale = Math.pow(2, z - zi);
  const [cx, cy] = mapProj(lat, lng, zi);
  const vw = width / scale, vh = height / scale, x0 = cx - vw / 2, y0 = cy - vh / 2;
  const tiles = [];
  for (let tx = Math.floor(x0 / TILE); tx <= Math.floor((x0 + vw) / TILE); tx++)
    for (let ty = Math.floor(y0 / TILE); ty <= Math.floor((y0 + vh) / TILE); ty++)
      tiles.push(<img key={tx + '_' + ty} alt="" draggable={false} src={`https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_${mapStyle === 'dark' ? 'Dark' : 'Light'}_Gray_Base/MapServer/tile/${zi}/${ty}/${tx}`}
        style={{ position: 'absolute', left: tx * TILE - x0, top: ty * TILE - y0, width: TILE, height: TILE }} />);
  const [fx, fy] = mapProj(lat, lng, z);
  const toPx = (la, ln) => { const [x, y] = mapProj(la, ln, z); return [x - fx + width / 2, y - fy + height / 2]; };
  const mPerPx = 156543.03 * Math.cos(lat * Math.PI / 180) / Math.pow(2, z);
  const drag = React.useRef(null);
  const down = e => { drag.current = { x: e.clientX, y: e.clientY, lat, lng, moved: false }; e.currentTarget.setPointerCapture(e.pointerId); };
  const move = e => { const d = drag.current; if (!d || !onPan) return; const dx = (e.clientX - d.x) / fit, dy = (e.clientY - d.y) / fit; if (Math.abs(dx) + Math.abs(dy) > 4) d.moved = true;
    if (d.moved) { const [px, py] = mapProj(d.lat, d.lng, z); const [la, ln] = mapUnproj(px - dx, py - dy, z); onPan({ lat: la, lng: ln, z }); } };
  const up = () => { setTimeout(() => { drag.current = null; }, 0); };
  const click = id => { if (drag.current && drag.current.moved) return; onSelect && onSelect(id); };
  const [mx, my] = toPx(me.lat, me.lng);
  return <div onPointerDown={down} onPointerMove={move} onPointerUp={up} style={{ position: 'absolute', inset: 0, overflow: 'hidden', background: 'var(--surface-raised)', touchAction: 'none', cursor: 'grab' }}>
    <div style={{ position: 'absolute', left: 0, top: 0, width: vw, height: vh, transform: `scale(${scale})`, transformOrigin: '0 0' }}>{tiles}</div>
    <svg width={width} height={height} style={{ position: 'absolute', inset: 0 }}>
      {TERRITORIES.map(t => { const s = statusOf(t), pts = (POLYS[t.id] ||= polyFor(t)).map(p => toPx(p[0], p[1]));
        const c = `var(--territory-${s})`, sel = selected === t.id;
        return <g key={t.id} onClick={() => click(t.id)} style={{ cursor: 'pointer' }}>
          <polygon points={pts.map(p => p.join(',')).join(' ')} style={{ fill: c, fillOpacity: sel ? .55 : .36, stroke: sel ? 'var(--text)' : c, strokeWidth: sel ? 3.5 : 2.5, strokeLinejoin: 'round' }} />
        </g>; })}
      {z >= 16.4 && TERRITORIES.map(t => { const [x, y] = toPx(t.lat, t.lng); return <text key={t.id} x={x} y={y + 4} textAnchor="middle" pointerEvents="none"
        style={{ font: '800 11px var(--font-body)', fill: 'var(--text)', stroke: 'var(--bg)', strokeWidth: 3.5, paintOrder: 'stroke', strokeLinejoin: 'round' }}>{t.name}</text>; })}
      <circle cx={mx} cy={my} r={Math.max(9, me.acc / mPerPx)} style={{ fill: 'var(--you-dot)', fillOpacity: .16, stroke: 'var(--you-dot)', strokeOpacity: .4 }} />
      <circle cx={mx} cy={my} r={8} style={{ fill: 'var(--you-dot)', transformBox: 'fill-box', transformOrigin: 'center', animation: 'wg-pulse 2s ease-out infinite' }} />
      <circle cx={mx} cy={my} r={8} style={{ fill: 'var(--you-dot)', stroke: '#fff', strokeWidth: 3 }} />
    </svg>
    <div style={{ position: 'absolute', right: 6, bottom: 2, fontSize: 9, color: 'var(--text-muted)', opacity: .8, pointerEvents: 'none' }}>Esri, HERE, Garmin, © OpenStreetMap</div>
  </div>;
}
Object.assign(window, { MapView, mapProj });
