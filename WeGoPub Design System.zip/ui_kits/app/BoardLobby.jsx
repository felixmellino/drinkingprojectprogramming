function LeaderboardScreen({ demo = {} }) {
  const [tab, setTab] = React.useState('season');
  const [loading, setLoading] = React.useState(false);
  const state = loading ? 'loading' : demo.board || 'ok';
  const me = PLAYERS.find(p => p.you), rank = PLAYERS.indexOf(me) + 1;
  const refresh = () => { setLoading(true); setTimeout(() => setLoading(false), 1200); };
  return <div style={{ padding: '54px 0 120px' }}>
    <ScreenHeader eyebrow={LOBBY.name + ' · Season 1'} title="Leaderboard" right={<IconButton icon="refresh" label="Refresh" onClick={refresh} />} />
    <div style={{ padding: '0 16px' }}>
      {state === 'unavailable' ? <Alert tone="error" title="Standings are unavailable" action={<Button size="sm" variant="secondary" onClick={refresh}>Retry</Button>}>We couldn't load the scores. Nothing is lost; try again in a moment.</Alert> : <>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1.3fr 1fr', gap: 8 }}>
          {state === 'loading' ? [0, 1, 2].map(i => <Skeleton key={i} h={96} r="var(--radius-lg)" />) : <>
            <StatCard accent label="Your rank" value={'#' + rank} sub={'of ' + PLAYERS.length} />
            <StatCard label="Season points" value={fmtPts(me.points)} sub={'6.25 behind ' + PLAYERS[0].name} />
            <StatCard label="Territories" value={me.terr} sub="owned" /></>}
        </div>
        <div style={{ margin: '16px 0 4px' }}><SegmentedControl value={tab} onChange={setTab} options={[{ value: 'season', label: 'Season' }, { value: 'territories', label: 'Territories' }]} /></div>
        {tab === 'season' ? <Card style={{ padding: 6, marginTop: 10 }}>
          {state === 'loading' ? [0, 1, 2, 3].map(i => <div key={i} style={{ display: 'flex', gap: 12, alignItems: 'center', padding: 10 }}><Skeleton w={34} h={34} /><Skeleton w={40} h={40} r={99} /><div style={{ flex: 1 }}><Skeleton w="60%" h={14} /></div><Skeleton w={44} h={24} /></div>)
            : PLAYERS.map((p, i) => <PlayerRow key={p.name} rank={i + 1} name={p.name} you={p.you} score={fmtPts(p.points)} sub={p.terr ? p.terr + (p.terr === 1 ? ' territory' : ' territories') : 'No territories'} />)}
        </Card> : <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginTop: 10 }}>
          {TERRITORIES.filter(t => Object.keys(t.pts).length).slice(0, 6).map(t => <TerritoryCard key={t.id} name={t.name} status={statusOf(t)} owner={t.owner === ME ? 'You' : t.owner}
            players={Object.entries(t.pts).sort((a, b) => b[1] - a[1]).map(([n, v]) => ({ name: n === ME ? 'You' : n, points: v, you: n === ME }))}
            note={statusOf(t) === 'theirs' ? `You need ${plural(neededFor(t), 'more point')} to take it.` : statusOf(t) === 'yours' ? `You lead by ${plural(leadBy(t), 'point')}.` : null} />)}
          <TerritoryCard name="Rua dos Mouros" status="free" />
        </div>}
        <div className="wg-hint" style={{ justifyContent: 'center', marginTop: 12 }}><Icon name="info" />Owner bonuses are 0.25 per point, so totals can end in .25 / .5 / .75</div>
      </>}
    </div>
  </div>;
}

function LobbyCard({ name, leader, active, test, ends, past, onOpen }) {
  return <Card variant={past ? 'muted' : undefined} style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 12, ...(active ? { borderColor: 'var(--accent)', boxShadow: 'var(--shadow-card), inset 0 0 0 1px var(--accent)' } : null) }}>
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>{active ? <StatusPill status="live">Running</StatusPill> : <StatusPill status="closed" icon="flag_check">Finished</StatusPill>}{test && <StatusPill status="test">Test season · opens Wed</StatusPill>}</div>
    <div className="wg-display" style={{ fontSize: 26 }}>{name}</div>
    <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontSize: 14 }}>{leader ? <><Avatar name={leader} size={32} /><span>{past ? 'Winner' : 'Leader'}: <b>{leader}</b></span></> : <><span className="wg-avatar" style={{ '--size': '32px', '--av-bg': 'var(--surface-raised)', color: 'var(--text-muted)' }}><Icon name="person_off" size={18} /></span><span className="wg-muted">No Leader yet</span></>}</div>
    {active ? <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 10 }}><Countdown seconds={ends} compact /><span className="wg-muted" style={{ fontSize: 12, textAlign: 'right' }}>Ends<br />{LOBBY.endsAt}</span></div>
      : <span className="wg-muted" style={{ fontSize: 13 }}>Finished {ends}</span>}
    <Button variant={active ? 'primary' : 'secondary'} block onClick={onOpen}>{past ? 'View results' : 'Open lobby'}</Button>
  </Card>;
}

function LobbyScreen({ go, demo = {} }) {
  const [panel, setPanel] = React.useState(null);
  const [dur, setDur] = React.useState('1 month');
  const [code, setCode] = React.useState('');
  const empty = demo.lobby === 'empty';
  return <div style={{ padding: '54px 0 120px' }}>
    <ScreenHeader eyebrow="Your lobbies" title="Lobby" />
    <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
        <Button variant={panel === 'create' ? 'primary' : 'secondary'} icon="add_circle" onClick={() => setPanel(panel === 'create' ? null : 'create')}>Create</Button>
        <Button variant={panel === 'join' ? 'primary' : 'secondary'} icon="key" onClick={() => setPanel(panel === 'join' ? null : 'join')}>Join with code</Button>
      </div>
      {panel === 'create' && <Card style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
        <TextInput label="Lobby name" placeholder="e.g. Thursday Crew" />
        <div><div className="wg-label" style={{ marginBottom: 8 }}>Duration</div><SegmentedControl value={dur} onChange={setDur} options={['1 week', '1 month', '3 months']} /></div>
        <Select label="Timezone" icon="public" options={['Europe/Lisbon', 'Europe/London', 'Europe/Madrid']} />
        <Checkbox label="Test season" hint="Opens Wednesday 08:00 instead of Thursday 18:00. Labelled everywhere." />
        <Button block icon="rocket_launch">Create lobby</Button>
      </Card>}
      {panel === 'join' && <Card style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <TextInput label="Invite code" placeholder="6 characters" value={code} onChange={v => setCode(v.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6))} hint={code.length + ' / 6'} />
        <Button block disabled={code.length !== 6} icon="login">Join lobby</Button>
      </Card>}
      {demo.lobby === 'setup' && <Alert tone="error" title="Lobby setup failed" action={<Button size="sm" variant="secondary">Retry</Button>}>Fridays League couldn't start. Check the timezone, then retry.</Alert>}
      {empty ? <EmptyState icon="group_add" title="No lobby yet" action={<Button icon="add_circle" onClick={() => setPanel('create')}>Create a lobby</Button>}>Create one for your group, or join with the 6-character code a friend sent you.</EmptyState> : <>
        <SectionTitle>Active</SectionTitle>
        <LobbyCard active name={LOBBY.name} leader="ana.lx" ends={LOBBY.endsIn} onOpen={() => go('leaderboard')} />
        <Card variant="raised" style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12 }}>
          <div style={{ flex: 1 }}><div className="wg-stat__label">Invite code</div><div className="wg-num" style={{ fontSize: 26, letterSpacing: '.12em', marginTop: 4 }}>{LOBBY.code}</div></div>
          <IconButton icon="content_copy" label="Copy code" /><IconButton icon="share" label="Share code" variant="accent" /></Card>
        <LobbyCard active test name="Erasmus Test Run" ends={5 * 86400 + 3600} />
        <SectionTitle>Past</SectionTitle>
        <LobbyCard past name="Freshers Week" leader="joao_b" ends="12 Oct 2026, 18:00 WEST" />
      </>}
    </div>
  </div>;
}
Object.assign(window, { LeaderboardScreen, LobbyScreen });
