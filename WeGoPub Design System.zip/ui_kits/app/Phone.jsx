const DIRS = window.WGP_DIRECTIONS;
function StatusBar() {
  return <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 47, zIndex: 40, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '4px 28px 0 34px', fontWeight: 700, fontSize: 16, pointerEvents: 'none', color: 'var(--text)' }}>
    <span>23:41</span><span style={{ display: 'flex', gap: 5, alignItems: 'center' }}><Icon name="signal_cellular_alt" size={18} /><Icon name="wifi" size={18} /><Icon name="battery_5_bar" size={20} style={{ transform: 'rotate(90deg)' }} /></span></div>;
}
function Phone({ theme = 'hyro-night', screen, setScreen, demo = {}, frame = true }) {
  const dir = DIRS.find(d => d.id === theme) || DIRS[0];
  const go = s => setScreen(s);
  const S = { map: MapScreen, checkin: CheckinScreen, leaderboard: LeaderboardScreen, lobby: LobbyScreen, profile: ProfileScreen, history: MemoriesScreen, login: LoginScreen }[screen] || MapScreen;
  const scrollRef = React.useRef(null);
  React.useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = 0; }, [screen]);
  return <div data-theme={theme} className="wg-app" data-screen-label={screen} style={{ position: 'relative', width: 390, height: 844, overflow: 'hidden', borderRadius: frame ? 48 : 0, boxShadow: frame ? '0 0 0 10px #0a0a0a, 0 0 0 11px #333, 0 30px 80px rgba(0,0,0,.45)' : 'none', flex: 'none' }}>
    <StatusBar />
    {screen === 'map' ? <S go={go} demo={demo} mapStyle={dir.scheme} /> :
      <div ref={scrollRef} style={{ height: '100%', overflowY: 'auto', scrollbarWidth: 'none' }}><S key={screen + JSON.stringify(demo)} go={go} demo={demo} /></div>}
    {screen !== 'login' && <div style={{ position: 'absolute', left: 10, right: 10, bottom: 10, zIndex: 25 }}><BottomNav active={screen} onNavigate={go} /></div>}
  </div>;
}
Object.assign(window, { Phone, DIRS });
