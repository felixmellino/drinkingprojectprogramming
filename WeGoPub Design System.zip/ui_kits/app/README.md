# WeGoPub app — UI kit

Interactive recreation of the WeGoPub mobile web app (Streamlit) at 390×844.

- `index.html` — click-through prototype. Left panel switches direction (6 themes), screen and demo states (location, season gate, submit errors, empty/loading/unavailable, auth errors…). State persists in localStorage.
- `compare.html` — all six directions × five key screens, pros/cons, scores and recommendation.
- `tokens.html` — pasteable `:root` tokens + `[theme]` blocks + a Streamlit widget CSS starter.
- `directions.js` — the direction data (generated together with `tokens/themes/*.css`).
- `data.jsx` mock lobby/territories/players · `MapView.jsx` Carto tile map stand-in for deck.gl · `MapScreen.jsx` · `CheckinScreen.jsx` · `BoardLobby.jsx` (Leaderboard + Lobby) · `ProfileMemories.jsx` (Profile, Edit profile, Friends, Security, Minigame concept, Memories, Login) · `Phone.jsx` frame + nav.

Territory polygons are illustrative hexagons placed at approximate real coordinates — the repo's territory GeoJSON was not imported. Photos are placeholders.
