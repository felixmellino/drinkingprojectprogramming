function TerritoryDetail({ t, here, onCheckin, onClose }) {
  const s = statusOf(t), need = neededFor(t), lead = leadBy(t);
  const msg = s === 'free' ? 'Unclaimed: your drink claims it.' : s === 'yours' ? `You own it · leading by ${plural(lead, 'point')}.` : `You need ${plural(need, 'more point')} to take it.`;
  return <FloatingPanel style={{ padding: 16 }}>
    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div className="wg-eyebrow" style={{ display: 'flex', alignItems: 'center', gap: 4 }}><Icon name={here ? 'my_location' : 'location_on'} size={14} />{here ? 'You are in' : 'Territory'}</div>
        <div className="wg-display" style={{ fontSize: 26, marginTop: 4 }}>{t.name}</div>
      </div>
      <StatusPill status={s} />
      {!here && <IconButton icon="close" label="Close" variant="ghost" onClick={onClose} style={{ marginTop: -8, marginRight: -8 }} />}
    </div>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8, margin: '12px 0' }}>
      <div><div className="wg-stat__label">Owner</div><div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 4, fontWeight: 750, fontSize: 14, minWidth: 0 }}>{t.owner ? <><Avatar name={t.owner} size={22} /><span style={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>{t.owner === ME ? 'You' : t.owner}</span></> : <span className="wg-muted">Nobody</span>}</div></div>
      <div><div className="wg-stat__label">Your points</div><div className="wg-num" style={{ fontSize: 22, marginTop: 4 }}>{myPts(t)}</div></div>
      <div><div className="wg-stat__label">{s === 'theirs' ? 'To take it' : s === 'yours' ? 'Your lead' : 'To claim'}</div><div className="wg-num" style={{ fontSize: 22, marginTop: 4, color: 'var(--accent-ink)' }}>{s === 'theirs' ? '+' + need : s === 'yours' ? '+' + lead : '+1'}</div></div>
    </div>
    <div style={{ fontSize: 14, fontWeight: 650 }}>{msg}</div>
    {s === 'theirs' && <div className="wg-hint" style={{ marginTop: 4 }}><Icon name="percent" />{t.owner} earns a 25% bonus when you drink here.</div>}
    {here && <div style={{ marginTop: 14 }}><Button size="lg" block icon="add_a_photo" onClick={onCheckin}>Check in here</Button></div>}
  </FloatingPanel>;
}

function TerritorySheet({ onClose, onPick }) {
  const order = { yours: 0, theirs: 1, free: 2 };
  const rows = [...TERRITORIES].sort((a, b) => order[statusOf(a)] - order[statusOf(b)] || a.name.localeCompare(b.name));
  return <div style={{ position: 'absolute', inset: 0, zIndex: 20, background: 'rgba(0,0,0,.35)', display: 'flex', alignItems: 'flex-end' }} onClick={onClose}>
    <div className="wg-card" onClick={e => e.stopPropagation()} style={{ width: '100%', maxHeight: '72%', overflow: 'auto', borderRadius: 'var(--radius-lg) var(--radius-lg) 0 0', padding: '8px 16px 24px' }}>
      <div style={{ width: 40, height: 5, borderRadius: 9, background: 'var(--border)', margin: '4px auto 10px' }} />
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}><h2 style={{ margin: 0, fontSize: 18, fontWeight: 800 }}>All territories</h2><IconButton icon="close" label="Close" variant="ghost" onClick={onClose} /></div>
      <MapLegend style={{ margin: '6px 0 10px' }} />
      <div className="wg-list">{rows.map(t => { const s = statusOf(t); return <button key={t.id} className="wg-listrow" onClick={() => onPick(t.id)} style={{ background: 'none', border: 0, borderBottom: '1px solid var(--border)', color: 'inherit', font: 'inherit', textAlign: 'left', cursor: 'pointer', width: '100%' }}>
        <span style={{ width: 10, height: 36, borderRadius: 4, background: `var(--territory-${s})`, flex: 'none' }} />
        <div style={{ flex: 1, minWidth: 0 }}><div style={{ fontWeight: 750, fontSize: 15 }}>{t.name}</div><div className="wg-row__sub">{t.owner ? (t.owner === ME ? 'Yours' : 'Owned by ' + t.owner) : 'Unclaimed'} · you have {myPts(t)}</div></div>
        <span className="wg-muted" style={{ fontSize: 13, fontWeight: 700 }}>{s === 'theirs' ? '+' + neededFor(t) + ' to take' : s === 'free' ? 'Claim' : 'Owned'}</span></button>; })}</div>
    </div></div>;
}

function MapScreen({ go, mapStyle, w = 390, h = 844 }) {
  const [focus, setFocus] = React.useState('Bairro Alto');
  const [view, setView] = React.useState(VIEWS['Bairro Alto']);
  const [sel, setSel] = React.useState(null);
  const [sheet, setSheet] = React.useState(false);
  const yours = TERRITORIES.filter(t => statusOf(t) === 'yours').length, free = TERRITORIES.filter(t => statusOf(t) === 'free').length, theirs = TERRITORIES.length - yours - free;
  const pick = f => { setFocus(f); setView(VIEWS[f]); };
  const t = TERRITORIES.find(x => x.id === (sel || CURRENT));
  return <div style={{ position: 'absolute', inset: 0 }}>
    <MapView view={view} width={w} height={h} mapStyle={mapStyle} selected={sel || CURRENT} onSelect={id => setSel(id === CURRENT ? null : id)} onPan={v => { setView(v); setFocus(null); }} />
    <div style={{ position: 'absolute', top: 54, left: 12, right: 12, display: 'flex', flexDirection: 'column', gap: 10 }}>
      <FloatingPanel style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 10px 10px 14px' }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 800, fontSize: 16, display: 'flex', alignItems: 'center', gap: 6 }}>{LOBBY.name}<span className="wg-pill wg-pill--live" style={{ height: 22, fontSize: 11 }}><Icon name="bolt" />Live</span></div>
          <div style={{ display: 'flex', gap: 12, fontSize: 13, fontWeight: 650, marginTop: 3, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>
            <span><b className="wg-num" style={{ color: 'var(--territory-yours)', fontSize: 15 }}>{yours}</b> / {TERRITORIES.length} yours</span><span><b style={{ color: 'var(--text)' }}>{theirs}</b> rival</span><span><b style={{ color: 'var(--text)' }}>{free}</b> free</span></div>
        </div>
        <IconButton icon="format_list_bulleted" label="All territories" onClick={() => setSheet(true)} />
      </FloatingPanel>
      <ChipGroup floating value={focus} onChange={pick} options={[{ value: 'Me', label: 'Me', icon: 'my_location' }, 'Bairro Alto', 'Lisbon', 'Nova SBE', 'All']} />
    </div>
    <div style={{ position: 'absolute', left: 12, right: 12, bottom: 100 }}>
      <TerritoryDetail t={t} here={!sel} onCheckin={() => go('checkin')} onClose={() => setSel(null)} />
    </div>
    {sheet && <TerritorySheet onClose={() => setSheet(false)} onPick={id => { setSheet(false); setSel(id === CURRENT ? null : id); const x = TERRITORIES.find(t => t.id === id); setView({ lat: x.lat, lng: x.lng, z: x.id === 'nova-sbe' ? 16.4 : 17.4 }); setFocus(null); }} />}
  </div>;
}
Object.assign(window, { MapScreen });
