const LOC = {
  finding: { tone: 'info', icon: 'location_searching', title: 'Finding you…', body: 'Allow location access if your browser asks.', ok: false },
  found: { tone: 'success', icon: 'my_location', title: 'Location found', body: 'Accurate to ±12 m. Updates automatically.', ok: true },
  imprecise: { tone: 'warning', icon: 'location_disabled', title: 'Not precise enough', body: 'Only accurate to ±80 m (we need 50 m or better). Step outside or wait a moment.', ok: false },
  blocked: { tone: 'error', icon: 'location_off', title: 'Location is blocked', body: 'Open your browser settings → Site settings → Location → Allow, then reload.', ok: false },
  outside: { tone: 'info', icon: 'wrong_location', title: 'Outside all territories', body: 'Accurate to ±9 m. This drink earns season points only.', ok: true },
  stale: { tone: 'warning', icon: 'history', title: 'Reading too old', body: 'Your last location is over a minute old. Refreshing…', ok: false },
};
function LocationCard({ state }) {
  const l = LOC[state], t = TERRITORIES.find(x => x.id === CURRENT), s = statusOf(t), need = neededFor(t);
  return <Card style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 12 }}>
    <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
      <span style={{ display: 'grid', placeItems: 'center', width: 44, height: 44, borderRadius: 'var(--radius-md)', flex: 'none', background: `color-mix(in oklch, var(--${l.tone}) 16%, var(--surface))`, color: `var(--${l.tone})` }}><Icon name={l.icon} fill size={24} /></span>
      <div style={{ minWidth: 0 }}><b style={{ fontSize: 15 }}>{l.title}</b><div className="wg-muted" style={{ fontSize: 13, lineHeight: 1.35 }}>{l.body}</div></div>
      {state === 'finding' || state === 'stale' ? <Skeleton w={24} h={24} r={99} style={{ marginLeft: 'auto', flex: 'none' }} /> : null}
    </div>
    {state === 'found' && <div style={{ borderTop: '1px solid var(--border)', paddingTop: 12, display: 'flex', flexDirection: 'column', gap: 8 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 8 }}><div><div className="wg-stat__label">Detected territory</div><div style={{ fontWeight: 800, fontSize: 18 }}>{t.name}</div></div><StatusPill status={s} /></div>
      <div className="wg-terr__owner"><Avatar name={t.owner} size={26} /><span>Owned by <b>{t.owner}</b> · {t.pts[t.owner]} pts vs your {myPts(t)}</span></div>
      <div style={{ fontSize: 14, fontWeight: 700 }}>You need {plural(need, 'more point')} to take it.</div>
      <div className="wg-hint"><Icon name="percent" />{t.owner} earns a 25% bonus on your drink here. Your points stay the same.</div>
    </div>}
  </Card>;
}

function CheckinSuccess({ points, captured, onDone, onMap }) {
  return <div style={{ position: 'absolute', inset: 0, zIndex: 30, background: 'var(--bg)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 16, padding: 28, textAlign: 'center' }}>
    <span className="wg-pop" style={{ display: 'grid', placeItems: 'center', width: 96, height: 96, borderRadius: '50%', background: 'var(--accent)', color: 'var(--on-accent)' }}><Icon name={captured ? 'flag' : 'check'} fill size={52} /></span>
    <div className="wg-num wg-pop" style={{ fontSize: 'var(--text-4xl)', color: 'var(--accent-ink)', animationDelay: '80ms' }}>+{points}</div>
    <div className="wg-eyebrow">season points · +{points} territory points</div>
    {captured && <><div className="wg-display wg-pop" style={{ fontSize: 'var(--text-2xl)', animationDelay: '160ms' }}>You captured Shortys!</div>
      <StatusPill status="yours">Shortys is now yours</StatusPill>
      <div className="wg-muted" style={{ fontSize: 14, maxWidth: 290 }}>ana.lx also earned 0.75 season points as the previous owner. You kept all your points.</div></>}
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10, width: '100%', marginTop: 10 }}><Button size="lg" block icon="map" onClick={onMap}>See it on the map</Button><Button variant="ghost" block onClick={onDone}>Done</Button></div>
  </div>;
}

function CheckinScreen({ go, demo = {} }) {
  const gate = demo.gate || 'open', loc = demo.loc || 'found', result = demo.result || 'success';
  const [shot, setShot] = React.useState(!!demo.captured);
  const [drink, setDrink] = React.useState('beer');
  const [size, setSize] = React.useState('large');
  const [done, setDone] = React.useState(null);
  const [err, setErr] = React.useState(null);
  const pts = drink === 'shot' ? POINTS.shot.standard : POINTS[drink][size];
  const sizes = ['small', 'medium', 'large'].map(v => ({ value: v, label: v[0].toUpperCase() + v.slice(1), sub: VOLUMES[drink] ? VOLUMES[drink][v] + ' ml' : undefined }));
  const blockers = [gate !== 'open' && 'Scoring is not open', !shot && 'Take a photo first', !LOC[loc].ok && 'Waiting for an accurate location'].filter(Boolean);
  const submit = () => { if (result === 'success') { setDone({ points: pts, captured: loc === 'found' && myPts(TERRITORIES[0]) + pts > 9 }); } else setErr(result); };
  const ERR = { save: ["Couldn't save your check-in", 'Check your connection. Your photo and choices are kept.'], duplicate: ['Already logged', 'You logged this drink a moment ago.'], accuracy: ['Location not accurate enough', 'Wait a moment, then submit again.'] };
  if (gate !== 'open') {
    const G = { closed: ['schedule', 'Scoring is closed', 'Opens Thu 19 Nov at 18:00', 2 * 3600 + 18 * 60], cooldown: ['timer', 'Nice one. Catch your breath', 'Wait before your next check-in. Your photo and selections stay here.', 84], ended: ['emoji_events', 'This season has ended', 'ana.lx won Thursday Crew with 18.5 points. Start a new season from Lobby.', 0] }[gate];
    return <div style={{ padding: '54px 0 120px' }}><ScreenHeader eyebrow={LOBBY.name} title="Check in" />
      <div style={{ padding: '0 20px' }}><EmptyState icon={G[0]} title={G[1]} action={gate === 'ended' ? <Button variant="secondary" onClick={() => go('lobby')}>Go to Lobby</Button> : G[3] ? <Countdown seconds={G[3]} inline={gate === 'cooldown'} /> : null}>{G[2]}</EmptyState></div></div>;
  }
  return <div style={{ padding: '54px 0 120px' }}>
    <ScreenHeader eyebrow={LOBBY.name + ' · Thu 19 Nov 23:41'} title="Check in" right={demo.test ? <StatusPill status="test" /> : null} />
    <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 14 }}>
      <CameraFrame state={demo.camera === 'blocked' ? 'blocked' : shot ? 'captured' : 'live'} onShutter={() => setShot(true)} onRetake={() => setShot(false)} onRetry={() => {}} />
      {shot && <>
        <div><div className="wg-label" style={{ marginBottom: 8 }}>Drink</div><ChoiceTiles value={drink} onChange={setDrink} options={DRINKS} label="Drink" /></div>
        {drink !== 'shot' ? <div><div className="wg-label" style={{ marginBottom: 8 }}>Size</div><SegmentedControl value={size} onChange={setSize} options={sizes} label="Size" /></div>
          : <div className="wg-hint"><Icon name="info" />One shot serving. No size needed.</div>}
        <Card variant="raised" style={{ padding: 14, display: 'flex', alignItems: 'center', gap: 14 }}>
          <span className="wg-num" style={{ fontSize: 44, color: 'var(--accent-ink)' }}>+{pts}</span>
          <div style={{ fontSize: 14, lineHeight: 1.35 }}><b>season points</b><div className="wg-muted">+{pts} territory points if you're in a territory</div></div>
        </Card>
      </>}
      <LocationCard state={loc} />
      {err && <Alert tone="error" title={ERR[err][0]} action={<Button size="sm" variant="secondary" onClick={() => setErr(null)}>Retry</Button>}>{ERR[err][1]}</Alert>}
      {blockers.length > 0 && <div className="wg-hint" style={{ justifyContent: 'center' }}><Icon name="block" />{blockers[0]}</div>}
      <Button size="lg" block icon="send" disabled={blockers.length > 0} onClick={submit}>Submit · +{pts}</Button>
      <div className="wg-hint" style={{ justifyContent: 'center', textAlign: 'center' }}>Shared only with your lobby with your username, time and territory.</div>
    </div>
    {done && <CheckinSuccess {...done} onDone={() => { setDone(null); setShot(false); }} onMap={() => go('map')} />}
  </div>;
}
Object.assign(window, { CheckinScreen });
