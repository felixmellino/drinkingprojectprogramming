function BackBar({ onBack, title }) {
  return <div style={{ display: 'flex', alignItems: 'center', gap: 4, padding: '0 8px 6px' }}><Button variant="ghost" icon="arrow_back" onClick={onBack}>Back to Profile</Button></div>;
}
function MenuRow({ icon, label, sub, onClick, danger }) {
  return <button onClick={onClick} className="wg-listrow" style={{ width: '100%', background: 'none', border: 0, borderBottom: '1px solid var(--border)', color: danger ? 'var(--error)' : 'inherit', font: 'inherit', cursor: 'pointer', textAlign: 'left', padding: '8px 4px' }}>
    <span style={{ display: 'grid', placeItems: 'center', width: 40, height: 40, borderRadius: 'var(--radius-md)', background: danger ? 'transparent' : 'var(--surface-raised)' }}><Icon name={icon} /></span>
    <div style={{ flex: 1 }}><div style={{ fontWeight: 700, fontSize: 15 }}>{label}</div>{sub && <div className="wg-row__sub">{sub}</div>}</div>{!danger && <Icon name="chevron_right" style={{ color: 'var(--text-muted)' }} />}</button>;
}
function ProfileMain({ setView, go }) {
  const me = PLAYERS.find(p => p.you);
  return <>
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, padding: '10px 20px 18px', textAlign: 'center' }}>
      <Avatar name={ME} size={104} ring />
      <div className="wg-display" style={{ fontSize: 'var(--text-2xl)' }}>@{ME}</div>
      <div className="wg-muted" style={{ fontSize: 14, marginTop: -4 }}>Rita Fonseca · only your username is public</div>
    </div>
    <div style={{ padding: '0 16px' }}>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 8 }}>
        <StatCard accent label="Rank" value="#2" sub={LOBBY.name} /><StatCard label="Points" value={fmtPts(me.points)} sub="this season" /><StatCard label="Owned" value={me.terr} sub="territories" /></div>
      <Card style={{ padding: '4px 12px', marginTop: 16 }}>
        <MenuRow icon="edit" label="Edit profile" sub="Username, name, picture" onClick={() => setView('edit')} />
        <MenuRow icon="group" label="Friends" sub="2 requests waiting" onClick={() => setView('friends')} />
        <MenuRow icon="insights" label="My stats" sub="Points, rank, territories" onClick={() => go('leaderboard')} />
        <MenuRow icon="sports_esports" label="Tonight's minigame" sub="Win a special item" onClick={() => setView('minigame')} />
        <MenuRow icon="shield_lock" label="Account & security" sub="Change password" onClick={() => setView('security')} />
        <div style={{ borderBottom: 0 }}><MenuRow icon="logout" label="Log out" danger onClick={() => go('login')} /></div>
      </Card>
    </div></>;
}
function EditProfile({ back }) {
  const [pic, setPic] = React.useState(true);
  return <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 14 }}>
    <h1 className="wg-display" style={{ fontSize: 'var(--text-2xl)', padding: '0 4px' }}>Edit profile</h1>
    <Card style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
      <div style={{ width: 96, height: 96, borderRadius: '50%', flex: 'none', overflow: 'hidden', boxShadow: '0 0 0 3px var(--accent)', display: 'grid', placeItems: 'center', background: 'var(--surface-raised)' }}>{pic ? <Icon name="face" size={52} style={{ color: 'var(--text-muted)' }} /> : <Avatar name={ME} size={96} />}</div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 8, flex: 1 }}>
        <div style={{ display: 'flex', gap: 8 }}><Button size="sm" variant="secondary" icon="upload">Upload</Button><Button size="sm" variant="secondary" icon="photo_camera">Take</Button></div>
        <div style={{ display: 'flex', gap: 8 }}><Button size="sm" variant="ghost" icon="swap_horiz">Replace</Button>{pic && <Button size="sm" variant="destructive" icon="delete" onClick={() => setPic(false)}>Remove</Button>}</div>
      </div></Card>
    <div className="wg-hint" style={{ marginTop: -6 }}><Icon name="crop" />Circular crop preview. Removing falls back to your initials.</div>
    <TextInput label="Username" icon="alternate_email" defaultValue={ME} hint="Public. Shown on leaderboards and photos." />
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}><TextInput label="First name" defaultValue="Rita" /><TextInput label="Surname" defaultValue="Fonseca" /></div>
    <TextInput label="Email" defaultValue="rita@novasbe.pt" readOnly />
    <Button size="lg" block icon="check" onClick={back}>Save</Button>
  </div>;
}
function Friends() {
  const [q, setQ] = React.useState('an');
  const [sent, setSent] = React.useState(false);
  return <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 12 }}>
    <h1 className="wg-display" style={{ fontSize: 'var(--text-2xl)', padding: '0 4px' }}>Friends</h1>
    <TextInput icon="search" placeholder="Search usernames" value={q} onChange={setQ} />
    {q && <Card style={{ padding: '4px 12px' }}>{['ana.lx', 'andre_m'].map(n => <div key={n} className="wg-listrow"><Avatar name={n} /><b style={{ flex: 1 }}>{n}</b>
      {n === 'andre_m' ? <span className="wg-hint"><Icon name="timer" />Declined · retry in 8 min</span> : <Button size="sm" variant={sent ? 'ghost' : 'primary'} icon={sent ? 'check' : 'person_add'} onClick={() => setSent(true)}>{sent ? 'Sent' : 'Add'}</Button>}</div>)}</Card>}
    <SectionTitle>Requests</SectionTitle>
    <Card style={{ padding: '4px 12px' }}>
      <div className="wg-listrow"><Avatar name="mia.santos" /><div style={{ flex: 1 }}><b>mia.santos</b><div className="wg-row__sub">wants to be friends</div></div><IconButton icon="close" label="Decline" /><IconButton icon="check" label="Accept" variant="accent" /></div>
      <div className="wg-listrow"><Avatar name="tomas.p" /><div style={{ flex: 1 }}><b>tomas.p</b><div className="wg-row__sub">Outgoing · pending</div></div><Button size="sm" variant="ghost">Cancel</Button></div>
    </Card>
    <SectionTitle right={<span className="wg-hint"><Icon name="lock" />Private</span>}>Your friends · 2</SectionTitle>
    <Card style={{ padding: '4px 12px' }}>{['ana.lx', 'joao_b'].map(n => <div key={n} className="wg-listrow"><Avatar name={n} /><b style={{ flex: 1 }}>{n}</b><Button size="sm" variant="destructive">Remove</Button></div>)}</Card>
  </div>;
}
function Security() {
  return <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 14 }}>
    <h1 className="wg-display" style={{ fontSize: 'var(--text-2xl)', padding: '0 4px' }}>Account & security</h1>
    <PasswordInput label="Current password" />
    <PasswordInput label="New password" hint="At least 8 characters" />
    <PasswordInput label="Confirm new password" />
    <Alert tone="info" title="Signs you out everywhere">Changing your password logs out all your devices.</Alert>
    <Button size="lg" block icon="key">Change password</Button>
  </div>;
}
function Minigame({ demo }) {
  const [phase, setPhase] = React.useState(demo.mini || 'start');
  const ITEMS = [{ icon: 'bolt', name: '2× multiplier', sub: 'Next drink counts double' }, { icon: 'shield', name: 'Territory shield', sub: '1 hour of protection' }];
  return <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 14 }}>
    <h1 className="wg-display" style={{ fontSize: 'var(--text-2xl)', padding: '0 4px' }}>Reaction test</h1>
    {phase === 'start' && <EmptyState icon="sports_esports" title="One go per game night" action={<Button size="lg" icon="play_arrow" onClick={() => setPhase('result')}>Start</Button>}>Tap the moment the screen flashes. Win an item, not points.</EmptyState>}
    {phase === 'played' && <EmptyState icon="bedtime" title="Already played tonight" action={<Countdown seconds={18 * 3600} inline />}>Your next go unlocks when Thursday's window opens.</EmptyState>}
    {phase === 'result' && <Card style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 10, padding: 24 }}>
      <div className="wg-num wg-pop" style={{ fontSize: 'var(--text-4xl)', color: 'var(--accent-ink)' }}>213<span style={{ fontSize: 22 }}>ms</span></div>
      <span className="wg-pop" style={{ display: 'grid', placeItems: 'center', width: 72, height: 72, borderRadius: 'var(--radius-lg)', background: 'var(--accent)', color: 'var(--on-accent)' }}><Icon name="bolt" fill size={40} /></span>
      <b style={{ fontSize: 18 }}>You won a 2× multiplier</b><span className="wg-muted" style={{ fontSize: 14 }}>Added to your inventory.</span>
      <Button variant="secondary" onClick={() => setPhase('played')}>Done</Button></Card>}
    <SectionTitle>Inventory</SectionTitle>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>{ITEMS.map(i => <Card key={i.name} style={{ padding: 14 }}><Icon name={i.icon} fill size={28} style={{ color: 'var(--accent-ink)' }} /><div style={{ fontWeight: 800, marginTop: 8 }}>{i.name}</div><div className="wg-row__sub">{i.sub}</div></Card>)}</div>
  </div>;
}
function ProfileScreen({ go, demo = {} }) {
  const [view, setView] = React.useState(demo.profile || 'main');
  const back = () => setView('main');
  return <div style={{ padding: '54px 0 120px' }}>
    {view === 'main' ? <ProfileMain setView={setView} go={go} /> : <><BackBar onBack={back} />
      {view === 'edit' && <EditProfile back={back} />}{view === 'friends' && <Friends />}{view === 'security' && <Security />}{view === 'minigame' && <Minigame demo={demo} />}</>}
  </div>;
}

function MemoriesScreen({ demo = {} }) {
  const [page, setPage] = React.useState(0);
  const [open, setOpen] = React.useState(null);
  const pages = Math.ceil(MEMORIES.length / 4), list = MEMORIES.slice(page * 4, page * 4 + 4);
  if (demo.memories === 'empty') return <div style={{ padding: '54px 0 120px' }}><ScreenHeader eyebrow={LOBBY.name} title="Memories" /><div style={{ padding: '0 16px' }}><EmptyState icon="photo_camera" title="No drinks yet">The first check-in of the night shows up here for the whole lobby.</EmptyState></div></div>;
  if (open) { const m = open, t = m.t && TERRITORIES.find(x => x.id === m.t);
    return <div style={{ padding: '54px 0 120px' }}><div style={{ padding: '0 8px 6px' }}><Button variant="ghost" icon="arrow_back" onClick={() => setOpen(null)}>Memories</Button></div>
      <div style={{ padding: '0 16px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <PhotoCard {...m} status={t ? statusOf(t) : 'free'} />
        {m.mine && <><Alert tone="info" title="Wrong drink or size?" action={<Countdown inline seconds={96} />}>You can correct it for 2 minutes after posting.</Alert>
          <SegmentedControl value="large" options={[{ value: 'small', label: 'Small', sub: '250 ml' }, { value: 'medium', label: 'Medium', sub: '330 ml' }, { value: 'large', label: 'Large', sub: '500 ml' }]} />
          <Button variant="destructive" block icon="delete">Delete photo</Button>
          <div className="wg-hint" style={{ justifyContent: 'center', textAlign: 'center' }}>Points stay if you delete. Photos expire 30 days after the season.</div></>}
      </div></div>; }
  return <div style={{ padding: '54px 0 120px' }}>
    <ScreenHeader eyebrow={LOBBY.name + ' · newest first'} title="Memories" />
    <div style={{ padding: '0 16px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
      {list.map((m, i) => { const t = m.t && TERRITORIES.find(x => x.id === m.t); return <PhotoCard key={i} {...m} status={t ? statusOf(t) : 'free'} onOpen={() => setOpen(m)} />; })}
    </div>
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, marginTop: 14 }}>
      <IconButton icon="chevron_left" label="Newer" onClick={() => setPage(Math.max(0, page - 1))} /><span className="wg-muted" style={{ fontSize: 14, fontWeight: 700 }}>Page {page + 1} of {pages}</span><IconButton icon="chevron_right" label="Older" onClick={() => setPage(Math.min(pages - 1, page + 1))} /></div>
  </div>;
}

function LoginScreen({ go, demo = {} }) {
  const [mode, setMode] = React.useState('login');
  const e = demo.auth;
  return <div style={{ padding: '80px 20px 40px', display: 'flex', flexDirection: 'column', gap: 14 }}>
    <div className="wg-display" style={{ fontSize: 'var(--text-4xl)', color: 'var(--accent-ink)' }}>WeGoPub</div>
    <div className="wg-muted" style={{ fontSize: 16, marginTop: -6 }}>Every drink counts. Take the city.</div>
    <div style={{ marginTop: 10 }}><SegmentedControl value={mode} onChange={setMode} options={[{ value: 'login', label: 'Log in' }, { value: 'signup', label: 'Create account' }]} /></div>
    {e === 'locked' && <Alert tone="warning" title="Too many attempts" action={<Countdown inline seconds={299} />}>Wait a few minutes, then try again.</Alert>}
    {e === 'down' && <Alert tone="error" title="Service unavailable">We can't reach the server. Try again in a moment.</Alert>}
    {mode === 'signup' && <><div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}><TextInput label="First name" /><TextInput label="Surname" /></div><TextInput label="Username" icon="alternate_email" hint="The only thing other players see" /></>}
    <TextInput label="Email" type="email" icon="mail" defaultValue="rita@novasbe.pt" />
    <PasswordInput label="Password" defaultValue="wrongpass" error={e === 'wrong' && mode === 'login' ? 'Wrong email or password.' : undefined} hint={mode === 'signup' ? 'At least 8 characters' : undefined} />
    {mode === 'signup' && <PasswordInput label="Confirm password" />}
    {mode === 'login' && <Checkbox label="Remember me on this device" hint="30 days" defaultChecked />}
    <Button size="lg" block onClick={() => go('map')}>{mode === 'login' ? 'Log in' : 'Create account'}</Button>
  </div>;
}
Object.assign(window, { ProfileScreen, MemoriesScreen, LoginScreen });
