// Mock game state + shared helpers for the WeGoPub UI kit.
const DS = window.WeGoPubDesignSystem_71f296 || {};
Object.assign(window, DS);

const ME = 'ritafromlx';
const LOBBY = { name: 'Thursday Crew', code: 'K7P2QX', endsIn: 3 * 86400 + 4 * 3600 + 12 * 60, endsAt: 'Sun 6 Dec 2026, 18:00 WET' };
const PLAYERS = [
  { name: 'ana.lx', points: 18.5, terr: 6 },
  { name: ME, points: 12.25, terr: 3, you: true },
  { name: 'joao_b', points: 9, terr: 1 },
  { name: 'mia.santos', points: 4.75, terr: 0 },
  { name: 'tomas.p', points: 2, terr: 0 },
];
// [id, name, lat, lng, radius m, owner, {player: territory points}]
const T = (id, name, lat, lng, r, owner, pts = {}) => ({ id, name, lat, lng, r, owner, pts });
const TERRITORIES = [
  T('shortys', 'Shortys', 38.71228, -9.14492, 34, 'ana.lx', { 'ana.lx': 9, [ME]: 7, joao_b: 2 }),
  T('le-pub', 'Le Pub', 38.71155, -9.14435, 30, 'ana.lx', { 'ana.lx': 5, [ME]: 1 }),
  T('party-street', 'Party Street', 38.71200, -9.14610, 36, 'ana.lx', { 'ana.lx': 6, joao_b: 4 }),
  T('rua-da-rosa', 'Rua da Rosa', 38.71335, -9.14660, 34, ME, { [ME]: 8, 'ana.lx': 3 }),
  T('rua-dos-mouros', 'Rua dos Mouros', 38.71345, -9.14455, 30, null),
  T('cheers-irish-pub', 'Cheers Irish Pub', 38.71440, -9.14540, 30, 'joao_b', { joao_b: 4 }),
  T('outer-bairro', 'Outer Bairro', 38.71445, -9.14760, 40, null),
  T('autschan', 'Autschan', 38.71090, -9.14590, 30, null),
  T('sao-pedro-de-alcantara', 'São Pedro de Alcântara', 38.71520, -9.14400, 38, null),
  T('principe-real', 'Príncipe Real', 38.71660, -9.14860, 46, ME, { [ME]: 5 }),
  T('chiado', 'Chiado', 38.71070, -9.14190, 44, 'ana.lx', { 'ana.lx': 7, [ME]: 2 }),
  T('bica', 'Bica', 38.70880, -9.14700, 36, ME, { [ME]: 4, 'mia.santos': 2 }),
  T('santa-catarina', 'Santa Catarina', 38.70960, -9.14860, 38, null),
  T('calcada-do-combro', 'Calçada do Combro', 38.71040, -9.14740, 30, null),
  T('pink-street', 'Pink Street', 38.70690, -9.14420, 36, 'ana.lx', { 'ana.lx': 8, [ME]: 3, 'tomas.p': 2 }),
  T('time-out-market', 'Time Out Market', 38.70660, -9.14620, 40, 'ana.lx', { 'ana.lx': 4 }),
  T('sao-paulo', 'São Paulo', 38.70760, -9.14770, 32, null),
  T('santos-kiosk', 'Santos Kiosk', 38.70740, -9.15320, 32, null),
  T('tower-bar', 'Tower Bar', 38.71000, -9.15000, 30, null),
  T('after8', 'After8', 38.70830, -9.15090, 30, null),
  T('praca-das-flores', 'Praça das Flores', 38.71540, -9.15300, 38, null),
  T('sao-bento', 'São Bento', 38.71240, -9.15280, 40, null),
  T('madragoa', 'Madragoa', 38.70820, -9.15560, 42, null),
  T('sao-pedro', 'Miradouro', 38.71590, -9.14560, 26, null),
  T('nova-sbe', 'Nova SBE', 38.67830, -9.32590, 140, null, { 'mia.santos': 0 }),
];
const statusOf = t => (t.owner === ME ? 'yours' : t.owner ? 'theirs' : 'free');
const myPts = t => t.pts[ME] || 0;
const neededFor = t => (t.owner && t.owner !== ME ? (t.pts[t.owner] || 0) - myPts(t) + 1 : 0);
const leadBy = t => { const others = Object.entries(t.pts).filter(([k]) => k !== ME).map(([, v]) => v); return myPts(t) - Math.max(0, ...others); };
const CURRENT = 'shortys';
const ME_POS = { lat: 38.71232, lng: -9.14488, acc: 12 };
const VIEWS = {
  Me: { lat: ME_POS.lat, lng: ME_POS.lng, z: 17.2 },
  'Bairro Alto': { lat: 38.71280, lng: -9.14560, z: 17 },
  Lisbon: { lat: 38.71120, lng: -9.14850, z: 15.6 },
  'Nova SBE': { lat: 38.67830, lng: -9.32590, z: 16.4 },
  All: { lat: 38.6960, lng: -9.2350, z: 12.4 },
};
const POINTS = { beer: { small: 1, medium: 2, large: 3 }, wine: { small: 1, medium: 2, large: 4 }, mixed: { small: 2, medium: 3, large: 5 }, shot: { standard: 4 } };
const VOLUMES = { beer: { small: 250, medium: 330, large: 500 }, wine: { small: 100, medium: 150, large: 250 } };
const DRINKS = [
  { value: 'beer', label: 'Beer', icon: 'sports_bar' }, { value: 'wine', label: 'Wine', icon: 'wine_bar' },
  { value: 'shot', label: 'Shot', icon: 'liquor' }, { value: 'mixed', label: 'Mixed drink', icon: 'local_bar' }];
const MEMORIES = [
  { user: 'ana.lx', time: 'Thu 23:52', territory: 'Pink Street', t: 'pink-street', drink: 'Shot', points: 4 },
  { user: ME, time: 'Thu 23:41', territory: 'Shortys', t: 'shortys', drink: 'Beer · Large 500 ml', points: 3, mine: true },
  { user: 'joao_b', time: 'Thu 23:20', territory: 'Cheers Irish Pub', t: 'cheers-irish-pub', drink: 'Mixed drink · Medium', points: 3 },
  { user: 'mia.santos', time: 'Thu 22:58', territory: null, drink: 'Wine · Medium 150 ml', points: 2 },
  { user: 'ana.lx', time: 'Thu 22:31', territory: 'Chiado', t: 'chiado', drink: 'Beer · Medium 330 ml', points: 2 },
  { user: ME, time: 'Thu 21:47', territory: 'Rua da Rosa', t: 'rua-da-rosa', drink: 'Beer · Large 500 ml', points: 3, mine: true },
  { user: 'tomas.p', time: 'Thu 21:12', territory: 'Pink Street', t: 'pink-street', drink: 'Beer · Small 250 ml', points: 1 },
];
const fmtPts = n => String(Math.round(n * 100) / 100);
const plural = (n, w) => n + ' ' + w + (n === 1 ? '' : 's');

function ScreenHeader({ eyebrow, title, right }) {
  return <header style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', gap: 12, padding: '8px 20px 16px' }}>
    <div style={{ minWidth: 0 }}>{eyebrow && <div className="wg-eyebrow" style={{ marginBottom: 6 }}>{eyebrow}</div>}<h1 className="wg-display" style={{ fontSize: 'var(--text-3xl)' }}>{title}</h1></div>{right}</header>;
}
function SectionTitle({ children, right }) {
  return <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '22px 0 10px' }}><h2 style={{ margin: 0, fontSize: 17, fontWeight: 800, letterSpacing: '-.01em' }}>{children}</h2>{right}</div>;
}
function EmptyState({ icon, title, children, action }) {
  return <div className="wg-card" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center', gap: 10, padding: '28px 20px' }}>
    <span style={{ display: 'grid', placeItems: 'center', width: 64, height: 64, borderRadius: '50%', background: 'var(--accent-soft)', color: 'var(--accent-ink)' }}><Icon name={icon} size={32} /></span>
    <b style={{ fontSize: 17 }}>{title}</b><span className="wg-muted" style={{ fontSize: 14, maxWidth: 280 }}>{children}</span>{action}</div>;
}

Object.assign(window, { ME, LOBBY, PLAYERS, TERRITORIES, statusOf, myPts, neededFor, leadBy, CURRENT, ME_POS, VIEWS, POINTS, VOLUMES, DRINKS, MEMORIES, fmtPts, plural, ScreenHeader, SectionTitle, EmptyState });
