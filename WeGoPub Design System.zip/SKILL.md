---
name: wegopub-design
description: Use this skill to generate well-branded interfaces and assets for WeGoPub, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the readme.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Quick start: link `styles.css`, put `class="wg-app" data-theme="hyro-night"` on the root (or another direction id: hyro-day, base-club, rush, tennis, moon), and use the `wg-*` classes from `components/components.css` or the React components in `components/`.
